import logging
import json

from timezonefinder import TimezoneFinder
import azure.functions as func

tf = TimezoneFinder()
def main(req: func.HttpRequest) -> func.HttpResponse:

    input_rows = req.get_json().get('data')
    output_rows = []
    for row in (input_rows):
        row_number = row[0]
        lat = row[1]
        lng = row[2]
        timezone = tf.timezone_at(lng=lng, lat=lat)
        output_value = {}
        output_value["timezone"] = timezone
        output_rows.append([row_number, output_value])

    package = {}
    package['data'] = output_rows
    json_package = json.dumps(package)

    return func.HttpResponse(json_package, status_code=200)
   