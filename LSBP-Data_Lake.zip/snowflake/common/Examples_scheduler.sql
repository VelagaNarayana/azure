-- Example tasks to schedule
insert into CONTROL.SCHEDULER (TIMEZONE, WAREHOUSE,PROCESS_NAME,PROCESS_TYPE,SCHEDULE_TIME) values
   ('Europe/London', 'ANALYTICS_DEV_WH', 'Irradiance', 'ADF', '10:30'),
   ('Europe/London', 'ANALYTICS_DEV_WH', 'Irradiance', 'ADF', '10:26'),
   ('Australia/Sydney', 'ANALYTICS_DEV_WH', 'Satellite', 'LA', '21:30');

-- Example external function execution
select common.execute_process('Europe/London','Irradiance','ADF', CONVERT_TIMEZONE('UTC', 'Europe/London',sysdate()),sysdate())

-- example execution of drop tasks
CALL DROP_SCHEDULER_TASKS()
CALL DROP_SCHEDULER_TASKS('EUROPELONDON_IRRADIANCE_1030')

-- example execution of creating tasks
CALL CREATE_SCHEDULER_TASKS()