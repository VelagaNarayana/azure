use database data_lake_{{ env }};
use warehouse DATA_TRANSFORM_{{ env }}_WH;
use role dl_{{ env }}_data_engineers;
USE SCHEMA COMMON;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace function COMMON.REPLACE_HTML(SUBJECT VARCHAR)
  returns string
  language javascript
  strict
  as '
     var str = SUBJECT;
     str= str.replace(/\&#039;/g,\'\\\'\');
     str= str.replace(/\&amp;/g,\'&\');
    str= str.replace(/\&lt;/g,\'<\');
    str= str.replace(/\&gt;/g,\'>\');
    str= str.replace(/\&quot;/g,\'"\');
    str= str.replace(/(<BR><\\/BR>)/g,\'\\n \');    
    return str;
  ';