use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

  create or replace function COMMON.RESOLVE_RECORD_SOURCE(RECORD_QUALITY VARCHAR)
  returns VARCHAR
  as $$
       case when RECORD_QUALITY='GOOD' then 'Pyranometer'
         when RECORD_QUALITY='MEDIUM' then 'Pyranometer / Satellite'
         when RECORD_QUALITY='BACKFILL' then 'Satellite'
         else 'Not Defined'
    end
  $$;