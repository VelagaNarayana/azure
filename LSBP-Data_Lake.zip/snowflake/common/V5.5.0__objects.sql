use database data_lake_{{ env }};
use warehouse DATA_TRANSFORM_{{ env }}_WH;
use role dl_{{ env }}_data_engineers;
USE SCHEMA COMMON;

create or replace function COMMON.GET_WARHOUSE_SIZE_NUMBER(WAREHOUSE_SIZE VARCHAR)
returns INTEGER
as $$
       case when upper(replace(WAREHOUSE_SIZE,'-','')) = 'XSMALL' then 1      
            when upper(replace(WAREHOUSE_SIZE,'-','')) = 'SMALL' then 2
            when upper(replace(WAREHOUSE_SIZE,'-','')) = 'MEDIUM' then 3
            when upper(replace(WAREHOUSE_SIZE,'-','')) = 'LARGE' then 4
            when upper(replace(WAREHOUSE_SIZE,'-','')) = 'XLARGE' then 5
            when upper(replace(WAREHOUSE_SIZE,'-','')) = 'XXLARGE' or upper(replace(WAREHOUSE_SIZE,'-','')) = 'X2LARGE' or upper(replace(WAREHOUSE_SIZE,'-','')) = '2XLARGE' then 6
            when upper(replace(WAREHOUSE_SIZE,'-','')) = 'XXXLARGE' or upper(replace(WAREHOUSE_SIZE,'-','')) = 'X3LARGE' or upper(replace(WAREHOUSE_SIZE,'-','')) = '3XLARGE' then 7
            when upper(replace(WAREHOUSE_SIZE,'-','')) = 'XXXXLARGE' or upper(replace(WAREHOUSE_SIZE,'-','')) = 'X4LARGE' or upper(replace(WAREHOUSE_SIZE,'-','')) = '4XLARGE' then 8      
       else 0       
       end
$$;

CREATE OR REPLACE PROCEDURE COMMON.PROC_ALTER_WAREHOUSE_SIZE(WAREHOUSE_NAME VARCHAR,WAREHOUSE_SIZE VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS CALLER 
AS
$$ 
  var stmt = snowflake.createStatement({
  sqlText: "SHOW WAREHOUSES LIKE '"+WAREHOUSE_NAME+"'"});  
  var rsSelectQuery = stmt.execute();
  rsSelectQuery.next();
  var current_warehouse_size =  rsSelectQuery.getColumnValue(4).replace('-','').toUpperCase();
  var proposed_warehouse_size =  WAREHOUSE_SIZE.replace('-','').toUpperCase();
  var isCurrentWarehouse =  rsSelectQuery.getColumnValue(11);
  
  var wh_running_queued_queries_count;
  
  if (isCurrentWarehouse.toUpperCase() == 'Y')
  {
  wh_running_queued_queries_count = rsSelectQuery.getColumnValue(8) + rsSelectQuery.getColumnValue(9) - 1;
  }else {
  wh_running_queued_queries_count = rsSelectQuery.getColumnValue(8) + rsSelectQuery.getColumnValue(9) ;
  }
   
  stmt = snowflake.createStatement({
  sqlText: "select COMMON.GET_WARHOUSE_SIZE_NUMBER('"+current_warehouse_size+"') as current_warehouse_size_num,COMMON.GET_WARHOUSE_SIZE_NUMBER('"+proposed_warehouse_size+"') as proposed_warehouse_size_num "});  
  rsSelectWHSize = stmt.execute();
  rsSelectWHSize.next();
 
  var current_warehouse_size_num =  rsSelectWHSize.getColumnValue(1);
  var proposed_warehouse_size_num =  rsSelectWHSize.getColumnValue(2);
    
  if (proposed_warehouse_size_num <= 0 || current_warehouse_size_num <= 0 )
  {
  return "Invalid Proposed Warehouse Size" ;
  } 
  else if (current_warehouse_size_num == proposed_warehouse_size_num )
  {
      return "Current Warehouse size is same as proposed warehouse size" ;
  }
  else if (proposed_warehouse_size_num < current_warehouse_size_num )
  {
    if(wh_running_queued_queries_count <= 0)
    {
      var sites_cmd =
        {
            sqlText: "ALTER WAREHOUSE "+WAREHOUSE_NAME+" SET WAREHOUSE_SIZE = '"+WAREHOUSE_SIZE+"'"
        }
      var stmt = snowflake.createStatement(sites_cmd);
      stmt.execute();            
            return "Warehouse size changed from "+current_warehouse_size+" to "+proposed_warehouse_size+" ";   
    }else{
          return "Warehouse size could not be changed because warehouse is in running state";     
    }    
  }else{
      var sites_cmd =
        {
            sqlText: "ALTER WAREHOUSE "+WAREHOUSE_NAME+" SET WAREHOUSE_SIZE = '"+WAREHOUSE_SIZE+"'"
        }
      var stmt = snowflake.createStatement(sites_cmd);
      stmt.execute();    
      return "Warehouse size changed from "+current_warehouse_size+" to "+proposed_warehouse_size+" ";   
  }; 
$$
;
