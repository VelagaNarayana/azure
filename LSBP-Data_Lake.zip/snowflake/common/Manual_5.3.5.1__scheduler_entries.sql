use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

insert into control.scheduler(timezone,process_name, schedule_time,process_type,warehouse)   
select * from ((select distinct derived_timezone as timezone from curated.dim_prod_meter_details meters join curated.dim_sites sites on 
sites.site_key = meters.site_fkey
where meters.source = 'Insolar') timezones
cross join (select 'Production meter' as process_name, '04:00' as schedule_time, 'ADF' as process_type, 'DATA_TRANSFORM_PRD_WH' as warehouse) processes )  

insert into control.scheduler(timezone,process_name, schedule_time,process_type,warehouse)
  select * from (
   (select distinct coalesce(derived_timezone,source_timezone) as timezone from curated.dim_sites) timezones
   cross join (select 'Satellite' as process_name, '04:00' as schedule_time, 'LogicApp' as process_type, 'DATA_LOAD_PRD_WH' as warehouse) processes)
   