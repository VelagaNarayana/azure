use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace external function common.execute_process(timezone varchar,processName varchar,processType varchar,timestampLocal TIMESTAMP_NTZ,timestampUtc TIMESTAMP_NTZ)
returns variant
api_integration = dl_api_int_{{ integration }}
as 'https://dl-appl-api-mgmnt.azure-api.net/dl-la-{{ env }}-process-orchestrator/manual/paths/invoke';


CREATE OR REPLACE TABLE CONTROL.SCHEDULER
(
  TIMEZONE	                VARCHAR(100) NULL,
  WAREHOUSE	                VARCHAR(100) NULL,
  PROCESS_NAME	            VARCHAR(100) NULL,
  PROCESS_TYPE	            VARCHAR(100) NULL,
  SCHEDULE_TIME	            VARCHAR(100) NULL,
  SCHEDULE_INTERVAL         SMALLINT NULL
)DATA_RETENTION_TIME_IN_DAYS = 31
COMMENT = "Scheduled processes for each timezone";

CREATE OR REPLACE PROCEDURE CONTROL.CREATE_SCHEDULER_TASKS()
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS CALLER 
AS
$$
    try{
        var query = "select TIMEZONE, WAREHOUSE, PROCESS_NAME, PROCESS_TYPE, SCHEDULE_TIME, SCHEDULE_INTERVAL from CONTROL.SCHEDULER";
        var templatesSqlCmd = {sqlText: query};
        var stmt = snowflake.createStatement(templatesSqlCmd);

        var rs1 = stmt.execute();
        var schedulesInserted = 0;
        var schedulesTotal = 0;

        while(rs1.next()) {
            try {
                var timezone = rs1.getColumnValueAsString("TIMEZONE");
                var warehouse = rs1.getColumnValueAsString("WAREHOUSE");
                var processName = rs1.getColumnValueAsString("PROCESS_NAME");
                var processType = rs1.getColumnValueAsString("PROCESS_TYPE");
                var scheduleTime = rs1.getColumnValueAsString("SCHEDULE_TIME");
                var scheduleInterval = rs1.getColumnValue("SCHEDULE_INTERVAL");

                var formattedTimezone = timezone.replace(/[\/|\:]/g,"")
                var formattedScheduleTime = scheduleTime.replace(/[\/|\:]/g,"")
                var time = scheduleTime.split(":");

                var cronExp = `${time[1]} ${time[0]} * * *`;
                
                var taskName = `${formattedTimezone}_${processName}_${formattedScheduleTime}`

                query = `CREATE OR REPLACE TASK ${taskName} WAREHOUSE = ${warehouse} SCHEDULE = 'USING CRON ${cronExp} ${timezone}' AS select common.execute_process('${timezone}','${processName}','${processType}', CONVERT_TIMEZONE('UTC', '${timezone}',sysdate()),sysdate());`
                templatesSqlCmd = {sqlText: query};
                stmt = snowflake.createStatement(templatesSqlCmd);
                stmt.execute();

                query = `ALTER TASK ${taskName} RESUME;`
                templatesSqlCmd = {sqlText: query};
                stmt = snowflake.createStatement(templatesSqlCmd);
                stmt.execute();

                schedulesInserted += 1;
            }
            finally {
                schedulesTotal += 1;
            }
        }
    }       
    finally{
        snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
    }
    return JSON.stringify({ "schedules": {"Inserted": schedulesInserted, "Total": schedulesTotal}});
$$;

CREATE OR REPLACE PROCEDURE CONTROL.DROP_SCHEDULER_TASKS(TASK_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS CALLER 
AS
$$
    try{
        var query;
        var schedulesRemoved = 0;
        var schedulesTotal = 0;
        if (TASK_NAME) {
            query = `DROP TASK IF EXISTS ${TASK_NAME};`
            var templatesSqlCmd = {sqlText: query};
            var stmt = snowflake.createStatement(templatesSqlCmd);

            var rs1 = stmt.execute();
            schedulesRemoved += 1;
            schedulesTotal += 1;
        } else {
            query = 'show tasks';
            var templatesSqlCmd = {sqlText: query};
            var stmt = snowflake.createStatement(templatesSqlCmd);

            var rs1 = stmt.execute();

            while(rs1.next()) {
                try {
                    var name = rs1.getColumnValueAsString("NAME");

                    var createTask = `DROP TASK IF EXISTS ${name};`
                    templatesSqlCmd = {sqlText: createTask};
                    stmt = snowflake.createStatement(templatesSqlCmd);
                    stmt.execute();
                    schedulesRemoved += 1;
                }
                finally {
                    schedulesTotal += 1;
                }
            }
        }
    }       
    finally{
        snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
    }
    return JSON.stringify({ "schedules": {"Removed": schedulesRemoved, "Total": schedulesTotal}});
$$;

