use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

create or replace external function common.get_timezone(latitude float, longitude float)
returns variant
RETURNS NULL ON NULL INPUT
api_integration = dl_api_int_{{ integration }}
as 'https://dl-appl-api-mgmnt.azure-api.net/dl-func-ext-sf-{{ env }}/get-timezone'
