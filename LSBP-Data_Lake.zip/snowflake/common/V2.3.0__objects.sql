
use database data_lake_{{ env }};
use warehouse DATA_TRANSFORM_{{ env }}_WH;
use role dl_{{ env }}_data_engineers;
USE SCHEMA COMMON;

create or replace function COMMON.GET_QUERY_TAG(PROCESS_EXEC_ID varchar, PROCESS_NAME varchar, OTHER varchar)
  returns string
  language javascript
  strict
  as '
     return PROCESS_EXEC_ID+"~"+PROCESS_NAME+"~"+OTHER
  ';

CREATE OR REPLACE PROCEDURE COMMON.PROC_ALTER_WAREHOUSE_SIZE(WAREHOUSE_NAME VARCHAR,WAREHOUSE_SIZE VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS CALLER 
AS
$$ 
var sites_cmd =
  {
      sqlText: "ALTER WAREHOUSE "+WAREHOUSE_NAME+" SET WAREHOUSE_SIZE = '"+WAREHOUSE_SIZE+"'"
    }
var stmt = snowflake.createStatement(sites_cmd);
stmt.execute();
return "Success";   

$$
;