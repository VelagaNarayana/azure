use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;
USE SCHEMA COMMON;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace function COMMON.REPLACE_QUERY(QUERY VARCHAR, FILTER_OR_PATH VARCHAR, DATA_SOURCE VARCHAR,PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
  returns string
  language javascript
  strict
  as $$
     var str = QUERY;
     str= str.replace(/\${filter_or_path}/g,FILTER_OR_PATH);
     str= str.replace(/\${data_source}/g,DATA_SOURCE);
     str= str.replace(/\${process_run_id}/g,PROCESS_RUN_ID);
     str= str.replace(/\${process_name}/g,PROCESS_NAME);
    return str;
  $$;
  
  create or replace function COMMON.RESOLVE_MISSING_DIMS(FIELD_VALUE VARCHAR)
  returns string
  as $$
       case when FIELD_VALUE is null or LEN(TRIM(FIELD_VALUE))=0 then '!' else FIELD_VALUE end
  $$;
  
  create or replace function COMMON.RESOLVE_UNKNOWN_DIMS(KEY NUMBER)
  returns NUMBER
  as $$
        coalesce(KEY,-1)
  $$;