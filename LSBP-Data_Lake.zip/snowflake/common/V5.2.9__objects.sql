use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

  create or replace function COMMON.CONVERT_TO_LOCAL_TZ(DATE DATE, TIME TIME, SOURCE_TZ STRING, TARGET_TZ STRING)
  returns datetime
  as $$
       case 
            when source_tz in ('Missing','Unknown','NA') or target_tz in ('Missing','Unknown','NA') then NULL            
            when DATE is not null and time is not null and source_tz is not null and target_tz is not null
            then convert_timezone(source_tz,target_tz,timestamp_from_parts(date,time))
            else NULL
       end
  $$;