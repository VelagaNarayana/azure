use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;


CREATE OR REPLACE PROCEDURE "COMMON"."PROC_DDL_OPERATION"(COMMAND NVARCHAR)
RETURNS STRING
LANGUAGE JAVASCRIPT
STRICT
EXECUTE AS CALLER
AS
$$
    var actionStatus;
    var stmt;
    
    stmt = snowflake.createStatement({
		sqlText: COMMAND
        });
    var rs = stmt.execute();
    rs.next();
    actionStatus = rs.getColumnValue(1);        
    return actionStatus;        
$$;        
