use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';


CREATE OR REPLACE PROCEDURE CONTROL.CREATE_SCHEDULER_TASKS()
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS CALLER 
AS
$$
    try{
        var schedulesInserted=0,schedulesTotal=0;
        var result = [];
        var query = "select TIMEZONE, WAREHOUSE, PROCESS_NAME, PROCESS_TYPE, SCHEDULE_TIME, SCHEDULE_INTERVAL from CONTROL.SCHEDULER";
        var templatesSqlCmd = {sqlText: query};
        var stmt = snowflake.createStatement(templatesSqlCmd);

        var rs1 = stmt.execute();
        

        while(rs1.next()) {
            try {
                var timezone = rs1.getColumnValueAsString("TIMEZONE");
                var warehouse = rs1.getColumnValueAsString("WAREHOUSE");
                var processName = rs1.getColumnValueAsString("PROCESS_NAME");
                var processType = rs1.getColumnValueAsString("PROCESS_TYPE");
                var scheduleTime = rs1.getColumnValueAsString("SCHEDULE_TIME");
                var scheduleInterval = rs1.getColumnValue("SCHEDULE_INTERVAL");

                var formattedProcessName = processName.replace(/\s/g, '');
                var formattedTimezone = timezone.replace(/[\/|\:]/g,"")
                var formattedScheduleTime = scheduleTime.replace(/[\/|\:]/g,"")
                var time = scheduleTime.split(":");

                var cronExp = `${time[1]} ${time[0]} * * *`;
                
                var taskName = `${formattedTimezone}_${formattedProcessName}_${formattedScheduleTime}`

                query = `CREATE OR REPLACE TASK CONTROL.${taskName} WAREHOUSE = ${warehouse} SCHEDULE = 'USING CRON ${cronExp} ${timezone}' AS select common.execute_process('${timezone}','${processName}','${processType}', CONVERT_TIMEZONE('UTC', '${timezone}',sysdate()),sysdate());`
                templatesSqlCmd = {sqlText: query};
                stmt = snowflake.createStatement(templatesSqlCmd);
                var rs = stmt.execute();
                rs.next();
                result.push(rs.getColumnValue(1));
                
                schedulesInserted+=1;

                query = `ALTER TASK CONTROL.${taskName} RESUME;`
                templatesSqlCmd = {sqlText: query};
                stmt = snowflake.createStatement(templatesSqlCmd);
                var rs = stmt.execute();

            }
            finally {
                schedulesTotal += 1;
            }
        }
    }       
    finally{
        snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
    }
    return JSON.stringify({ "Schedules": {"Inserted/Replaced": schedulesInserted, "Total": schedulesTotal, "Result":result}});
$$;

CREATE OR REPLACE PROCEDURE CONTROL.DROP_SCHEDULER_TASKS(TASK_NAME_OR_PATTERN VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS CALLER 
AS
$$

        var query;
        var result=[],schedulesTotal=0;
      
        query = "show tasks like '"+TASK_NAME_OR_PATTERN+"'";
        var templatesSqlCmd = {sqlText: query};
        var stmt = snowflake.createStatement(templatesSqlCmd);

        var rs1 = stmt.execute();

        while(rs1.next()) {
              var name = rs1.getColumnValueAsString("name");
              var schema = rs1.getColumnValueAsString("schema_name");

              var dropTask = `DROP TASK IF EXISTS ${schema}.${name};`
              templatesSqlCmd = {sqlText: dropTask};
              stmt = snowflake.createStatement(templatesSqlCmd);
              var rs = stmt.execute();
              rs.next();
              result.push(rs.getColumnValue(1)) ;  
              schedulesTotal++;
        }
        

     return JSON.stringify({ "Schedules": { "Total": schedulesTotal, "Result":result}});
$$;