use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

-- ADD COLUMNS DISPLAY_DATE_KEY and DISPLAY_TIME_KEY to table RAW.FACT_SV_SCHEDULED_SERVICES
ALTER TABLE RAW.FACT_SV_SCHEDULED_SERVICES 
ADD COLUMN DISPLAY_DATE_KEY NUMBER(38,0) null, DISPLAY_TIME_KEY NUMBER(38,0) null;


--  Updated SP for loading to FACT_SV_SCHEDULED_SERVICES
CREATE OR REPLACE PROCEDURE "RAW"."PROC_LOAD_FACT_SV_SCHEDULED_SERVICES"(PIPELINE_RUN_ID VARCHAR, PIPELINE_NAME VARCHAR)
    RETURNS string
    LANGUAGE javascript
    strict
    EXECUTE AS CALLER 
    AS
    $$
        snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PIPELINE_RUN_ID+"','"+PIPELINE_NAME+"','ref2fact'))"});
    	snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} ); 

		var stmt = snowflake.createStatement({
                   sqlText: "insert overwrite into RAW.FACT_SV_SCHEDULED_SERVICES SELECT SS2.*, common.resolve_unknown_dims(DT.date_key)	as 	display_date_key, common.resolve_unknown_dims(TM.time_key)	as 	display_time_key FROM (SELECT SVSS1.\"UID\" 	as	Scheduled_Service_id	, SVSS1.\"RecordStatusID\"	as	Record_status_id	, common.resolve_unknown_dims(SVA.agreement_key)	as	Agreement_fkey	, common.resolve_unknown_dims(DS.Site_Key)	as	Site_fkey	, \"EquipmentID\"	as	Equipment_id	, \"SchedServiceType\"	as	Sched_Service_Type	, \"IntervalID\"	as	Interval_ID	, \"IntervalEveryID\"	as	Interval_every_id	, common.RESOLVE_DATE_YEAR(\"DueDate\")	as	Due_date	, \"DueTime\"	as	Due_time	, common.RESOLVE_DATE_YEAR(\"IntervalStartDate\")	as	Interval_start_date	, common.RESOLVE_DATE_YEAR(\"IntervalEndDate\")	as	Interval_end_date	, SVSS1.\"ServiceRoutineID\"	as	Service_routine_id	, \"StatusID\"	as	Status_id	, SVSS1.\"ServiceOrdersJobID\"	as	Service_orders_job_id	, FSOJ.SOJ_key	as	Service_orders_job_fkey	, \"Liability\"	as	Liability	, SVSS1.\"Memo\"	as	Memo	, \"Charge\"	as	Charge	, \"CurrencyCharge\"	as	Currency_Charge	, SVSS1.\"ServiceSchemeID\"	as	Service_scheme_id	, \"PersonnelID\"	as	Personnel_id	, \"AppointmentID\"	as	Appointment_id	, \"ChargeBasis\"	as	Charge_Basis	, \"RenewalPriceMethod\"	as	Renewal_Price_Method	, \"SSEquipmentID\"	as	SS_equipment_id	, \"EstDurationInMins\"	as	Est_Duration_In_Mins	, \"ProjectItemID\"	as	Project_item_id	, \"CustomersEquipmentSSID\"	as	Customers_equipment_ss_id	, \"AgreementEquipmentID\"	as	Agreement_equipment_id	, SVSS1.\"RecordTimeStamp\"	as	Record_timestamp	, \"OriginateType\"	as	Originate_Type	, \"CriteriaType\"	as	Criteria_Type	, \"OriginatingScheduledServiceID\"	as	Originating_service_schedule_ID	, \"GenerateAsType\"	as	Generate_As_Type	, \"PriorityLevel\"	as  Priority_Level , \"OptionalType\"	as	Optional_Type	, \"OptionalUntilDays\"	as	Optional_Until_Days	, \"ProblemMemo\"	as	Problem_Memo	, SVSS1.\"JobCategoryID\"	as	Job_category_id	, \"IntervalEvery\"	as	Interval_every	, SVSS1.\"Classification\"	as	Classification	, case  when SOJS.\"Name\" in ('Completed','Completed (Suspended)','Fixed Service/Restored','Fixed/Service Restored','Returning') then 'Done' when SOJS.\"Name\" in ('Cancelled Job - No Longer Reqd ','Unsafe','Unsfafe') then 'NtDn'  when SOJS.\"Name\" in ('Awaiting Completion','Awaiting Parts','Hold - client approval','Hold - engineering','Hold - land management','Hold - spares client','Hold - spares ordered','Hold - spares required','In Progress','No Spares','Suspended','Work Not Complete','Work Not Completed') then 'Part' when SOJS.\"Name\" in ('Adverse Weather','Allocation Cancelled','Called Elsewhere','Cancelling Allocation','No Access','Rejected') then 'ReSchd'  when SOJS.\"Name\" in ('Accepted','Allocated','Allocated & Despatched','Arrived','Departed','Outstanding','Waiting/On Break')  then 'Schd'  else 'No Status Type' end as Status_type , case  when ( SVSS1.\"ServiceOrdersJobID\" is null or SVSS1.\"ServiceOrdersJobID\" =0 ) THEN \"DueDate\"   when ( status_type='Done' AND FSOJ.has_real_fixtime =1 ) THEN SVSOJ.\"FixTime\"  when ( FSOJ.has_reaL_fixtime=0 ) then SVSOJ.\"ScheduledDate\" end as Display_Date , SOJT.task_count as task_count, case when ( Status_type='Schd' and display_date >= current_date() and SVSOJ.\"ScheduledDate\" < to_date('01/01/2015','DD/MM/YYYY')) THEN 'Plan'  when ( Status_type IN ('Plan', 'Scheduled') AND Display_Date < current_date())  THEN 'ReSchd'  when ( Status_type IN ('Plan', 'Scheduled') AND Display_Date > current_date())  THEN Status_type  when ( Status_type='ReSchd' AND Display_Date >= current_date() ) THEN 'Schd'  when ( Status_type='Part' and FSOJ.Job_Status_Name='In Progress' AND task_count<=1 AND Display_Date < current_date()) THEN ( 'ReSchd' )  when ( Status_type='Part' and FSOJ.Job_Status_Name='In Progress' AND task_count<=1 AND Display_Date >= current_date()) THEN ( 'Schd' )  else Status_type END as	display_status	, SVSS1.\"Memo\"	as	Block_Name, display_status || ' - ' || block_name as Display_final, '" + PIPELINE_RUN_ID + "' as 	Process_exec_id	, sysdate()	as 	Load_ts FROM ( select * from \"REFERENCE\".\"SV_ScheduledServices\" SVSS where (SVSS.\"RecordStatusID\" < 6 and ( SVSS.\"SchedServiceType\" <> 3 or SVSS.\"SchedServiceType\" is null)) and (SVSS.\"EquipmentID\" <> 0 or SVSS.\"EquipmentID\" is null) and SVSS.\"DueDate\" >= '2016-01-01') SVSS1  left join CURATED.Dim_SV_Agreements SVA on SVSS1.\"AgreementID\"=SVA.agreement_id  left join \"REFERENCE\".\"SV_Customers\" SVC on SVSS1.\"CustomerID\"=SVC.\"UID\"  left join \"CURATED\".Dim_Sites DS on TRIM(SVC.\"ShortCode\")=DS.O_M_Reference_Formula left join RAW.FACT_SV_SERVICE_ORDERS_JOBS FSOJ on SVSS1.\"ServiceOrdersJobID\" = FSOJ.SOJ_ID  left join \"REFERENCE\".\"SV_ServiceOrdersJobs\" SVSOJ on FSOJ.SOJ_Key=SVSOJ.UID  left join \"REFERENCE\".\"SV_ServiceOrdersJobsStatus\" SOJS on SVSOJ.\"JobStatusID\"=SOJS.\"UID\"  left join (select \"ServiceOrdersJobID\",count(*) as task_count from \"REFERENCE\".\"SV_ServiceOrdersJobsTasks\" group by \"ServiceOrdersJobID\") SOJT on SVSS1.\"ServiceOrdersJobID\"=SOJT.\"ServiceOrdersJobID\")SS2 left join CURATED.Dim_Calendar_Date DT on  DATE(SS2.Display_Date)=DT.date  left join CURATED.Dim_Calendar_Time TM on TIME(SS2.Display_Date)=TM.time "
               });  
        var rs = stmt.execute();
        rs.next();
        rowsInserted = rs.getColumnValue(1);
        
        snowflake.execute( {sqlText: "COMMIT WORK;"} );
		  
		snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )

		return JSON.stringify({"Rows inserted":rowsInserted});
        
        $$
       ;    