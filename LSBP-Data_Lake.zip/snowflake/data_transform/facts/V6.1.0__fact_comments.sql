use database data_lake_{{ db }};
use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace view raw.fact_o_m_monthly_reporting_comments as
select common.resolve_unknown_dims(ds.site_key)      as site_key,
       common.resolve_unknown_dims(dcd.date_key)      as date_key,
       try_to_date(concat(qbmr.year_and_month, '-01')) as date,
       qbmr.year_and_month                             as original_year_and_month,
       qbmr.site_name                                  as original_site_name,
       qbmr.related_o_m_site                           as original_site_id,
       qbmr.comment_for_pr_summary,
       qbmr.comment2,
       qbmr.comment3,
       qbmr.h_s_comment,
       qbmr.lm_comment,
       qbmr.process_exec_id,
       qbmr.load_ts,
       qbmr.load_file      
from   reference.qb_monthly_resume qbmr
       left join curated.dim_sites ds
              on ( qbmr.site_name = ds.site_name_formula)
       left join curated.dim_calendar_date dcd
              on dcd.date = try_to_date(concat(qbmr.year_and_month, '-01'))
