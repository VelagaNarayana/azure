use database data_lake_{{ db }};
use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

CREATE OR REPLACE VIEW RAW.REP_FACT_SV_SCHEDULED_SERVICES
AS
SELECT *, row_number() OVER (PARTITION BY SITE_FKEY, TO_VARCHAR(DISPLAY_DATE ,'yyyyMM') ORDER BY display_final) as index_by_display_month from RAW.FACT_SV_SCHEDULED_SERVICES;

