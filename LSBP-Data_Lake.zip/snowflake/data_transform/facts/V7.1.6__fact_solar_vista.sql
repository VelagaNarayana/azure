use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

-- DDL for FACT_SV_SERVICE_ORDERS_JOBS
create or replace TRANSIENT TABLE RAW.FACT_SV_SERVICE_ORDERS_JOBS (
	SOJ_KEY NUMBER(38,0),
	SITE_FKEY NUMBER(38,0),
	SO_CREATED_DATE_KEY NUMBER(38,0),
	SO_CREATED_TIME_KEY NUMBER(38,0),
	SO_CUSTOMER_SITE_ID NUMBER(38,0),
	SO_CLOSED_DATE_KEY NUMBER(38,0),
	SO_CLOSED_TIME_KEY NUMBER(38,0),
	SO_RECORD_STATUS_ID NUMBER(38,0),
	SO_REFERENCE VARCHAR(20),
	SERVICE_ORDER_ID NUMBER(38,0),
	CUSTOMER_DEPT_ID NUMBER(38,0),
	CUSTOMER_EQUIPMENT_ID NUMBER(38,0),
	CUSTOMER_EQUIPMENT_MODULE_ID NUMBER(38,0),
	PRODUCT_ID NUMBER(38,0),
	PRODUCT_FKEY NUMBER(38,0),
	INVSERIAL_ID NUMBER(38,0),
	SOJ_ID NUMBER(38,0),
	JOB_NUMBER NUMBER(38,0),
	CUSTOMER_CONTACT VARCHAR(61),
	TELEPHONE VARCHAR(30),
	PROBLEM_TEXT VARCHAR(16777216),
	SERVICE_ROUTINE_ID NUMBER(38,0),
	TASK_TEXT VARCHAR(16777216),
	CAUSE_DESCRIPTION VARCHAR(50),
	CAUSE_TEXT VARCHAR(16777216),
	ORDER_REFERENCE VARCHAR(30),
	INVOICED_FLAG BOOLEAN,
	ASSIGN_LOCAL_DATE_KEY NUMBER(38,0),
	ASSIGN_LOCAL_TIME_KEY NUMBER(38,0),
	RESPONSE_LOCAL_DATE_KEY  NUMBER(38,0),
	RESPONSE_LOCAL_TIME_KEY  NUMBER(38,0),
	SCHEDULED_START_LOCAL_DATE_KEY  NUMBER(38,0),
	SCHEDULED_START_LOCAL_TIME_KEY  NUMBER(38,0),
	CREATED_LOCAL_DATE_KEY  NUMBER(38,0),
	CREATED_LOCAL_TIME_KEY  NUMBER(38,0),
	CREATED_BY_KEY NUMBER(38,0),
	MODIFIED_BY_KEY NUMBER(38,0),
	CLOSED_LOCAL_DATE_KEY  NUMBER(38,0),
	CLOSED_LOCAL_TIME_KEY  NUMBER(38,0),
	CLOSED_BY VARCHAR(50),
	JOB_CLOSED VARCHAR(6),
	FINANCIAL_STATUS VARCHAR(50),
	JOB_TYPE NUMBER(38,0),
	JOB_CATEGORY VARCHAR(50),
	JOB_CATEGORY_SHORT_NAME VARCHAR(10),
	PROBLEM_SHORT_CODE VARCHAR(10),
	PROBLEM_DESCRIPTION VARCHAR(50),
	PROBLEM_TAG VARCHAR(16777216),
	PROBLEM_CODE VARCHAR(50),
	ASSIGNED_TO_PERSONNEL_KEY NUMBER(38,0),
	JOB_STATUS_NAME VARCHAR(50),
	JOB_STATUS_TYPE VARCHAR(14),
	SERVICE_ROUTINE_FKEY NUMBER(38,0),
	CLASSIFICATION NUMBER(38,0),
	CLOSED_FLAG BOOLEAN,
	CUSTOMER_SITE_ID NUMBER(38,0),
	IS_CALL_OUT VARCHAR(50),
	PROBLEMMEMO VARCHAR(16777216),
	HAS_REAL_FIXTIME NUMBER(1,0),
	ACTUAL_FIX_LOCAL_DATE_KEY NUMBER(38,0),
	ACTUAL_FIX_LOCAL_TIME_KEY NUMBER(38,0),
	AGREEMENTID NUMBER(38,0),
	AGREEMENT_FKEY NUMBER(38,0),
	SERVICE_RESOLUTION_DESCRIPTION VARCHAR(50),
	AGREEMENT VARCHAR(30),
	QUOTE_REFERENCE VARCHAR(20),
	SERIAL_NUMBER VARCHAR(25),
	EQUIPMENT_HIERARCHY VARCHAR(30),
	SERVICE_SCHEME_ID NUMBER(38,0),
	WARRANTY_SUPPLIER_ID NUMBER(38,0),
	AS_PER_SERVICE_SCHEME_ID NUMBER(38,0),
	AS_PER_QUOTATION_ID NUMBER(38,0),
	AS_PER_SALES_ORDER_ID NUMBER(38,0),
	ORDER_REF VARCHAR(30),
	SERVICE_RESOLUTION_ID NUMBER(38,0),
	ASSIGNED_TO_TEAM_ID NUMBER(38,0),
	AUTOBOOK_VIA_SCHEDULER NUMBER(38,0),
	USE_AUTO_SCHEDULER NUMBER(38,0),
	EXTERNAL_REFERENCE VARCHAR(50),
	CLOSURE_EMAIL_SENT NUMBER(38,0),
	AGREEMENT_SERVICE_SCHEME_ID NUMBER(38,0),
	VOUCHERS_ALLOW_TYPE NUMBER(38,0),
	VOUCHER_DEALLOC_TYPE NUMBER(38,0),
	JEOPARDY_ID NUMBER(38,0),
	SLA_PERFORMANCE_STATUS_ID NUMBER(38,0),
	SLA_VARIANCE_REASON_ID NUMBER(38,0),
	SLA_VARIANCE_MEMO VARCHAR(16777216),
	SLA_SUSPEND_DATE_TIME TIMESTAMP_NTZ(9),
	SLA_SUSPEND_CUM_MINS NUMBER(38,0),
	SS_ASSIGN_DURATION FLOAT,
	SS_DEPART_DURATION FLOAT,
	SS_RESPONSE_DURATION FLOAT,
	SS_FIX_DURATION FLOAT,
	SS_SHIP_DURATION FLOAT,
	REFERENCE VARCHAR(30),
	DEP_CHECKLIST_DEFINTION_ID NUMBER(38,0),
	ARR_CHECKLIST_DEFINITION_ID NUMBER(38,0),
	COMP_CHECKLIST_DEFINITION_ID NUMBER(38,0),
	BROKEN_APPOINTMENT_COUNT NUMBER(38,0),
	RECORD_TIMESTAMP VARCHAR(100),
	PROCESS_EXEC_ID VARCHAR(100),
	LOAD_TS TIMESTAMP_NTZ(9),
	LOAD_FILE VARCHAR(100)
)comment ='FACT_SV_SERVICE_ORDERS_JOBS';


CREATE OR REPLACE PROCEDURE "RAW"."PROC_LOAD_FACT_SV_SERVICE_ORDERS_JOBS"(PIPELINE_RUN_ID VARCHAR, PIPELINE_NAME VARCHAR)
    RETURNS string
    LANGUAGE javascript
    strict
    EXECUTE AS CALLER 
    AS
    $$
        snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PIPELINE_RUN_ID+"','"+PIPELINE_NAME+"','ref2fact'))"});
    	snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} ); 

		var stmt = snowflake.createStatement({
                   sqlText: "insert overwrite into RAW.Fact_SV_Service_Orders_Jobs select SVSOJ.\"UID\" as SOJ_Key,common.resolve_unknown_dims(DS.Site_Key) as Site_FKey	,common.resolve_unknown_dims(DT.date_key) as SO_Created_Date_Key	,common.resolve_unknown_dims(TM.time_key)	as 	SO_Created_Time_Key	,SVSO.\"CustomerSiteID\"	as 	SO_Customer_Site_Id	,common.resolve_unknown_dims(DT1.date_key) as 	SO_Closed_Date_Key	,common.resolve_unknown_dims(TM1.time_key) as 	SO_Closed_Time_Key	,SVSO.\"RecordStatusID\"	as 	SO_Record_Status_Id	,SVSO.\"REFERENCE\"	as 	SO_Reference	,SVSOJ.\"ServiceOrderID\"	as 	Service_order_id	,SVSOJ.\"CustomerDeptID\"	as 	Customer_dept_id	,SVSOJ.\"CustomerEquipmentID\"	as 	Customer_equipment_id	,SVSOJ.\"CustomerEquipmentModuleID\"	as 	Customer_equipment_module_id	,SVSOJ.\"ProductID\"	as 	Product_ID	,common.resolve_unknown_dims(product_key)	as 	Product_fkey	,SVSOJ.\"InvSerialID\"	as 	InvSerial_ID	,SVSOJ.\"UID\"	as 	SOJ_ID	,SVSOJ.\"JobNumber\"	as 	Job_Number	,PRSNL.\"FirstName\" || ' ' || PRSNL.\"LastName\" as Customer_Contact	,SVSOJ.\"Telephone\"	as 	Telephone	,SVSOJ.\"ProblemText\"	as 	Problem_text	,SVSOJ.\"ServiceRoutineID\"	as 	Service_Routine_ID	,SVSOJ.\"TaskText\"	as 	Task_text	,SVCS.\"Description\"	as 	Cause_Description	,SVSOJ.\"CauseText\"	as 	Cause_Text	,SVSOJ.\"OrderRef\"	as 	Order_Reference	,SVSOJ.\"InvoicedFlag\"	as 	Invoiced_Flag	,common.resolve_unknown_dims(DT2.date_key)	as 	Assign_Local_Date_Key 	,common.resolve_unknown_dims(TM2.time_key)	as 	ASSIGN_LOCAL_TIME_KEY	,common.resolve_unknown_dims(DT3.date_key)	as 	RESPONSE_LOCAL_DATE_KEY	,common.resolve_unknown_dims(TM3.time_key)	as 	RESPONSE_LOCAL_TIME_KEY	,common.resolve_unknown_dims(DT4.date_key)	as 	SCHEDULED_START_LOCAL_DATE_KEY	, common.resolve_unknown_dims(TM4.time_key)	as 	SCHEDULED_START_LOCAL_TIME_KEY	,common.resolve_unknown_dims(DT5.date_key)	as 	CREATED_LOCAL_DATE_KEY	,common.resolve_unknown_dims(TM5.time_key)	as 	CREATED_LOCAL_TIME_KEY	,common.resolve_unknown_dims(SVU.User_key)	as 	Created_by_key	, common.resolve_unknown_dims(SVU1.User_key)	as 	Modified_by_key	,common.resolve_unknown_dims(DT6.date_key)	as 	CLOSED_LOCAL_DATE_KEY	,common.resolve_unknown_dims(TM6.time_key)	as 	CLOSED_LOCAL_TIME_KEY	,PRSNL1.\"ShortName\"	as 	Closed_By	,case when SVSOJ.\"ClosedFlag\"=0 THEN 'Open' ELSE 'Closed' END as Job_Closed	,SVCTMSOJC.\"Name\" as 	Financial_Status	, SVSOJ.\"JobType\"	as 	Job_Type	,SVSOJC.\"Category\"	as 	Job_Category	,SVSOJC.\"ShortName\"	as 	Job_Category_Short_Name	,SVPRBLM.\"ShortCode\"	as 	Problem_Short_Code	,SVPRBLM.\"Description\"	as 	Problem_Description	,replace(SVSOJ.\"ProblemText\",'#',' ')	as 	Problem_Tag	,SVPRBLM.\"Description\"	as 	Problem_Code	,common.resolve_unknown_dims(DSVPRSNL.Personnel_Key)	as 	Assigned_To_Personnel_key	,SVSOJS1.\"Name\"	as 	Job_Status_Name	,case when Job_Status_Name in ('Completed','Completed (Suspended)','Fixed Service/Restored','Fixed/Service Restored','Returning') then 'Done' when Job_Status_Name in ('Cancelled Job - No Longer Reqd ','Unsafe','Unsfafe') then 'NtDn' when Job_Status_Name in ('Awaiting Completion','Awaiting Parts','Hold - client approval','Hold - engineering','Hold - land management','Hold - spares client','Hold - spares ordered','Hold - spares required','In Progress','No Spares','Suspended','Work Not Complete','Work Not Completed') then 'Part' when Job_Status_Name in ('Adverse Weather','Allocation Cancelled','Called Elsewhere','Cancelling Allocation','No Access','Rejected') then 'ReSchd' when Job_Status_Name in ('Accepted','Allocated','Allocated & Despatched','Arrived','Departed','Outstanding','Waiting/On Break') then 'Schd' else NVL2(Job_Status_Name,'No Status Type','Plan') end as 	Job_Status_Type	,common.resolve_unknown_dims(SVSR.service_routine_key)	as 	Service_routine_fkey	,SVSOJ.\"Classification\"	as 	Classification	,SVSOJ.\"ClosedFlag\"	as 	Closed_Flag	,SVSO.\"CustomerSiteID\"	as 	Customer_Site_ID	,SVCLJL.\"CallOut\"	as 	Is_Call_Out	,SVCLJL.\"ProblemMemo\"	as 	ProblemMemo	,case when Year(SVSOJ.\"FixTime\")<2000 THEN 0 ELSE 1 END as 	Has_real_fixtime	,common.resolve_unknown_dims(DT7.date_key)	as 	Actual_fix_Local_date_key	,common.resolve_unknown_dims(TM7.time_key)	as 	Actual_fix_Local_time_key	,SVSOJ.\"AgreementID\"	as 	AgreementID	,common.resolve_unknown_dims(SVA.agreement_key)	as 	Agreement_fkey	,SVSRSLTNS.\"Description\"	as 	Service_Resolution_Description	,SVA2.\"Reference\"	as 	Agreement	,SVQ.REFERENCE	as 	Quote_Reference	,SVCE.\"SerialNumber\"	as 	Serial_Number	,SVCE.\"Location\"	as 	Equipment_hierarchy	,SVSOJ.\"ServiceSchemeID\"	as 	Service_Scheme_ID	,SVSOJ.\"WarrantySupplierID\"	as 	Warranty_Supplier_ID	,SVSOJ.\"AsPerServiceSchemeID\"	as 	As_Per_Service_Scheme_ID	,SVSOJ.\"AsPerQuotationID\"	as 	As_Per_Quotation_ID	,SVSOJ.\"AsPerSalesOrderID\"	as 	As_Per_Sales_Order_ID	,SVSOJ.\"OrderRef\"	as 	Order_Ref	,SVSOJ.\"ServiceResolutionID\"	as 	Service_Resolution_ID	,SVSOJ.\"AssignedToTeamID\"	as 	Assigned_To_Team_ID	,SVSOJ.\"AutoBookViaScheduler\"	as 	Autobook_Via_Scheduler	,SVSOJ.\"UseAutoScheduler\"	as 	Use_Auto_Scheduler	,SVSOJ.\"ExternalReference\"	as 	External_Reference	,SVSOJ.\"ClosureEmailSent\"	as 	Closure_Email_Sent	,SVSOJ.\"AgreementServiceSchemeID\"	as 	Agreement_Service_Scheme_ID	,SVSOJ.\"VouchersAllowType\"	as 	Vouchers_Allow_Type	,SVSOJ.\"VouchersDeAllocType\"	as 	Voucher_DeAlloc_Type	,SVSOJ.\"JeopardyID\"	as 	Jeopardy_ID	,SVSOJ.\"SLAPerformanceStatusID\"	as 	SLA_Performance_Status_ID	,SVSOJ.\"SLAVarianceReasonID\"	as 	SLA_Variance_Reason_ID	,SVSOJ.\"SLAVarianceMemo\"	as 	SLA_Variance_Memo	,SVSOJ.\"SLASuspendDateTime\"	as 	SLA_Suspend_Date_Time	,SVSOJ.\"SLASuspendCumMins\"	as 	SLA_Suspend_Cum_Mins	,SVSOJ.\"SSAssignDuration\"	as 	SS_Assign_Duration	,SVSOJ.\"SSDepartDuration\"	as 	SS_Depart_Duration	,SVSOJ.\"SSResponseDuration\"	as 	SS_Response_Duration	,SVSOJ.\"SSFixDuration\"	as 	SS_Fix_Duration	,SVSOJ.\"SSShipDuration\"	as 	SS_Ship_Duration	,SVSOJ.\"REFERENCE\"	as 	Reference	, SVSOJ.\"DepChecklistDefinitionID\"	as 	Dep_Checklist_Defintion_ID	, SVSOJ.\"ArrChecklistDefinitionID\"	as 	Arr_Checklist_Definition_ID	, SVSOJ.\"CompChecklistDefinitionID\"	as 	Comp_Checklist_Definition_ID	, SVSOJ.\"BrokenAppointmentCount\"	as 	Broken_Appointment_Count	, SVSOJ.\"RecordTimeStamp\"	as 	Record_Timestamp	,  '"+PIPELINE_RUN_ID+"' as 	Process_exec_id	, sysdate()	as 	Load_ts	, SVSOJ.\"LOAD_FILE\"	as 	Load_file	 from  \"REFERENCE\".\"SV_ServiceOrdersJobs\" SVSOJ left join \"REFERENCE\".\"SV_ServiceOrders\" SVSO on SVSOJ.\"ServiceOrderID\"= SVSO.UID left join \"REFERENCE\".\"SV_Customers\" SVC on SVSO.\"CustomerID\"=SVC.\"UID\"  left join \"CURATED\".Dim_Sites DS on TRIM(SVC.\"ShortCode\")=DS.O_M_Reference_Formula  left join CURATED.Dim_Calendar_Date DT on (SVSO.\"CreatedDate\"=DT.date)  left join curated.dim_calendar_time TM on (SVSO.\"CreatedTime\"=TM.time)  left join CURATED.Dim_Calendar_Date DT1 on (SVSO.\"ClosedDate\"=DT1.date)  left join curated.dim_calendar_time TM1 on (TIME(SVSO.\"ClosedTime\")=TM1.time)  left join CURATED.Dim_SV_Products SVP on SVSOJ.\"ProductID\"=SVP.product_id  left join \"REFERENCE\".\"SV_Personnel\" PRSNL on SVSOJ.\"CustomerContactID\"=PRSNL.UID  left join  \"REFERENCE\".\"SV_Causes\" SVCS on SVSOJ.\"CauseID\"=SVCS.UID  left join CURATED.Dim_Calendar_Date DT2 on  DATE(SVSOJ.\"AssignTime\")=DT2.date  left join CURATED.Dim_Calendar_Time TM2 on TIME(SVSOJ.\"AssignTime\")=TM2.time  left join CURATED.Dim_Calendar_Date DT3 on  DATE(SVSOJ.\"ResponseTime\")=DT3.date  left join CURATED.Dim_Calendar_Time TM3 on TIME(SVSOJ.\"ResponseTime\")=TM3.time  left join CURATED.Dim_Calendar_Date DT4 on  DATE(SVSOJ.\"ScheduledStart\")=DT4.date  left join CURATED.Dim_Calendar_Time TM4 on TIME(SVSOJ.\"ScheduledStart\")=TM4.time  left join CURATED.Dim_Calendar_Date DT5 on  DATE(SVSOJ.\"CreatedDate\")=DT5.date  left join CURATED.Dim_Calendar_Time TM5 on SVSOJ.\"CreatedTime\"=TM5.time  left join CURATED.Dim_SV_Users SVU on SVSOJ.\"CreatedByID\"=SVU.user_id  left join CURATED.Dim_SV_Users SVU1 on SVSOJ.\"ModifiedByID\"=SVU1.user_id  left join CURATED.Dim_Calendar_Date DT6 on  DATE(SVSOJ.\"SOJClosedDate\")=DT6.date  left join CURATED.Dim_Calendar_Time TM6 on TIME(SVSOJ.\"SOJClosedDate\")=TM6.time  left join \"REFERENCE\".\"SV_Personnel\" PRSNL1 on SVSOJ.\"SOJClosedByID\"=PRSNL1.UID  left join REFERENCE.\"SV_CTM_ServiceOrdersJobsChgS\" SVCTMSOJC on SVSOJ.\"ChargeStatusID\"=SVCTMSOJC.UID  left join \"REFERENCE\".\"SV_ServiceOrdersJobsStatus\" SVSOJS on  SVSOJ.\"JobCategoryID\"=SVSOJS.UID  left join \"REFERENCE\".\"SV_Problems\" SVPRBLM on SVSOJ.\"ProblemID\"=SVPRBLM.UID  left join CURATED.Dim_SV_Personnel DSVPRSNL on SVSOJ.\"AssignedToPersonnelID\"=DSVPRSNL.Personnel_ID  left join \"REFERENCE\".\"SV_ServiceOrdersJobsStatus\" SVSOJS1 on SVSOJ.\"JobStatusID\"=SVSOJS1.UID  left join CURATED.Dim_SV_Service_Routines SVSR on SVSOJ.\"ServiceRoutineID\"=SVSR.service_routine_id  left join CURATED.Dim_Calendar_Date DT7 on  DATE(SVSOJ.\"FixTime\")=DT7.date  left join CURATED.Dim_Calendar_Time TM7 on TIME(SVSOJ.\"FixTime\")=TM7.time  left join \"REFERENCE\".\"SV_ServiceOrdersJobsCats\" SVSOJC on SVSOJ.\"JobCategoryID\"=SVSOJC.UID  left join \"REFERENCE\".\"SV_CTM_LS_JobList\" SVCLJL on SVSOJ.\"JobNumber\"=SVCLJL.\"JobNumber\"  left join CURATED.Dim_SV_Agreements SVA on SVSOJ.\"AgreementID\"=SVA.agreement_id left join \"REFERENCE\".\"SV_ServiceResolutions\" SVSRSLTNS on SVSOJ.\"ServiceResolutionID\"=SVSRSLTNS.UID left join REFERENCE.\"SV_Agreements\" SVA2 on SVSOJ.\"AgreementID\"=SVA2.UID left join (select UID,\"REFERENCE\" as REFERENCE from \"REFERENCE\".\"SV_Quotations\" where \"DocumentTypeID\"=2) SVQ on SVSO.\"DocumentID\"=SVQ.UID left join \"REFERENCE\".\"SV_CustomersEquipment\" SVCE on SVSOJ.\"CustomerEquipmentID\"=SVCE.UID  where Job_Status_Name <> 'Cancelled Job – No Longer Reqd'"
               });  
        var rs = stmt.execute();
        rs.next();
        rowsInserted = rs.getColumnValue(1);
        
        snowflake.execute( {sqlText: "COMMIT WORK;"} );
		  
	snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )

	return JSON.stringify({"Rows inserted":rowsInserted});
        
        $$
       ; 