use database data_lake_{{ db }};
use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

alter table RAW.FACT_SITE_MEASUREMENTS
add column local_date_key NUMBER(38,0);

alter table RAW.FACT_SITE_MEASUREMENTS
add column local_time_key NUMBER(38,0);

alter table RAW.FACT_SITE_MEASUREMENTS
add column local_date DATE;


alter table RAW.FACT_SITE_MEASUREMENTS
add column local_time TIME(9);