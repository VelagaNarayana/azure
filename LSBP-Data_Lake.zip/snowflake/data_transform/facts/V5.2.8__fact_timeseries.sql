use database data_lake_{{ db }};
use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

CREATE OR REPLACE PROCEDURE "RAW"."PROC_LOAD_FACT_TS_MEASUREMENTS"(QUERY_SOURCE VARCHAR,DATA_SOURCE VARCHAR,SOURCE_FILTER_OR_PATH VARCHAR,HISTORY_LOAD BOOLEAN ,PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller
AS
$$
	snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','InsolarStage2fact'))"});
	snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );

	var transientTableSql;
	var transientTableName = "COMMON.\"TRANS_FACT_TS_MSRMNTS_"+PROCESS_RUN_ID+"\"";
	var rowsUpdated = 0, multiJoinUpdated = 0, rowsInserted=0;
    
    var stmt = snowflake.createStatement({
		sqlText: "select fact_table,common.replace_query(parse_query,'"+SOURCE_FILTER_OR_PATH+"','"+DATA_SOURCE+"','"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"') from control.fact_table_load_queries where data_source= ? and query_source= ?",
        binds:[DATA_SOURCE,QUERY_SOURCE]
	});  
    var rs = stmt.execute();
    var factTable, query;
    if(rs.next()){
        factTable = rs.getColumnValue(1);
        query = rs.getColumnValue(2);
    } else {
        throw "Parsing for source system - "+DATA_SOURCE+" not configured in the table CONTROL.FACT_TABLE_LOAD_QUERIES"
    };
    
	transientTableSql = " CREATE OR REPLACE transient TABLE "+transientTableName+" AS WITH new_msrmnts AS ( "+query+" ) SELECT source_data.*,local_dim_dt.date as local_date,local_dim_tm.time as local_time, common.resolve_unknown_dims(local_dim_dt.date_key) AS local_date_key,common.resolve_unknown_dims(local_dim_tm.time_key) AS local_time_key FROM ( SELECT common.Resolve_unknown_dims(site.site_key) AS skey, common.Resolve_unknown_dims(device.device_key) AS dkey, common.Resolve_unknown_dims(measurement.measurement_key) AS mkey, common.resolve_unknown_dims(dt.date_key) AS date_key,common.resolve_unknown_dims(tm.time_key) AS time_key, dt.date AS dt, tm.time AS tmin, common.convert_to_local_tz(dt.date,new_msrmnts.msrmnt_time_in_min,new_msrmnts.source_data_tz,site.derived_timezone) as local_datetime,to_date(local_datetime) as local_dt,to_time(local_datetime) as local_tm,new_msrmnts.msrmnt_ts AS ts, new_msrmnts.msrmnt_id AS id, CASE WHEN LOWER(measurement.data_type) IN ('integer','float') THEN to_double(new_msrmnts.value) ELSE null END AS measurement_value_numeric, CASE WHEN LOWER(measurement.data_type) NOT IN ('integer','float') OR measurement.data_type IS NULL THEN new_msrmnts.value::string ELSE null END AS measurement_value_string, '"+DATA_SOURCE+"' AS data_source,new_msrmnts.process_exec_id, new_msrmnts.filename, new_msrmnts.file_arrival_date FROM new_msrmnts LEFT JOIN curated.dim_measurements measurement ON common.Resolve_missing_dims(new_msrmnts.msrmnt_id) = measurement.measurement_id LEFT JOIN curated.dim_devices device ON measurement.device_fkey = device.device_key LEFT JOIN curated.dim_sites site ON device.site_fkey = site.site_key  LEFT JOIN curated.dim_calendar_date dt ON new_msrmnts.msrmnt_date = dt.date  LEFT JOIN curated.dim_calendar_time tm ON new_msrmnts.msrmnt_time_in_min = tm.time ) source_data LEFT JOIN curated.dim_calendar_date local_dim_dt ON source_data.local_dt = local_dim_dt.date LEFT JOIN curated.dim_calendar_time local_dim_tm ON source_data.local_tm = local_dim_tm.time ";

	snowflake.execute({ sqlText:transientTableSql});
	snowflake.execute( {sqlText: "BEGIN WORK;"} );

	try{

 
        if(HISTORY_LOAD == false)
        {
            stmt = snowflake.createStatement({
              sqlText: " UPDATE "+factTable+" fact SET site_key = temp.skey, device_key = temp.dkey, measurement_key = temp.mkey, date_key = temp.date_key, time_key = temp.time_key, local_date_key = temp.local_date_key, local_time_key = temp.local_time_key, mdate = temp.dt, mtime = temp.tmin, local_date = temp.local_date,local_time = temp.local_time, measurement_value_numeric = temp.measurement_value_numeric, measurement_value_string = temp.measurement_value_string, updated_ts = Sysdate(), process_exec_id = temp.process_exec_id, load_file = temp.filename FROM   "+transientTableName+" temp WHERE  fact.original_measurement_id = temp.id AND fact.original_measurement_ts = temp.ts AND fact.data_source = ? ",
            binds:[DATA_SOURCE]
            });  
        }else{
        
            stmt = snowflake.createStatement({
              sqlText: " UPDATE "+factTable+" fact SET site_key = temp.skey, device_key = temp.dkey, measurement_key = temp.mkey, date_key = temp.date_key, time_key = temp.time_key, local_date_key = temp.local_date_key, local_time_key = temp.local_time_key, mdate = temp.dt,mtime = temp.tmin,  local_date = temp.local_date,local_time = temp.local_time, measurement_value_numeric = temp.measurement_value_numeric, measurement_value_string = temp.measurement_value_string, updated_ts = Sysdate(), process_exec_id = temp.process_exec_id, load_file = temp.filename FROM (SELECT *, Row_number() OVER ( partition BY id, ts ORDER BY file_arrival_date DESC) AS row_num FROM   "+transientTableName+") temp WHERE  row_num = 1 AND fact.original_measurement_id = temp.id AND fact.original_measurement_ts = temp.ts AND fact.data_source = ? ",
            binds:[DATA_SOURCE]
            });                  
        }

        var rs = stmt.execute();
		rs.next();
		rowsUpdated = rs.getColumnValue(1);
		multiJoinUpdated = rs.getColumnValue(2);

        if(HISTORY_LOAD == false)
        {
            stmt = snowflake.createStatement({
            sqlText: "INSERT INTO "+factTable+" (site_key, device_key, measurement_key, date_key, time_key,local_date_key,local_time_key, mdate, mtime,local_date,local_time, measurement_value_numeric, measurement_value_string, original_measurement_id, original_measurement_ts, data_source, created_ts, updated_ts, process_exec_id, load_file) SELECT temp.skey, temp.dkey, temp.mkey, temp.date_key, temp.time_key,temp.local_date_key,temp.local_time_key, temp.dt AS MDATE, temp.tmin AS MTIME, temp.local_date,temp.local_time,temp.measurement_value_numeric, temp.measurement_value_string, temp.id, temp.ts, temp.data_source, Sysdate() AS CREATED_TS, Sysdate() AS UPDATED_TS, temp.process_exec_id AS process_exec_id, temp.filename FROM "+transientTableName+" temp LEFT JOIN (SELECT measurement_key, mdate, mtime, original_measurement_id, original_measurement_ts FROM "+factTable+" WHERE  mdate BETWEEN (SELECT Min(dt) AS mindt FROM "+transientTableName+") AND ( SELECT Max(dt) AS maxdt FROM "+transientTableName+" ) AND data_source = ?) fact ON temp.id = fact.original_measurement_id AND temp.ts = fact.original_measurement_ts WHERE  fact.measurement_key IS NULL ",
            binds:[DATA_SOURCE]
            });
        }else{

            stmt = snowflake.createStatement({
            sqlText: "INSERT INTO "+factTable+" (site_key, device_key, measurement_key, date_key, time_key, local_date_key,local_time_key,mdate, mtime,local_date,local_time, measurement_value_numeric, measurement_value_string, original_measurement_id, original_measurement_ts, data_source, created_ts, updated_ts, process_exec_id, load_file) WITH temp_ts AS (SELECT *, Row_number() over( PARTITION BY id, ts ORDER BY file_arrival_date DESC) AS row_num FROM "+transientTableName+") SELECT temp.skey, temp.dkey, temp.mkey, temp.date_key, temp.time_key,temp.local_date_key,temp.local_time_key, temp.dt AS MDATE, temp.tmin AS MTIME,local_date,local_time, temp.measurement_value_numeric, temp.measurement_value_string, temp.id, temp.ts, temp.data_source, SYSDATE() AS CREATED_TS, SYSDATE() AS UPDATED_TS, temp.process_exec_id AS process_exec_id, temp.filename FROM (SELECT * FROM temp_ts WHERE row_num = 1 ) temp left join (SELECT measurement_key, mdate, mtime, original_measurement_id, original_measurement_ts FROM "+factTable+" WHERE  mdate BETWEEN (SELECT Min(dt) AS mindt FROM   "+transientTableName+") AND ( SELECT Max(dt) AS maxdt FROM "+transientTableName+" ) AND data_source = ?) fact ON temp.id = fact.original_measurement_id AND temp.ts = fact.original_measurement_ts WHERE  fact.measurement_key IS NULL ",
            binds:[DATA_SOURCE]
            });        
        }

        rs = stmt.execute();
		rs.next();
		rowsInserted = rs.getColumnValue(1);

		snowflake.execute( {sqlText: "DROP TABLE "+transientTableName+";"} );
		snowflake.execute( {sqlText: "COMMIT WORK;"} );
	}
	catch(err){
		snowflake.execute( {sqlText: "ROLLBACK WORK;"} );
		rowsInserted=rowsUpdated=multiJoinUpdated=-1;
		throw err;
	}
	finally{
		snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
	}
	return JSON.stringify({"Rows inserted":rowsInserted,"Rows updated":rowsUpdated,"Multi-join updates":multiJoinUpdated});
$$;

