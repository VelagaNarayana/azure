use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

-- DDL for FACT_SV_SERVICE_ORDERS_JOBS
create or replace TRANSIENT TABLE RAW.FACT_SV_SERVICE_ORDERS_JOBS (
	SOJ_KEY NUMBER(38,0),
	SITE_FKEY NUMBER(38,0),
	SO_CREATED_DATE_KEY NUMBER(38,0),
	SO_CREATED_TIME_KEY NUMBER(38,0),
	SO_CUSTOMER_SITE_ID NUMBER(38,0),
	SO_CLOSED_DATE_KEY NUMBER(38,0),
	SO_CLOSED_TIME_KEY NUMBER(38,0),
	SO_RECORD_STATUS_ID NUMBER(38,0),
	SO_REFERENCE VARCHAR(20),
	SERVICE_ORDER_ID NUMBER(38,0),
	CUSTOMER_DEPT_ID NUMBER(38,0),
	CUSTOMER_EQUIPMENT_ID NUMBER(38,0),
	CUSTOMER_EQUIPMENT_MODULE_ID NUMBER(38,0),
	PRODUCT_ID NUMBER(38,0),
	PRODUCT_FKEY NUMBER(38,0),
	INVSERIAL_ID NUMBER(38,0),
	SOJ_ID NUMBER(38,0),
	JOB_NUMBER NUMBER(38,0),
	CUSTOMER_CONTACT VARCHAR(61),
	TELEPHONE VARCHAR(30),
	PROBLEM_TEXT VARCHAR(16777216),
	SERVICE_ROUTINE_ID NUMBER(38,0),
	TASK_TEXT VARCHAR(16777216),
	CAUSE_DESCRIPTION VARCHAR(50),
	CAUSE_TEXT VARCHAR(16777216),
	ORDER_REFERENCE VARCHAR(30),
	INVOICED_FLAG BOOLEAN,
	ASSIGN_DATE_KEY NUMBER(38,0),
	ASSIGN_TIME_KEY NUMBER(38,0),
	RESPONSE_DATE_KEY NUMBER(38,0),
	RESPONSE_TIME_KEY NUMBER(38,0),
	SCHEDULED_START_DATE_KEY NUMBER(38,0),
	SCHEDULED_START_TIME_KEY NUMBER(38,0),
	CREATED_DATE_KEY NUMBER(38,0),
	CREATED_TIME_KEY NUMBER(38,0),
	CREATED_BY_KEY NUMBER(38,0),
	MODIFIED_BY_KEY NUMBER(38,0),
	CLOSED_DATE_KEY NUMBER(38,0),
	CLOSED_TIME_KEY NUMBER(38,0),
	CLOSED_BY VARCHAR(50),
	JOB_CLOSED VARCHAR(6),
	FINANCIAL_STATUS VARCHAR(50),
	JOB_TYPE NUMBER(38,0),
	JOB_CATEGORY VARCHAR(50),
	JOB_CATEGORY_SHORT_NAME VARCHAR(10),
	PROBLEM_SHORT_CODE VARCHAR(10),
	PROBLEM_DESCRIPTION VARCHAR(50),
	PROBLEM_TAG VARCHAR(16777216),
	PROBLEM_CODE VARCHAR(50),
	ASSIGNED_TO_PERSONNEL_KEY NUMBER(38,0),
	JOB_STATUS_NAME VARCHAR(50),
	JOB_STATUS_TYPE VARCHAR(14),
	SERVICE_ROUTINE_FKEY NUMBER(38,0),
	CLASSIFICATION NUMBER(38,0),
	CLOSED_FLAG BOOLEAN,
	CUSTOMER_SITE_ID NUMBER(38,0),
	IS_CALL_OUT VARCHAR(50),
	PROBLEMMEMO VARCHAR(16777216),
	HAS_REAL_FIXTIME NUMBER(1,0),
	ACTUAL_FIX_LOCAL_DATE_KEY NUMBER(38,0),
	ACTUAL_FIX_LOCAL_TIME_KEY NUMBER(38,0),
	AGREEMENTID NUMBER(38,0),
	AGREEMENT_FKEY NUMBER(38,0),
	SERVICE_RESOLUTION_DESCRIPTION VARCHAR(50),
	AGREEMENT VARCHAR(30),
	QUOTE_REFERENCE VARCHAR(20),
	SERIAL_NUMBER VARCHAR(25),
	EQUIPMENT_HIERARCHY VARCHAR(30),
	SERVICE_SCHEME_ID NUMBER(38,0),
	WARRANTY_SUPPLIER_ID NUMBER(38,0),
	AS_PER_SERVICE_SCHEME_ID NUMBER(38,0),
	AS_PER_QUOTATION_ID NUMBER(38,0),
	AS_PER_SALES_ORDER_ID NUMBER(38,0),
	ORDER_REF VARCHAR(30),
	SERVICE_RESOLUTION_ID NUMBER(38,0),
	ASSIGNED_TO_TEAM_ID NUMBER(38,0),
	AUTOBOOK_VIA_SCHEDULER NUMBER(38,0),
	USE_AUTO_SCHEDULER NUMBER(38,0),
	EXTERNAL_REFERENCE VARCHAR(50),
	CLOSURE_EMAIL_SENT NUMBER(38,0),
	AGREEMENT_SERVICE_SCHEME_ID NUMBER(38,0),
	VOUCHERS_ALLOW_TYPE NUMBER(38,0),
	VOUCHER_DEALLOC_TYPE NUMBER(38,0),
	JEOPARDY_ID NUMBER(38,0),
	SLA_PERFORMANCE_STATUS_ID NUMBER(38,0),
	SLA_VARIANCE_REASON_ID NUMBER(38,0),
	SLA_VARIANCE_MEMO VARCHAR(16777216),
	SLA_SUSPEND_DATE_TIME TIMESTAMP_NTZ(9),
	SLA_SUSPEND_CUM_MINS NUMBER(38,0),
	SS_ASSIGN_DURATION FLOAT,
	SS_DEPART_DURATION FLOAT,
	SS_RESPONSE_DURATION FLOAT,
	SS_FIX_DURATION FLOAT,
	SS_SHIP_DURATION FLOAT,
	REFERENCE VARCHAR(30),
	DEP_CHECKLIST_DEFINTION_ID NUMBER(38,0),
	ARR_CHECKLIST_DEFINITION_ID NUMBER(38,0),
	COMP_CHECKLIST_DEFINITION_ID NUMBER(38,0),
	BROKEN_APPOINTMENT_COUNT NUMBER(38,0),
	RECORD_TIMESTAMP VARCHAR(100),
	PROCESS_EXEC_ID VARCHAR(100),
	LOAD_TS TIMESTAMP_NTZ(9),
	LOAD_FILE VARCHAR(100)
)comment ='FACT_SV_SERVICE_ORDERS_JOBS';

--  SP for FACT_SV_SERVICE_ORDERS_JOBS
CREATE OR REPLACE PROCEDURE "RAW"."PROC_LOAD_FACT_SV_SERVICE_ORDERS_JOBS"(PIPELINE_RUN_ID VARCHAR, PIPELINE_NAME VARCHAR)
    RETURNS string
    LANGUAGE javascript
    strict
    EXECUTE AS CALLER 
    AS
    $$
        snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PIPELINE_RUN_ID+"','"+PIPELINE_NAME+"','ref2fact'))"});
    	snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} ); 

		var stmt = snowflake.createStatement({
                   sqlText: "insert overwrite into RAW.Fact_SV_Service_Orders_Jobs select SVSOJ.\"UID\" as SOJ_Key,common.resolve_unknown_dims(DS.Site_Key) as Site_FKey	,common.resolve_unknown_dims(DT.date_key) as SO_Created_Date_Key	,common.resolve_unknown_dims(TM.time_key)	as 	SO_Created_Time_Key	,SVSO.\"CustomerSiteID\"	as 	SO_Customer_Site_Id	,common.resolve_unknown_dims(DT1.date_key) as 	SO_Closed_Date_Key	,common.resolve_unknown_dims(TM1.time_key) as 	SO_Closed_Time_Key	,SVSO.\"RecordStatusID\"	as 	SO_Record_Status_Id	,SVSO.\"REFERENCE\"	as 	SO_Reference	,SVSOJ.\"ServiceOrderID\"	as 	Service_order_id	,SVSOJ.\"CustomerDeptID\"	as 	Customer_dept_id	,SVSOJ.\"CustomerEquipmentID\"	as 	Customer_equipment_id	,SVSOJ.\"CustomerEquipmentModuleID\"	as 	Customer_equipment_module_id	,SVSOJ.\"ProductID\"	as 	Product_ID	,common.resolve_unknown_dims(product_key)	as 	Product_fkey	,SVSOJ.\"InvSerialID\"	as 	InvSerial_ID	,SVSOJ.\"UID\"	as 	SOJ_ID	,SVSOJ.\"JobNumber\"	as 	Job_Number	,PRSNL.\"FirstName\" || ' ' || PRSNL.\"LastName\" as Customer_Contact	,SVSOJ.\"Telephone\"	as 	Telephone	,SVSOJ.\"ProblemText\"	as 	Problem_text	,SVSOJ.\"ServiceRoutineID\"	as 	Service_Routine_ID	,SVSOJ.\"TaskText\"	as 	Task_text	,SVCS.\"Description\"	as 	Cause_Description	,SVSOJ.\"CauseText\"	as 	Cause_Text	,SVSOJ.\"OrderRef\"	as 	Order_Reference	,SVSOJ.\"InvoicedFlag\"	as 	Invoiced_Flag	,common.resolve_unknown_dims(DT2.date_key)	as 	Assign_Date_Key	,common.resolve_unknown_dims(TM2.time_key)	as 	Assign_Time_Key	,common.resolve_unknown_dims(DT3.date_key)	as 	Response_Date_Key	,common.resolve_unknown_dims(TM3.time_key)	as 	Response_Time_Key	,common.resolve_unknown_dims(DT4.date_key)	as 	Scheduled_Start_Date_Key	, common.resolve_unknown_dims(TM4.time_key)	as 	Scheduled_Start_Time_Key	,common.resolve_unknown_dims(DT5.date_key)	as 	Created_Date_Key	,common.resolve_unknown_dims(TM5.time_key)	as 	Created_Time_Key	,common.resolve_unknown_dims(SVU.User_key)	as 	Created_by_key	,common.resolve_unknown_dims(SVU1.User_key)	as 	Modified_by_key	,common.resolve_unknown_dims(DT6.date_key)	as 	Closed_Date_Key	,common.resolve_unknown_dims(TM6.time_key)	as 	Closed_Time_Key	,PRSNL1.\"ShortName\"	as 	Closed_By	,case when SVSOJ.\"ClosedFlag\"=0 THEN 'Open' ELSE 'Closed' END as Job_Closed	,SVCTMSOJC.\"Name\" as 	Financial_Status	, SVSOJ.\"JobType\"	as 	Job_Type	,SVSOJC.\"Category\"	as 	Job_Category	,SVSOJC.\"ShortName\"	as 	Job_Category_Short_Name	,SVPRBLM.\"ShortCode\"	as 	Problem_Short_Code	,SVPRBLM.\"Description\"	as 	Problem_Description	,replace(SVSOJ.\"ProblemText\",'#',' ')	as 	Problem_Tag	,SVPRBLM.\"Description\"	as 	Problem_Code	,common.resolve_unknown_dims(DSVPRSNL.Personnel_Key)	as 	Assigned_To_Personnel_key	,SVSOJS1.\"Name\"	as 	Job_Status_Name	,case when Job_Status_Name in ('Completed','Completed (Suspended)','Fixed Service/Restored','Fixed/Service Restored','Returning') then 'Done' when Job_Status_Name in ('Cancelled Job - No Longer Reqd ','Unsafe','Unsfafe') then 'NtDn' when Job_Status_Name in ('Awaiting Completion','Awaiting Parts','Hold - client approval','Hold - engineering','Hold - land management','Hold - spares client','Hold - spares ordered','Hold - spares required','In Progress','No Spares','Suspended','Work Not Complete','Work Not Completed') then 'Part' when Job_Status_Name in ('Adverse Weather','Allocation Cancelled','Called Elsewhere','Cancelling Allocation','No Access','Rejected') then 'ReSchd' when Job_Status_Name in ('Accepted','Allocated','Allocated & Despatched','Arrived','Departed','Outstanding','Waiting/On Break') then 'Schd' else NVL2(Job_Status_Name,'No Status Type','Plan') end as 	Job_Status_Type	,common.resolve_unknown_dims(SVSR.service_routine_key)	as 	Service_routine_fkey	,SVSOJ.\"Classification\"	as 	Classification	,SVSOJ.\"ClosedFlag\"	as 	Closed_Flag	,SVSO.\"CustomerSiteID\"	as 	Customer_Site_ID	,SVCLJL.\"CallOut\"	as 	Is_Call_Out	,SVCLJL.\"ProblemMemo\"	as 	ProblemMemo	,case when Year(SVSOJ.\"FixTime\")<2000 THEN 0 ELSE 1 END as 	Has_real_fixtime	,common.resolve_unknown_dims(DT7.date_key)	as 	Actual_fix_Local_date_key	,common.resolve_unknown_dims(TM7.time_key)	as 	Actual_fix_Local_time_key	,SVSOJ.\"AgreementID\"	as 	AgreementID	,common.resolve_unknown_dims(SVA.agreement_key)	as 	Agreement_fkey	,SVSRSLTNS.\"Description\"	as 	Service_Resolution_Description	,SVA2.\"Reference\"	as 	Agreement	,SVQ.REFERENCE	as 	Quote_Reference	,SVCE.\"SerialNumber\"	as 	Serial_Number	,SVCE.\"Location\"	as 	Equipment_hierarchy	,SVSOJ.\"ServiceSchemeID\"	as 	Service_Scheme_ID	,SVSOJ.\"WarrantySupplierID\"	as 	Warranty_Supplier_ID	,SVSOJ.\"AsPerServiceSchemeID\"	as 	As_Per_Service_Scheme_ID	,SVSOJ.\"AsPerQuotationID\"	as 	As_Per_Quotation_ID	,SVSOJ.\"AsPerSalesOrderID\"	as 	As_Per_Sales_Order_ID	,SVSOJ.\"OrderRef\"	as 	Order_Ref	,SVSOJ.\"ServiceResolutionID\"	as 	Service_Resolution_ID	,SVSOJ.\"AssignedToTeamID\"	as 	Assigned_To_Team_ID	,SVSOJ.\"AutoBookViaScheduler\"	as 	Autobook_Via_Scheduler	,SVSOJ.\"UseAutoScheduler\"	as 	Use_Auto_Scheduler	,SVSOJ.\"ExternalReference\"	as 	External_Reference	,SVSOJ.\"ClosureEmailSent\"	as 	Closure_Email_Sent	,SVSOJ.\"AgreementServiceSchemeID\"	as 	Agreement_Service_Scheme_ID	,SVSOJ.\"VouchersAllowType\"	as 	Vouchers_Allow_Type	,SVSOJ.\"VouchersDeAllocType\"	as 	Voucher_DeAlloc_Type	,SVSOJ.\"JeopardyID\"	as 	Jeopardy_ID	,SVSOJ.\"SLAPerformanceStatusID\"	as 	SLA_Performance_Status_ID	,SVSOJ.\"SLAVarianceReasonID\"	as 	SLA_Variance_Reason_ID	,SVSOJ.\"SLAVarianceMemo\"	as 	SLA_Variance_Memo	,SVSOJ.\"SLASuspendDateTime\"	as 	SLA_Suspend_Date_Time	,SVSOJ.\"SLASuspendCumMins\"	as 	SLA_Suspend_Cum_Mins	,SVSOJ.\"SSAssignDuration\"	as 	SS_Assign_Duration	,SVSOJ.\"SSDepartDuration\"	as 	SS_Depart_Duration	,SVSOJ.\"SSResponseDuration\"	as 	SS_Response_Duration	,SVSOJ.\"SSFixDuration\"	as 	SS_Fix_Duration	,SVSOJ.\"SSShipDuration\"	as 	SS_Ship_Duration	,SVSOJ.\"REFERENCE\"	as 	Reference	, SVSOJ.\"DepChecklistDefinitionID\"	as 	Dep_Checklist_Defintion_ID	, SVSOJ.\"ArrChecklistDefinitionID\"	as 	Arr_Checklist_Definition_ID	, SVSOJ.\"CompChecklistDefinitionID\"	as 	Comp_Checklist_Definition_ID	, SVSOJ.\"BrokenAppointmentCount\"	as 	Broken_Appointment_Count	, SVSOJ.\"RecordTimeStamp\"	as 	Record_Timestamp	, '" + PIPELINE_RUN_ID + "' as 	Process_exec_id	, sysdate()	as 	Load_ts	, SVSOJ.\"LOAD_FILE\"	as 	Load_file	 from  \"REFERENCE\".\"SV_ServiceOrders\" SVSO  left join \"REFERENCE\".\"SV_Customers\" SVC on SVSO.\"CustomerID\"=SVC.\"UID\"  left join \"CURATED\".Dim_Sites DS on TRIM(SVC.\"ShortCode\")=DS.O_M_Reference_Formula  left join CURATED.Dim_Calendar_Date DT on (SVSO.\"CreatedDate\"=DT.date)  left join curated.dim_calendar_time TM on (SVSO.\"CreatedTime\"=TM.time)  left join CURATED.Dim_Calendar_Date DT1 on (SVSO.\"ClosedDate\"=DT1.date)  left join curated.dim_calendar_time TM1 on (SVSO.\"ClosedTime\"=TM1.time)  left join \"REFERENCE\".\"SV_ServiceOrdersJobs\" SVSOJ on SVSO.UID=SVSOJ.\"ServiceOrderID\"   left join CURATED.Dim_SV_Products SVP on SVSOJ.\"ProductID\"=SVP.product_id  left join \"REFERENCE\".\"SV_Personnel\" PRSNL on SVSOJ.\"CustomerContactID\"=PRSNL.UID  left join  \"REFERENCE\".\"SV_Causes\" SVCS on SVSOJ.\"CauseID\"=SVCS.UID  left join CURATED.Dim_Calendar_Date DT2 on  DATE(SVSOJ.\"AssignTime\")=DT2.date  left join CURATED.Dim_Calendar_Time TM2 on TIME(SVSOJ.\"AssignTime\")=TM2.time  left join CURATED.Dim_Calendar_Date DT3 on  DATE(SVSOJ.\"ResponseTime\")=DT3.date  left join CURATED.Dim_Calendar_Time TM3 on TIME(SVSOJ.\"ResponseTime\")=TM3.time  left join CURATED.Dim_Calendar_Date DT4 on  DATE(SVSOJ.\"ScheduledStart\")=DT4.date  left join CURATED.Dim_Calendar_Time TM4 on TIME(SVSOJ.\"ScheduledStart\")=TM4.time  left join CURATED.Dim_Calendar_Date DT5 on  DATE(SVSOJ.\"CreatedDate\")=DT5.date  left join CURATED.Dim_Calendar_Time TM5 on SVSOJ.\"CreatedTime\"=TM5.time  left join CURATED.Dim_SV_Users SVU on SVSOJ.\"CreatedByID\"=SVU.user_id  left join CURATED.Dim_SV_Users SVU1 on SVSOJ.\"ModifiedByID\"=SVU.user_id  left join CURATED.Dim_Calendar_Date DT6 on  DATE(SVSOJ.\"SOJClosedDate\")=DT6.date  left join CURATED.Dim_Calendar_Time TM6 on TIME(SVSOJ.\"SOJClosedDate\")=TM6.time  left join \"REFERENCE\".\"SV_Personnel\" PRSNL1 on SVSOJ.\"SOJClosedByID\"=PRSNL1.UID  left join REFERENCE.\"SV_CTM_ServiceOrdersJobsChgS\" SVCTMSOJC on SVSOJ.\"ChargeStatusID\"=SVCTMSOJC.UID  left join \"REFERENCE\".\"SV_ServiceOrdersJobsStatus\" SVSOJS on  SVSOJ.\"JobCategoryID\"=SVSOJS.UID  left join \"REFERENCE\".\"SV_Problems\" SVPRBLM on SVSOJ.\"ProblemID\"=SVPRBLM.UID  left join CURATED.Dim_SV_Personnel DSVPRSNL on SVSOJ.\"AssignedToPersonnelID\"=DSVPRSNL.Personnel_ID  left join \"REFERENCE\".\"SV_ServiceOrdersJobsStatus\" SVSOJS1 on SVSOJ.\"JobStatusID\"=SVSOJS1.UID  left join CURATED.Dim_SV_Service_Routines SVSR on SVSOJ.\"ServiceRoutineID\"=SVSR.service_routine_id  left join CURATED.Dim_Calendar_Date DT7 on  DATE(SVSOJ.\"FixTime\")=DT7.date  left join CURATED.Dim_Calendar_Time TM7 on TIME(SVSOJ.\"FixTime\")=TM7.time  left join \"REFERENCE\".\"SV_ServiceOrdersJobsCats\" SVSOJC on SVSOJ.\"JobCategoryID\"=SVSOJC.UID  left join \"REFERENCE\".\"SV_CTM_LS_JobList\" SVCLJL on SVSOJ.\"JobNumber\"=SVCLJL.\"JobNumber\"  left join CURATED.Dim_SV_Agreements SVA on SVSOJ.\"AgreementID\"=SVA.agreement_id left join \"REFERENCE\".\"SV_ServiceResolutions\" SVSRSLTNS on SVSOJ.\"ServiceResolutionID\"=SVSRSLTNS.UID left join REFERENCE.\"SV_Agreements\" SVA2 on SVSOJ.\"AgreementID\"=SVA2.UID left join (select UID,\"REFERENCE\" as REFERENCE from \"REFERENCE\".\"SV_Quotations\" where \"DocumentTypeID\"=2) SVQ on SVSO.\"DocumentID\"=SVQ.UID left join \"REFERENCE\".\"SV_CustomersEquipment\" SVCE on SVSOJ.\"CustomerEquipmentID\"=SVCE.UID  where Job_Status_Name <> 'Cancelled Job – No Longer Reqd'"
               });  
        var rs = stmt.execute();
        rs.next();
        rowsInserted = rs.getColumnValue(1);
        
        snowflake.execute( {sqlText: "COMMIT WORK;"} );
		  
		snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )

		return JSON.stringify({"Rows inserted":rowsInserted});
        
        $$
       ;    

-- DDL for Fact_SV_Service_Orders_Jobs_Personnel

create or replace view RAW.Fact_SV_Service_Orders_Jobs_Personnel 
as select

"UID" as SOJ_Personnel_key,
FSOJ.SOJ_Key as SOJ_Fkey,
"PersonnelID" as Personnel_id,
"UID" as UID,
"RecordStatusID" as Record_Status_ID,
DSP.POST_ZIP_CODE as Post_Zip_Code,
"AssignTime" as Assign_Time,
"ScheduledDate" as Scheduled_Date,
"ScheduledTime" as Scheduled_Time,
"JobStatusID" as Job_Status_ID,
"Completed" as Completed,
"SchedulingType" as Scheduling_Type,
"RespondFromTime" as Respond_From_Time,
"CHAssignTime" as CH_Assign_Time,
"SSDepartTime" as SS_Depart_Time,
"SSResponseTime" as SS_Response_Time,
"SSFixTime" as SS_Fix_Time,
"SSShipTime" as SS_Ship_Time,
"ScheduledAssignTime" as Scheduled_Assign_Time,
"ScheduledDepartTime" as Scheduled_Depart_Time,
"ScheduledResponseTime" as Scheduled_Response_Time,
"ScheduledFixTime" as Scheduled_Fix_Time,
"ScheduledShipTime" as Scheduled_Ship_Time,
"DepartTime" as Depart_Time,
"ResponseTime" as Response_Time,
"FixTime" as Fix_Time,
"ShipTime" as Ship_Time,
"AssignDuration" as Assign_Duration,
"DepartDuration" as Depart_Duration,
"ResponseDuration" as Response_Duration,
"FixDuration" as Fix_Duration,
"ShipDuration" as Ship_Duration,
"CHAssignVariance" as CH_Assign_Variance,
"SSDepartVariance" as SS_Depart_Variance,
"SSResponseVariance" as SS_Response_Variance,
"SSFixVariance" as SS_Fix_Variance,
"SSShipVariance" as SS_Ship_Variance,
"EstDurationMins" as Est_Duration_Mins,
"AutoBookViaScheduler" as Autobook_Via_Scheduler,
"ResponseFromTime" as Response_From_Time,
"Inactive" as Inactive,
"EstimatedDepartTime" as Estimated_Depart_Time,
"EstimatedResponseTime" as Estimated_Response_Time,
"EstimatedFixTime" as Estimated_Fix_Time,
"SendTimes" as Send_Times,
"SchedulerMandatory" as Scheduler_Mandatory,
"CreatedDate" as Created_Date,
"CreatedTime" as Created_Time,
"CreatedByID" as Created_By_ID,
"PersonnelUpdate" as Personnel_Update,
"SchedulerBookingJobStatusID" as Scheduler_Booking_Job_Status_ID,
"SchedulerPersonnelJobStatusID" as Scheduler_Personnel_Job_Status_ID,
"PreviousJobStatusID" as Previous_Job_Status_ID,
"JeopardyID" as Jeopardy_ID,
"ModifiedDateTime" as Modified_Date_Time,
"ModifiedByID" as Modified_By_ID,
"JobActionNumber" as Job_Action_Number,
"ClosedDateTime" as Closed_Date_Time,
"ClosedByUserID" as Closed_By_User_ID,
"ScheduledAssignVariance" as Scheduled_Assign_Variance,
"ScheduledDepartVariance" as Scheduled_Depart_Variance,
"ScheduledResponseVariance" as Scheduled_Response_Variance,
"ScheduledFixVariance" as Scheduled_Fix_Variance,
"ScheduledShipVariance" as Scheduled_Ship_Variance,
"WTRestCreditType" as WT_Rest_Credit_Type,
"WTCallOutType" as WT_Call_Out_Type,
"ReceivedTime" as Received_Time,
"AcceptedTime" as Accepted_Time,
"LastStatusChangeTime" as Last_Status_Change_Time,
"RejectReasonID" as Reject_Reason_ID
,"RecordTimeStamp" as Record_Timestamp
,"CancelReasonID" as Cancel_Reason_Id
,"ScheduledDateVarianceType" as Scheduled_Date_Variance_Type
,"AccessStatusID" as Access_Status_ID
,"ExchangeSyncItemRef" as Exchange_Sync_Item_Ref
,"PinnedType" as Pinned_Type
,"ServiceOrderJobLinkID" as Service_Order_Job_Link_ID
,SOJP."PROCESS_EXEC_ID" as Process_exec_Id
,SOJP."LOAD_TS" as Load_ts
,SOJP."LOAD_FILE" as Load_file

from REFERENCE."SV_ServiceOrdersJobsPersonnel" SOJP
	left join CURATED.DIM_SV_PERSONNEL DSP
		on SOJP."UID" = DSP.PERSONNEL_ID
	left join RAW.FACT_SV_SERVICE_ORDERS_JOBS FSOJ
		on SOJP."ServiceOrdersJobID" = FSOJ.SOJ_ID;


-- DDL for Fact_SV_Jobs_Inventory


create or replace view RAW.Fact_SV_Jobs_Inventory
as select

"UID" as SOJ_Inventory_Key,
 FSOJ.SOJ_Key as SOJ_Fkey,
"ActivityID" as Activity_Id,
"ItemNumber" as Item_Number,
"ItemType" as Item_Type,
"UID" as JobInventoryId,
"Quantity" as Quantity,
"FromLocationTypeID" as From_Location_Type_ID,
"FromLocationID" as From_Location_ID,
"FromInventoryStatusID" as From_Inventory_Status_ID,
"FromBinID" as From_Bin_ID,
"ProductID" as Product_ID,
SVP.PRODUCT_KEY as Product_fKey,
"InvSerialItemID" as Inv_Serial_Item_ID,
"PricingPolicyID" as Pricing_Policy_ID,
"ItemRetailPrice" as Item_Retail_Price,
"ItemPolicyPrice" as Item_Policy_Price,
"ItemDiscount" as Item_Dicscount,
"DiscountPercent" as Discount_Percent,
"ItemNetPrice" as Item_Net_Price,
"ItemCostPrice" as Item_Cost_Price,
"TotalRetailPrice" as Total_Retail_Price,
"TotalPolicyPrice" as Total_PolicyP_rice,
"TotalDiscount" as Total_Discount,
"TotalNetPrice" as Total_Net_Price,
"TotalCostPrice" as Total_Cost_Price,
"TaxRateID" as Tax_Rate_ID,
"InventoryUpdatedFlag" as Inventory_Updated_Flag,
"Basis" as Basis,
"ToLocationTypeID" as To_Location_Type_ID,
"ToLocationID" as To_Location_ID,
"ToInventoryStatusID" as To_Inventory_Status_ID,
"ToBinID" as To_Bin_ID,
"ExchangeProductID" as Exchange_Product_ID,
"ExchangeProductDesc" as Exchange_Product_Desc,
"ExchangeInvSerialItemID" as Exchange_Inv_Serial_Item_ID,
"SerialisedInventoryID" as Serialised_Inventory_ID,
"ExchangeQuantity" as Exchange_Quantity,
"ExchangeItemRetailPrice" as Exchange_Item_Retail_Price,
"ItemExchangeValue" as Item_Exchange_Value,
"TotalExchangeValue" as Total_Exchange_Value,
"AfterExchangeProfit" as After_Exchange_Profit,
"RoutingID" as Routing_ID,
"RoutingOther" as Routing_Other,
"RoutingDocumentTypeID" as Routing_Document_Type_ID,
"RoutingDocumentID" as Routing_Document_ID,
"RoutingCompleteFlag" as Routing_Complete_Flag,
"FreeTextFlag" as Free_Text_Flag,
"CurrencyItemRetailPrice" as Currency_Item_Retail_Price,
"CurrencyItemPolicyPrice" as Currency_Item_Policy_Price,
"CurrencyItemDiscount" as Currency_Item_Discount,
"CurrencyItemNetPrice" as Currency_Item_Net_Price,
"CurrencyItemCostPrice" as Currency_Item_Cost_Price,
"CurrencyItemRetailPrice" as Currenncy_Total_Retail_Price,
"CurrencyTotalPolicyPrice" as Currency_Total_Policy_Price,
"CurrencyTotalDiscount" as Currency_Total_Discount,
"CurrencyTotalNetPrice" as Currency_Total_Net_Price,
"CurrencyTotalCostPrice" as Currency_Total_Cost_Price,
"CurrencyExchangeItemRetailPrice" as Currency_Exchange_Item_Retail_Price,
"CurrencyItemExchangeValue" as Currency_Item_Exchange_Value,
"CurrencyTotalExchangeValue" as Currency_Total_Exchange_Value,
"CurrencyAfterExchangeProfit" as Currency_After_Exchange_Profit,
"CustomerEquipmentID" as Customer_Equipment_ID,
"CustomerEquipmentModuleID" as Customer_Equipment_Module_ID,
"RecordTimeStamp" as Record_Timestamp,
"ServiceOrdersJobsSecondaryID" as Service_Orders_Jobs_Secondary_ID,
SOJI."PROCESS_EXEC_ID" as Process_exec_ID,
SOJI."LOAD_TS" as Load_ts,
SOJI."LOAD_FILE" as Load_file

from "REFERENCE"."SV_ServiceOrdersJobsInventory" SOJI
 left join CURATED.DIM_SV_PRODUCTS SVP
		on SOJI."UID" = SVP.PRODUCT_ID

left join "RAW"."FACT_SV_SERVICE_ORDERS_JOBS" FSOJ
        on SOJI."ServiceOrdersJobID"  = FSOJ.SOJ_ID;

--DDL for Fact_SV_Scheduled_Services
create or replace TRANSIENT TABLE RAW.FACT_SV_SCHEDULED_SERVICES (
	SCHEDULED_SERVICE_ID NUMBER(38,0),
	RECORD_STATUS_ID NUMBER(38,0),
	AGREEMENT_FKEY NUMBER(38,0),
	SITE_FKEY NUMBER(38,0),
	EQUIPMENT_ID NUMBER(38,0),
	SCHED_SERVICE_TYPE NUMBER(38,0),
	INTERVAL_ID NUMBER(38,0),
	INTERVAL_EVERY_ID NUMBER(38,0),
	DUE_DATE DATE,
	DUE_TIME TIME(9),
	INTERVAL_START_DATE DATE,
	INTERVAL_END_DATE DATE,
	SERVICE_ROUTINE_ID NUMBER(38,0),
	STATUS_ID NUMBER(38,0),
	SERVICE_ORDERS_JOB_ID NUMBER(38,0),
	SERVICE_ORDERS_JOB_FKEY NUMBER(38,0),
	LIABILITY NUMBER(38,0),
	MEMO VARCHAR(16777216),
	CHARGE FLOAT,
	CURRENCY_CHARGE FLOAT,
	SERVICE_SCHEME_ID NUMBER(38,0),
	PERSONNEL_ID NUMBER(38,0),
	APPOINTMENT_ID NUMBER(38,0),
	CHARGE_BASIS NUMBER(38,0),
	RENEWAL_PRICE_METHOD NUMBER(38,0),
	SS_EQUIPMENT_ID NUMBER(38,0),
	EST_DURATION_IN_MINS NUMBER(38,0),
	PROJECT_ITEM_ID NUMBER(38,0),
	CUSTOMERS_EQUIPMENT_SS_ID NUMBER(38,0),
	AGREEMENT_EQUIPMENT_ID NUMBER(38,0),
	RECORD_TIMESTAMP VARCHAR(100),
	ORIGINATE_TYPE NUMBER(38,0),
	CRITERIA_TYPE NUMBER(38,0),
	ORIGINATING_SERVICE_SCHEDULE_ID NUMBER(38,0),
	GENERATE_AS_TYPE NUMBER(38,0),
	PRIORITY_LEVEL NUMBER(38,0),
	OPTIONAL_TYPE NUMBER(38,0),
	OPTIONAL_UNTIL_DAYS NUMBER(38,0),
	PROBLEM_MEMO VARCHAR(1024),
	JOB_CATEGORY_ID NUMBER(38,0),
	INTERVAL_EVERY NUMBER(38,0),
	CLASSIFICATION NUMBER(38,0),
	STATUS_TYPE VARCHAR(14),
	DISPLAY_DATE TIMESTAMP_NTZ(9),
	TASK_COUNT NUMBER(18,0),
	DISPLAY_STATUS VARCHAR(14),
	BLOCK_NAME VARCHAR(16777216),
	DISPLAY_FINAL VARCHAR(16777216),
	PROCESS_EXEC_ID VARCHAR(100),
	LOAD_TS TIMESTAMP_NTZ(9)
)comment ='FACT_SV_SCHEDULED_SERVICES';

--  SP for FACT_SV_SCHEDULED_SERVICES
CREATE OR REPLACE PROCEDURE "RAW"."PROC_LOAD_FACT_SV_SCHEDULED_SERVICES"(PIPELINE_RUN_ID VARCHAR, PIPELINE_NAME VARCHAR)
    RETURNS string
    LANGUAGE javascript
    strict
    EXECUTE AS CALLER 
    AS
    $$
        snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PIPELINE_RUN_ID+"','"+PIPELINE_NAME+"','ref2fact'))"});
    	snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} ); 

		var stmt = snowflake.createStatement({
                   sqlText: "insert overwrite into RAW.FACT_SV_SCHEDULED_SERVICES SELECT  SVSS1.\"UID\" 	as	Scheduled_Service_id	, SVSS1.\"RecordStatusID\"	as	Record_status_id	, common.resolve_unknown_dims(SVA.agreement_key)	as	Agreement_fkey	, common.resolve_unknown_dims(DS.Site_Key)	as	Site_fkey	, \"EquipmentID\"	as	Equipment_id	, \"SchedServiceType\"	as	Sched_Service_Type	, \"IntervalID\"	as	Interval_ID	, \"IntervalEveryID\"	as	Interval_every_id	, common.RESOLVE_DATE_YEAR(\"DueDate\")	as	Due_date	, \"DueTime\"	as	Due_time	, common.RESOLVE_DATE_YEAR(\"IntervalStartDate\")	as	Interval_start_date	, common.RESOLVE_DATE_YEAR(\"IntervalEndDate\")	as	Interval_end_date	, SVSS1.\"ServiceRoutineID\"	as	Service_routine_id	, \"StatusID\"	as	Status_id	, SVSS1.\"ServiceOrdersJobID\"	as	Service_orders_job_id	, FSOJ.SOJ_key	as	Service_orders_job_fkey	, \"Liability\"	as	Liability	, SVSS1.\"Memo\"	as	Memo	, \"Charge\"	as	Charge	, \"CurrencyCharge\"	as	Currency_Charge	, SVSS1.\"ServiceSchemeID\"	as	Service_scheme_id	, \"PersonnelID\"	as	Personnel_id	, \"AppointmentID\"	as	Appointment_id	, \"ChargeBasis\"	as	Charge_Basis	, \"RenewalPriceMethod\"	as	Renewal_Price_Method	, \"SSEquipmentID\"	as	SS_equipment_id	, \"EstDurationInMins\"	as	Est_Duration_In_Mins	, \"ProjectItemID\"	as	Project_item_id	, \"CustomersEquipmentSSID\"	as	Customers_equipment_ss_id	, \"AgreementEquipmentID\"	as	Agreement_equipment_id	, SVSS1.\"RecordTimeStamp\"	as	Record_timestamp	, \"OriginateType\"	as	Originate_Type	, \"CriteriaType\"	as	Criteria_Type	, \"OriginatingScheduledServiceID\"	as	Originating_service_schedule_ID	, \"GenerateAsType\"	as	Generate_As_Type	, \"PriorityLevel\"	as  Priority_Level , \"OptionalType\"	as	Optional_Type	, \"OptionalUntilDays\"	as	Optional_Until_Days	, \"ProblemMemo\"	as	Problem_Memo	, SVSS1.\"JobCategoryID\"	as	Job_category_id	, \"IntervalEvery\"	as	Interval_every	, SVSS1.\"Classification\"	as	Classification	, case  when SOJS.\"Name\" in ('Completed','Completed (Suspended)','Fixed Service/Restored','Fixed/Service Restored','Returning') then 'Done' when SOJS.\"Name\" in ('Cancelled Job - No Longer Reqd ','Unsafe','Unsfafe') then 'NtDn'  when SOJS.\"Name\" in ('Awaiting Completion','Awaiting Parts','Hold - client approval','Hold - engineering','Hold - land management','Hold - spares client','Hold - spares ordered','Hold - spares required','In Progress','No Spares','Suspended','Work Not Complete','Work Not Completed') then 'Part' when SOJS.\"Name\" in ('Adverse Weather','Allocation Cancelled','Called Elsewhere','Cancelling Allocation','No Access','Rejected') then 'ReSchd'  when SOJS.\"Name\" in ('Accepted','Allocated','Allocated & Despatched','Arrived','Departed','Outstanding','Waiting/On Break')  then 'Schd'  else 'No Status Type' end as Status_type , case  when ( SVSS1.\"ServiceOrdersJobID\" is null or SVSS1.\"ServiceOrdersJobID\" =0 ) THEN \"DueDate\"   when ( status_type='Done' AND FSOJ.has_real_fixtime =1 ) THEN SVSOJ.\"FixTime\"  when ( FSOJ.has_reaL_fixtime=0 ) then SVSOJ.\"ScheduledDate\" end as Display_Date , SOJT.task_count as task_count, case when ( Status_type='Schd' and display_date >= current_date() and SVSOJ.\"ScheduledDate\" < to_date('01/01/2015','DD/MM/YYYY')) THEN 'Plan'  when ( Status_type IN ('Plan', 'Scheduled') AND Display_Date < current_date())  THEN 'ReSchd'  when ( Status_type IN ('Plan', 'Scheduled') AND Display_Date > current_date())  THEN Status_type  when ( Status_type='ReSchd' AND Display_Date >= current_date() ) THEN 'Schd'  when ( Status_type='Part' and FSOJ.Job_Status_Name='In Progress' AND task_count<=1 AND Display_Date < current_date()) THEN ( 'ReSchd' )  when ( Status_type='Part' and FSOJ.Job_Status_Name='In Progress' AND task_count<=1 AND Display_Date >= current_date()) THEN ( 'Schd' )  else Status_type END as	display_status	, SVSS1.\"Memo\"	as	Block_Name, display_status || ' - ' || block_name as Display_final, '" + PIPELINE_RUN_ID + "' as 	Process_exec_id	, sysdate()	as 	Load_ts FROM ( select * from \"REFERENCE\".\"SV_ScheduledServices\" SVSS where (SVSS.\"RecordStatusID\" < 6 and ( SVSS.\"SchedServiceType\" <> 3 or SVSS.\"SchedServiceType\" is null)) and (SVSS.\"EquipmentID\" <> 0 or SVSS.\"EquipmentID\" is null) and SVSS.\"DueDate\" >= '2016-01-01') SVSS1  left join CURATED.Dim_SV_Agreements SVA on SVSS1.\"AgreementID\"=SVA.agreement_id  left join \"REFERENCE\".\"SV_Customers\" SVC on SVSS1.\"CustomerID\"=SVC.\"UID\"  left join \"CURATED\".Dim_Sites DS on TRIM(SVC.\"ShortCode\")=DS.O_M_Reference_Formula left join RAW.FACT_SV_SERVICE_ORDERS_JOBS FSOJ on SVSS1.\"ServiceOrdersJobID\" = FSOJ.SOJ_ID  left join \"REFERENCE\".\"SV_ServiceOrdersJobs\" SVSOJ on FSOJ.SOJ_Key=SVSOJ.UID  left join \"REFERENCE\".\"SV_ServiceOrdersJobsStatus\" SOJS on SVSOJ.\"JobStatusID\"=SOJS.\"UID\"  left join (select \"ServiceOrdersJobID\",count(*) as task_count from \"REFERENCE\".\"SV_ServiceOrdersJobsTasks\" group by \"ServiceOrdersJobID\") SOJT on SVSS1.\"ServiceOrdersJobID\"=SOJT.\"ServiceOrdersJobID\" "
               });  
        var rs = stmt.execute();
        rs.next();
        rowsInserted = rs.getColumnValue(1);
        
        snowflake.execute( {sqlText: "COMMIT WORK;"} );
		  
		snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )

		return JSON.stringify({"Rows inserted":rowsInserted});
        
        $$
       ;    