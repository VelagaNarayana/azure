create or replace table raw.fact_satellite_measurements
(
    site_key integer not null,
    measure_key smallint not null,
    date_key bigint not null,
    time_key smallint not null,
    sdate date null,
    stime time null ,
    satellite_value float null,
    original_satellite_site varchar(255) null,
    original_measure_idx varchar(10) null,
    original_satellite_ts varchar(255) null,
    local_date_key bigint,
    local_time_key smallint,
    local_date date null,
    local_time time null,
    created_ts datetime NULL,
	updated_ts datetime NULL,
    process_exec_id varchar(255) NULL,
    load_file varchar(500) NULL
)DATA_RETENTION_TIME_IN_DAYS = 31
 CLUSTER BY (sdate) 
 comment = 'Raw table for Satellite data';