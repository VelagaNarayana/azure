use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace table raw.fact_production_meter
(
    site_key integer not null,
    meter_key integer not null,
    date_key bigint not null,
    time_key smallint not null,
    pdate date null,
    ptime time null,
    production_value float null,
    original_meter_id varchar(255) null,
    original_date_time varchar(50) null,
    data_source varchar(255) null,
    created_ts datetime NULL,
	updated_ts datetime NULL,
    process_exec_id varchar(255) NULL,
    load_file varchar(500) NULL
)  comment = "Raw fact table for Production Meter" 
 DATA_RETENTION_TIME_IN_DAYS = 31
 CLUSTER BY (pdate)
;

create or replace procedure "RAW"."PROC_LOAD_FACT_PROD_METER"(FILTER_OR_PATH VARCHAR,SOURCE VARCHAR, PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
 RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller 
AS
 $$
    
    snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','file2fact~"+SOURCE.toLowerCase()+"'))"});
    snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} ); 
    
    var tempTableSql;
    var tempTableName = "common.\"TMP_PROD_METER_"+PROCESS_RUN_ID+"\"";
    var rowsUpdated = 0, multiJoinUpdated = 0, rowsInserted=0;
    
    var stmt = snowflake.createStatement({
		sqlText: "select fact_table,common.replace_query(parse_query,'"+FILTER_OR_PATH+"','"+SOURCE+"','"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"'),data_source from control.fact_table_load_queries where query_source=?",
        binds:[SOURCE]
	});  
    var rs = stmt.execute();
    var factTable, query, dataSource;
    if(rs.next()){
        factTable = rs.getColumnValue(1);
        query = rs.getColumnValue(2);
        dataSource = rs.getColumnValue(3);
    } else {
        throw "Parsing for source system - "+DATA_SOURCE+" not configured in the table CONTROL.FACT_TABLE_LOAD_QUERIES"
    };
       
    snowflake.execute({ sqlText:"create or replace temporary table "+tempTableName+"as with new_meter_reads as ( "+query+")  select common.resolve_unknown_dims(pm.site_fkey) as site_key, common.resolve_unknown_dims(pm.meter_key) as meter_key,common.resolve_unknown_dims(dt.date_key) as date_key,common.resolve_unknown_dims(tm.time_key) as time_key, dt.date as pdate,tm.time as ptime, new_meter_reads.meter_value as meter_value, new_meter_reads.meter_id as original_meter_id, new_meter_reads.original_date_time, new_meter_reads.filename as filename from new_meter_reads left join curated.dim_prod_meter_details pm on (common.resolve_missing_dims(new_meter_reads.meter_id)=pm.meter_id) left join curated.dim_calendar_date dt on (new_meter_reads.pdate=dt.date) left join curated.dim_calendar_time tm on (new_meter_reads.ptime=tm.time)"});
    
    snowflake.execute( {sqlText: "BEGIN WORK;"} ); 
    try{        
        var stmt = snowflake.createStatement({
                   sqlText: "update "+factTable+" fact set fact.METER_KEY=tmp.METER_KEY, fact.SITE_KEY = tmp.SITE_KEY, fact.date_key = tmp.date_key, fact.pdate = tmp.pdate, fact.time_key = tmp.time_key, fact.ptime=tmp.ptime, fact.PRODUCTION_VALUE = tmp.MAX_METER_VALUE, fact.LOAD_FILE = tmp.FILENAME, fact.UPDATED_TS = sysdate(), fact.PROCESS_EXEC_ID =? from (select *, TO_DATE(REGEXP_SUBSTR (filename,'(\\\\d{4}\/\\\\d{2}\/\\\\d{2})'),'YYYY/MM/DD') as file_date, max(meter_value) over(partition by file_date,original_meter_id, original_date_time) as max_meter_value,row_number() over(partition by original_meter_id, original_date_time order by file_date desc) as row_num from "+tempTableName+") tmp where fact.original_meter_id=tmp.original_meter_id and fact.original_date_time=tmp.original_date_time and fact.data_source=? and tmp.row_num=1",
                   binds:[ PROCESS_RUN_ID, dataSource]
               });  
        var rs = stmt.execute();
        rs.next();
        rowsUpdated = rs.getColumnValue(1);
        multiJoinUpdated = rs.getColumnValue(2);
        
        
        stmt = snowflake.createStatement({
                   sqlText: "insert into "+factTable+"(SITE_KEY ,METER_KEY ,DATE_KEY, TIME_KEY, PDATE ,PTIME ,PRODUCTION_VALUE ,ORIGINAL_METER_ID, ORIGINAL_DATE_TIME, DATA_SOURCE,CREATED_TS ,UPDATED_TS, PROCESS_EXEC_ID ,LOAD_FILE) with latest as (select *,TO_DATE(REGEXP_SUBSTR (filename,'(\\\\d{4}\/\\\\d{2}\/\\\\d{2})'),'YYYY/MM/DD') as file_date, max(meter_value) over(partition by file_date,original_meter_id, original_date_time) as max_meter_value,row_number() over(partition by original_meter_id, original_date_time order by file_date desc) as row_num from "+tempTableName+") select tmp.site_key, tmp.meter_key,    tmp.date_key, tmp.time_key, tmp.pdate,tmp.ptime,tmp.max_meter_value,tmp.original_meter_id, tmp.original_date_time,? as data_source,sysdate(),sysdate(),?, tmp.filename from (select * from latest where row_num=1) tmp LEFT JOIN (select * from raw.fact_production_meter where pdate between   (select min(pdate) as mindt from "+tempTableName+") and   (select max(pdate) maxdt from "+tempTableName+")) fact on fact.original_meter_id=tmp.original_meter_id and fact.original_date_time=tmp.original_date_time and fact.data_source=? where fact.meter_key is null",
                   binds:[ dataSource,PROCESS_RUN_ID,dataSource]
               });  
        rs = stmt.execute();
        rs.next();
        rowsInserted = rs.getColumnValue(1);
        
        snowflake.execute( {sqlText: "COMMIT WORK;"} );
    }
    catch(err){
        snowflake.execute( {sqlText: "ROLLBACK WORK;"} );
        rowsInserted=rowsUpdated=multiJoinUpdated=-1;
        throw err;
    }
    finally{
        snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
    }
    
    return JSON.stringify({"Rows inserted":rowsInserted,"Rows updated":rowsUpdated,"Multi-join updates":multiJoinUpdated});
 $$;