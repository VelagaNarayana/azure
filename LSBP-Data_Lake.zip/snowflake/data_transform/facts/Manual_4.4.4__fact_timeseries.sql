use database data_lake_{{ db }};
use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER TABLE RAW.FACT_SITE_MEASUREMENTS CLUSTER BY ( mdate, to_date(original_measurement_ts), to_date(updated_ts));
select SYSTEM$CLUSTERING_INFORMATION('RAW.FACT_SITE_MEASUREMENTS');