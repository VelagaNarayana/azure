use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace procedure "RAW"."PROC_LOAD_FACT_SATELLITE"(SOURCE_DATA_FILTER VARCHAR, PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
  RETURNS string
  LANGUAGE javascript
  strict
  EXECUTE AS caller 
  AS
   $$
      snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','stage2fact'))"});
      snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} ); 
      
      var tempTableName0 = "common.\"TMP_SATELLITE_0_"+PROCESS_RUN_ID+"\"";
      var tempTableName1 = "common.\"TMP_SATELLITE_1_"+PROCESS_RUN_ID+"\"";
      var rowsUpdated = 0, monthlyInserts = 0, rowsInserted=0;
      
      var tempTableSql = "create or replace temporary table "+tempTableName0+" as select GET( payload,'@id')::string AS site_name ,GET( payload, '@lat' )::float AS latitude ,GET( payload, '@lng' )::float AS longitude ,GET(ts_rows.value,'@dateTime')::timestamp AS ts_15min , measures.index as measure_index   , measures.value::float as measure_value  , is_monthly_load , filename from RAW.STAGE_SATELLITE_TS stg ,  lateral FLATTEN(stg.payload:\"$\") ts_rows , lateral FLATTEN(split(GET(ts_rows.value,'@values')::string,' ')) measures where GET( ts_rows.value, '@') = 'row' and "+SOURCE_DATA_FILTER;
      snowflake.execute( {sqlText: tempTableSql});
      
      tempTableSql = "create or replace temporary table "+tempTableName1+" as select inn.*,common.resolve_unknown_dims(ldt.date_key) as local_date_key, common.resolve_unknown_dims(ltm.time_key) as local_time_key, ldt.date as local_date, ltm.time as local_time from(select common.resolve_unknown_dims(dimsite.site_key) as site_key, common.resolve_unknown_dims(dimsat.skey) as measure_key, common.resolve_unknown_dims(dt.date_key) as date_key,common.resolve_unknown_dims(tm.time_key) as time_key, dt.date as sdate, tm.time as stime, common.convert_to_local_tz(sdate,stime,'UTC',coalesce(dimsite.derived_timezone, dimsite.source_timezone)) as local_ts,new.measure_value as satellite_value, new.site_name as original_satellite_site, new.measure_index as original_measure_idx, new.ts_15min as original_satellite_ts,new.filename as load_file,    new.is_monthly_load from "+tempTableName0+" new left join control.SATELLITE_LOAD cntrl on common.resolve_missing_dims(new.site_name)=cntrl.SOLARGIS_SITE_NAME left join curated.dim_satellite_measurements dimsat on coalesce(new.measure_index,-1)=dimsat.measure_source_idx left join curated.dim_sites dimsite on common.resolve_missing_dims(cntrl.INSOLAR_SITE_ID)=dimsite.site_id left join curated.dim_calendar_date dt on (to_date(new.ts_15min)=dt.date) left join curated.dim_calendar_time tm on (to_time(new.ts_15min)=tm.time)) inn left join curated.dim_calendar_date ldt on (to_date(local_ts)=ldt.date)left join curated.dim_calendar_time ltm on (to_time(local_ts)=ltm.time)";
      snowflake.execute( {sqlText: tempTableSql});
      
      var stmt = snowflake.createStatement({
                   sqlText: "insert into raw.fact_satellite_measurements(site_key, measure_key, date_key, time_key, sdate, stime, local_date_key, local_time_key,local_date,local_time, satellite_value,original_satellite_site, original_measure_idx, original_satellite_ts,load_file, created_ts,updated_ts, process_exec_id)   select new.site_key, new.measure_key, new.date_key, new.time_key, new.sdate, new.stime,new.local_date_key, new.local_time_key, new.local_date, new.local_time, new.satellite_value,new.original_satellite_site, new.original_measure_idx,new.original_satellite_ts, new.load_file, sysdate(),sysdate(), ?   from (select * from   "+tempTableName1+" where not is_monthly_load) new",
                   binds:[ PROCESS_RUN_ID]
               });  
        var rs = stmt.execute();
        rowsInserted = rs.next() && rs.getColumnValue(1);
        
        stmt = snowflake.createStatement({
                   sqlText: "merge into raw.fact_satellite_measurements fact using (select * from "+tempTableName1+" where is_monthly_load) new on fact.original_satellite_site = new.original_satellite_site and fact.original_measure_idx = new.original_measure_idx and fact.original_satellite_ts = new.original_satellite_ts when matched then update set fact.site_key = new.site_key, fact.measure_key = new.measure_key, fact.date_key = new.date_key, fact.time_key = new.time_key, fact.sdate = new.sdate, fact.stime = new.stime,fact.local_date_key = new.local_date_key, fact.local_time_key = new.local_time_key, fact.local_date = new.local_date, fact.local_time = new.local_time, fact.satellite_value = new.satellite_value, fact.load_file = new.load_file, fact.updated_ts = sysdate(), fact.process_exec_id = ? when not matched then insert (site_key, measure_key, date_key, time_key, sdate, stime, local_date_key, local_time_key,local_date,local_time, satellite_value,original_satellite_site, original_measure_idx, original_satellite_ts, load_file, created_ts,updated_ts, process_exec_id)   values(new.site_key, new.measure_key, new.date_key, new.time_key, new.sdate, new.stime, new.local_date_key, new.local_time_key, new.local_date, new.local_time, new.satellite_value, new.original_satellite_site, new.original_measure_idx,new.original_satellite_ts,new.load_file, sysdate(), sysdate(), ? )",
                   binds:[ PROCESS_RUN_ID, PROCESS_RUN_ID]
               });  
        rs = stmt.execute();
        rs.next();
        rowsUpdated = rs.getColumnValue(2);
        monthlyInserts = rs.getColumnValue(1);
      
        return JSON.stringify({"Daily inserts":rowsInserted,"Monthly updates":rowsUpdated,"Monthly inserts":monthlyInserts});
   $$;