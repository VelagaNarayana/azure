use database data_lake_{{ db }};
use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace procedure "RAW"."PROC_LOAD_FACT_METEOCONTROL_MEASUREMENTS"(FILEPATH VARCHAR,PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller 
AS
$$

  try{
                
        snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','blob2fact'))"});
        snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );            

        var metadataTempTableQuery = "create or replace temporary table \"COMMON\".\"METEOCONTROL_METADATA_"+PROCESS_RUN_ID+"\" as select split_part('"+FILEPATH+"','/',5) as systemkey,type.index,type.typeofmeasurement, id.device_id as deviceid, timestamp.abbr_id as abbreviationid,filename FROM ( select type.index,type.value::string as typeofmeasurement,metadata$filename as filename from @RAW.STG_METEO_CONROL_TIMESERIES_DATA"+FILEPATH+" stg, LATERAL FLATTEN(split(stg.$1::string,',')) type where  stg.$1::string like 'type%') type inner join (select id.index,id.value::string as device_id from @RAW.STG_METEO_CONROL_TIMESERIES_DATA"+FILEPATH+" stg, LATERAL FLATTEN(split(stg.$1::string,',')) id where  stg.$1::string like 'id%') id on type.index = id.index inner join ( select timestamp.index,timestamp.value::string as abbr_id from @RAW.STG_METEO_CONROL_TIMESERIES_DATA"+FILEPATH+" stg, LATERAL FLATTEN(split(stg.$1::string,',')) timestamp where  stg.$1::string like 'timestamp%') timestamp on type.index = timestamp.index where  type.index  > 0";        
        snowflake.execute({sqlText:metadataTempTableQuery});

        var timeseriesTempTableQuery = "create or replace temporary table \"COMMON\".\"METEOCONTROL_TIMESERIES_"+PROCESS_RUN_ID+"\" as select split($1::string,',') as split_column,metadata$filename as filename from @RAW.STG_METEO_CONROL_TIMESERIES_DATA"+FILEPATH+" where $1::string not like 'type%' AND $1::string not like'id%' AND $1::string not like 'timestamp%'";        
        snowflake.execute({sqlText:timeseriesTempTableQuery});


        var stmt = snowflake.createStatement({
              sqlText: "CALL RAW.PROC_LOAD_FACT_TS_MEASUREMENTS('Meteo Control LZ','Meteo Control','"+FILEPATH+"', 0 ,'"+PROCESS_RUN_ID+"', '"+PROCESS_NAME+"');"
                   });  
        var rs = stmt.execute();
        rs.next();
        var outputValue = rs.getColumnValue(1);

     }finally{
        snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
    }
    return outputValue;
$$;
