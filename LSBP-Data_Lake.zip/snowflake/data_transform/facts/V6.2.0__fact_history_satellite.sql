use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

ALTER TABLE raw.FACT_SATELLITE_MEASUREMENTS MODIFY COLUMN original_measure_idx VARCHAR(255);

create or replace procedure "RAW"."PROC_HISTORY_LOAD_FACT_SATELLITE"(SOURCE_DATA_FILTER VARCHAR, PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
  RETURNS string
  LANGUAGE javascript
  strict
  EXECUTE AS caller 
  AS
   $$
      snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','stage2fact'))"});
      snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} ); 
      
      var tempTableName0 = "common.\"TMP_SATELLITE_0_"+PROCESS_RUN_ID+"\"";
      var rowsUpdated = 0, rowsInserted=0;
      
      tempTableSql = "create or replace temporary table "+tempTableName0+" as select inn.*, common.resolve_unknown_dims(ldt.date_key) as local_date_key, common.resolve_unknown_dims(ltm.time_key) as local_time_key, ldt.date as local_date, ltm.time as local_time from (select common.resolve_unknown_dims(dimsite.site_key) as site_key, common.resolve_unknown_dims(dimsat.skey) as measure_key, common.resolve_unknown_dims(dt.date_key) as date_key,common.resolve_unknown_dims(tm.time_key) as time_key, dt.date as sdate, tm.time as stime, common.convert_to_local_tz(sdate,stime,'UTC',coalesce(dimsite.derived_timezone, dimsite.source_timezone)) as local_ts,sat_data.value_decimal as satellite_value, sat_data.site_id::string as original_satellite_site, sat_data.data_series as original_measure_idx, sat_data.TIMESTAMP as original_satellite_ts, 'REFERENCE.PENTAHO_SATELLITE_ADJUSTED_DATA_SERIES' as load_file, row_number() over (partition by sat_data.data_series, sat_data.TIMESTAMP order by sat_data.record_timestamp DESC) as rank from reference.pentaho_satellite_adjusted_data_series sat_data left join curated.dim_satellite_measurements dimsat on dimsat.measure_source_idx=-1 left join curated.dim_sites dimsite on sat_data.site_id=dimsite.site_id_formula left join curated.dim_calendar_date dt on (to_date(sat_data.TIMESTAMP)=dt.date) left join curated.dim_calendar_time tm on (to_time(sat_data.TIMESTAMP)=tm.time)) inn left join curated.dim_calendar_date ldt on (to_date(local_ts)=ldt.date) left join curated.dim_calendar_time ltm on (to_time(local_ts)=ltm.time) where "+SOURCE_DATA_FILTER;
      snowflake.execute( {sqlText: tempTableSql});
    
        
        stmt = snowflake.createStatement({
                   sqlText: "merge into raw.fact_satellite_measurements fact using (select * from "+tempTableName0+" where rank=1 ) sat_data on fact.original_satellite_site = sat_data.original_satellite_site and fact.original_measure_idx = sat_data.original_measure_idx and fact.original_satellite_ts = sat_data.original_satellite_ts when matched then update set fact.site_key = sat_data.site_key, fact.measure_key = sat_data.measure_key, fact.date_key = sat_data.date_key, fact.time_key = sat_data.time_key, fact.sdate = sat_data.sdate, fact.stime = sat_data.stime,fact.local_date_key = sat_data.local_date_key, fact.local_time_key = sat_data.local_time_key, fact.local_date = sat_data.local_date, fact.local_time = sat_data.local_time, fact.satellite_value = sat_data.satellite_value, fact.load_file = sat_data.load_file, fact.updated_ts = sysdate(), fact.process_exec_id = ? when not matched then insert (site_key, measure_key, date_key, time_key, sdate, stime, local_date_key, local_time_key,local_date,local_time, satellite_value,original_satellite_site, original_measure_idx, original_satellite_ts, load_file, created_ts,updated_ts, process_exec_id)   values(sat_data.site_key, sat_data.measure_key, sat_data.date_key, sat_data.time_key, sat_data.sdate, sat_data.stime, sat_data.local_date_key, sat_data.local_time_key, sat_data.local_date, sat_data.local_time, sat_data.satellite_value, sat_data.original_satellite_site, sat_data.original_measure_idx,sat_data.original_satellite_ts,sat_data.load_file, sysdate(), sysdate(), ? )",
                   binds:[ PROCESS_RUN_ID, PROCESS_RUN_ID]
               });  
        rs = stmt.execute();
        rs.next();
        rowsUpdated = rs.getColumnValue(2);
        rowsInserted = rs.getColumnValue(1);
      
        return JSON.stringify({"Rows inserted":rowsInserted,"Rows updated":rowsUpdated});
   $$;
