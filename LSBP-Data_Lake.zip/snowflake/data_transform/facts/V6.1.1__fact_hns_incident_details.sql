use database data_lake_{{ db }};
use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

CREATE OR REPLACE TABLE  REFERENCE.HS_INCIDENTS_DETAILS
(
	  record_id 			integer not null,
      incident_id 			integer null,
      incident_number 		varchar(50) null,
      incident_date 		varchar(30) null,
      report_date 			varchar(30) null,
      last_changed_date 	varchar(30) null,
      location_id 			integer null,
      location_name 		varchar(200) null, 
      location_code 		varchar(20) null,
      incident_status 		varchar(50) null,
      qb_incident_status 	varchar(50) null,
      incident_category 	varchar(100) null,
      incident_title 		varchar null,
      incident_description 	varchar null,
      activity_during_incident varchar null,
      immediate_action 		varchar null,
      history_id 			integer null,
      active 				varchar(50) null,
      created 				varchar(50) null,
      created_by_id 		varchar(50) null,
      last_edited 			varchar(50) null,
      last_edited_by_id	 	varchar(50) null,
      incident_type 		varchar(200) null,
      list_item_id_for_risk_level integer null,
      risk_level 			varchar(50) null,
      priority 				varchar(20) null,
      qb_incident_summary 	varchar null,
      concatenated_root_causes varchar null,
      concatenated_tasks 	varchar null,
      concatenated_roles 	varchar null,
      concatenated_audit_trail varchar null,
      qb_am_category	 	varchar(200) null,
      qb_site_id 			integer null,
      qb_site_status 		varchar(100) null,
      qb_pac_date 			varchar(50) null,
      potential_duplicate 	varchar(50) null,
      record_creation 		datetime,
      process_exec_id       varchar(255), 
      load_ts timestamp   
)DATA_RETENTION_TIME_IN_DAYS = 31 
comment = 'reference table for hs incident details';

CREATE OR REPLACE VIEW RAW.FACT_HS_INCIDENT_DETAILS
AS 
SELECT record_id,
       incident_id,
       site_key,
       incident_number,
       incident_local_date,
       incident_local_time_in_min,
       incident_local_date_key,
       common.Resolve_unknown_dims(incident_local_time.time_key) AS incident_local_time_key,
       incident_utc_date,
       incident_utc_time_in_min,
       common.Resolve_unknown_dims(incident_utc_date.date_key) AS incident_utc_date_key,
       common.Resolve_unknown_dims(incident_utc_time.time_key) AS incident_utc_time_key,
       report_local_date,
       report_local_time_in_min,
       report_local_date_key,
       common.Resolve_unknown_dims(report_local_time.time_key) AS report_local_time_key,
       report_utc_date,
       report_utc_time_in_min,
       common.Resolve_unknown_dims(report_utc_date.date_key) AS report_utc_date_key,
       common.Resolve_unknown_dims(report_utc_time.time_key) AS report_utc_time_key,
       original_incident_date,
       original_report_date,
       location_id,
       location_name,
       location_code,
       incident_status,
       qb_incident_status,
       incident_category,
       incident_title,
       incident_description,
       activity_during_incident,
       immediate_action,
       history_id,
       active,
       incident_type,
       list_item_id_for_risk_level,
       risk_level,
       priority,
       qb_incident_summary,
       concatenated_root_causes,
       concatenated_tasks,
       concatenated_roles,
       concatenated_audit_trail,
       qb_am_category,
       qb_site_id,
       qb_site_status,
       qb_pac_date,
       potential_duplicate,
       last_changed_date,
       created,
       created_by_id,
       last_edited,
       last_edited_by_id,
       record_creation,
       base.process_exec_id,
       load_ts
FROM   
(
SELECT 
record_id,
incident_id,
common.Resolve_unknown_dims(site.site_key) AS site_key,
incident_number,
Try_to_date(incident_date) AS incident_local_date,
CASE 
	WHEN Second(Try_to_time(incident_date,'YYYY-MM-DDTHH24:MI:SS')) > 30 
		THEN Date_trunc('minute', Timeadd('minute', 1, Try_to_time(incident_date,'YYYY-MM-DDTHH24:MI:SS')))
		ELSE Date_trunc('minute', Try_to_time(incident_date,'YYYY-MM-DDTHH24:MI:SS')) 
END AS incident_local_time_in_min,
Try_to_date(common.Convert_to_local_tz(incident_local_date, incident_local_time_in_min, site.derived_timezone, 'UTC')::string)  AS incident_utc_date,
Try_to_time(to_varchar(common.Convert_to_local_tz(incident_local_date, incident_local_time_in_min, site.derived_timezone, 'UTC'),'YYYY-MM-DDTHH24:MI:SS'),'YYYY-MM-DDTHH24:MI:SS') AS incident_utc_time_in_min,
common.Resolve_unknown_dims(incident_local_date.date_key) AS incident_local_date_key,
Try_to_date(report_date) AS report_local_date,
CASE 
	WHEN Second(Try_to_time(report_date,'YYYY-MM-DDTHH24:MI:SS')) > 30 
		THEN Date_trunc('minute', Timeadd('minute', 1, Try_to_time(report_date,'YYYY-MM-DDTHH24:MI:SS'))) 
		ELSE Date_trunc('minute', Try_to_time(report_date,'YYYY-MM-DDTHH24:MI:SS')) 
END AS report_local_time_in_min, 
Try_to_date(common.Convert_to_local_tz(report_local_date, report_local_time_in_min, site.derived_timezone, 'UTC')::string) AS report_utc_date,
Try_to_time(to_varchar(common.Convert_to_local_tz(report_local_date, report_local_time_in_min, site.derived_timezone, 'UTC'),'YYYY-MM-DDTHH24:MI:SS'),'YYYY-MM-DDTHH24:MI:SS') AS report_utc_time_in_min,
common.Resolve_unknown_dims(report_local_date.date_key) AS report_local_date_key,
incident_date AS original_incident_date,
report_date AS original_report_date,
location_id,
location_name,
location_code,
incident_status,
qb_incident_status,
incident_category,
incident_title,
incident_description,
activity_during_incident,
immediate_action,
history_id,
active,
incident_type,
list_item_id_for_risk_level,
risk_level,
priority,
qb_incident_summary,
concatenated_root_causes,
concatenated_tasks,
concatenated_roles,
concatenated_audit_trail,
qb_am_category,
qb_site_id,
qb_site_status,
qb_pac_date,
potential_duplicate,
last_changed_date,
created,
created_by_id,
last_edited,
last_edited_by_id,
record_creation,
ref.process_exec_id,
load_ts
FROM   REFERENCE.HS_INCIDENTS_DETAILS ref
LEFT JOIN curated.dim_sites site
ON ( ref.qb_site_id = site.site_id_formula )
    OR ( ref.location_code = site.site_reference_formula )
LEFT JOIN curated.dim_calendar_date incident_local_date
ON Try_to_date(ref.incident_date) = incident_local_date.date
LEFT JOIN curated.dim_calendar_date report_local_date
ON Try_to_date(ref.report_date) = report_local_date.date) base
LEFT JOIN curated.dim_calendar_date incident_utc_date
ON base.incident_utc_date = incident_utc_date.date
LEFT JOIN curated.dim_calendar_date report_utc_date
ON base.report_utc_date = report_utc_date.date
LEFT JOIN curated.dim_calendar_time incident_local_time
ON base.incident_local_time_in_min = incident_local_time.time
LEFT JOIN curated.dim_calendar_time report_local_time
ON base.report_local_time_in_min = report_local_time.time
LEFT JOIN curated.dim_calendar_time incident_utc_time
ON base.incident_utc_time_in_min = incident_utc_time.time
LEFT JOIN curated.dim_calendar_time report_utc_time
ON base.report_utc_time_in_min = report_utc_time.time 
order by site_key ;

