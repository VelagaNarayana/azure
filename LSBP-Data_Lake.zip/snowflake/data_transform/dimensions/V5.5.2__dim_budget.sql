use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';


CREATE OR REPLACE TABLE CURATED.DIM_BUDGETS (
  BUDGET_KEY	        INTEGER IDENTITY,
  SITE_KEY	            INTEGER	        NOT NULL,
  SITE_ID_FORMULA       INTEGER         NULL,
  BUDGET_MODEL_NAME	    VARCHAR(1000)   NOT NULL,  
  BUDGET_CATEGORY	    VARCHAR(1000)   NULL,  
  COMMENT	            VARCHAR(5000)   NULL,  
  VALID_FROM	        DATE            NULL,  
  VALID_TO	            DATE            NULL,  
  PROCESS_EXEC_ID	    VARCHAR(100)    NULL,  
  CREATED_TS	        TIMESTAMP       NULL,  
  UPDATED_TS	        TIMESTAMP       NULL,  
  LOAD_FILE	            VARCHAR(500)    NULL
) DATA_RETENTION_TIME_IN_DAYS = 31
comment = "Dimension table of budgets";


CREATE OR REPLACE PROCEDURE  "RAW"."PROC_UPSERT_DIM_BUDGETS"(SOURCE_FILE_PATH VARCHAR,SOURCE_FILE_NAME VARCHAR,PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller 
AS
 $$
   try{
        snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','blob2DimTable'))"});
        snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} ); 

       	var tempTableName = "COMMON.\"TEMP_DIM_BUDGET_"+PROCESS_RUN_ID+"\"";
	    var rowsUpdated = 0, rowsInserted=0;

			
        var select_query = "CREATE OR REPLACE TEMPORARY TABLE "+tempTableName+" AS SELECT budget.site_id_formula,common.resolve_unknown_dims(site.site_key) AS site_key, budget_model_name, budget_category,comment as budeget_model_comment, valid_from, valid_to, budget.load_file FROM  (SELECT DISTINCT $1 as site_id_formula,$4 as budget_model_name,$5 as budget_category,$6 as comment,$7::date as valid_from, $8::date as valid_to,metadata$filename as load_file FROM @RAW.STG_BUDGET_DATASET/"+SOURCE_FILE_PATH+"/"+SOURCE_FILE_NAME+") budget LEFT JOIN curated.dim_sites site ON budget.site_id_formula = site.site_id_formula";
        snowflake.execute({sqlText: select_query});

        var stmt = snowflake.createStatement({
               sqlText: "MERGE INTO CURATED.DIM_BUDGETS target_table USING "+tempTableName+" source_table  ON target_table.site_id_formula = source_table.site_id_formula AND target_table.budget_model_name = source_table.budget_model_name AND coalesce(target_table.budget_category,'') = coalesce(source_table.budget_category,'')  WHEN MATCHED THEN  UPDATE 	SET target_table.site_key = source_table.site_key, target_table.comment = source_table.budeget_model_comment, target_table.valid_from = source_table.valid_from, target_table.valid_to = source_table.valid_to, target_table.process_exec_id = ?, target_table.load_file = source_table.load_file, target_table.updated_ts = SYSDATE() WHEN NOT MATCHED THEN INSERT(SITE_KEY,SITE_ID_FORMULA,BUDGET_MODEL_NAME,BUDGET_CATEGORY,COMMENT,VALID_FROM,VALID_TO,PROCESS_EXEC_ID,CREATED_TS,UPDATED_TS,LOAD_FILE) VALUES(source_table.site_key,source_table.site_id_formula,source_table.budget_model_name,source_table.budget_category,source_table.budeget_model_comment,source_table.valid_from,source_table.valid_to, ? ,SYSDATE(),SYSDATE(), source_table.load_file) ",
                binds:[PROCESS_RUN_ID, PROCESS_RUN_ID]
        });  
        var rsMergeQuery = stmt.execute();
        rsMergeQuery.next();
        var count = {"Inserted":rsMergeQuery.getColumnValue(1),"Updated":rsMergeQuery.getColumnValue(2)};

        var select_missing_unkonwm_record_query = "MERGE INTO CURATED.DIM_BUDGETS target_table USING ( SELECT 0 AS budget_key, 0 as site_key, 0 as site_id_formula,'Missing' as budget_model_name,'Missing' as budget_category, 'Missing' as budeget_model_comment  UNION SELECT -1 AS budget_key, -1 as site_key, -1 as site_id_formula,'Unknown' as budget_model_name,'Unknown' as budget_category, 'Unknown' as budeget_model_comment) source_table ON target_table.budget_key = source_table.budget_key WHEN MATCHED THEN  UPDATE SET target_table.site_key = source_table.site_key, target_table.site_id_formula = source_table.site_id_formula, target_table.budget_model_name = source_table.budget_model_name, target_table.budget_category = source_table.budget_category, target_table.comment =  source_table.budeget_model_comment, target_table.valid_from = NULL, target_table.valid_to = NULL, target_table.process_exec_id = 'NA', target_table.updated_ts = NULL, target_table.load_file = 'NA' WHEN NOT MATCHED THEN INSERT(BUDGET_KEY,SITE_KEY,SITE_ID_FORMULA,BUDGET_MODEL_NAME,BUDGET_CATEGORY,COMMENT,PROCESS_EXEC_ID,LOAD_FILE) VALUES(source_table.budget_key,source_table.site_key,source_table.site_id_formula,source_table.budget_model_name,source_table.budget_category,source_table.budeget_model_comment,'NA' ,'NA')";
        snowflake.execute({sqlText: select_missing_unkonwm_record_query});

        }finally{
            snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
        }
    return JSON.stringify({"Budets":count});
$$
;
