use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace view curated.dim_prod_meter_details as
select 
     met.meter_key as METER_KEY 
     , met.meter_id as METER_ID
    , common.resolve_unknown_dims(ss.site_key) as SITE_FKEY
    , METER_REFERENCE
    , MPAN
    , SOURCE 
    , EXPORT_OR_IMPORT 
    , TYPE_OF_METER 
    , METER_USED_IN_REPORTING 
    , case when source='Insolar' then sd.DEVICE_SERIAL_NUMBER  else METER_SERIAL_NUMBER end as meter_serial_number
    , SIM_NUMBER_IP_DIALLER 
    , case when source='Insolar' then  sd.DEVICE_MODEL else METER_MAKE_MODEL end as meter_make_model
    , met.data_source as dim_source
    , met.PROCESS_EXEC_ID 
    , met.updated_ts  
    , smsr.MEASUREMENT_KEY,smsr.MEASUREMENT_ID,smsr.MEASUREMENT_APCODE,smsr.MEASUREMENT_NAME,smsr.PARAMETER_TYPE,smsr.MEASUREMENT_TYPE,smsr.CALCULATION_PERIOD_NAME,smsr.DATA_TYPE,smsr.ENGINEERING_UNIT
    , sd.DEVICE_KEY,sd.DEVICE_ID,sd.DEVICE_APCODE,sd.DEVICE_NAME,sd.DEVICE_MODEL,sd.DEVICE_SERIAL_NUMBER,sd.DEVICE_TYPE,sd.MANUFACTURER,sd.PARENT
from (select -1 as meter_key, 'Unknown' as meter_id,'Unknown' as data_source,NULL as updated_ts,'NA' as process_exec_id
      union
      select 0 as meter_key, 'Missing' as meter_id,'Missing' as data_source,NULL as updated_ts,'NA' as process_exec_id
      union
      select * from reference.source_prod_meter_details) met
left join "REFERENCE"."QB_O_M_METERS_DATABASE" qb on met.meter_id=qb.meter_id
left join "REFERENCE"."QB_O_M_SITE_MASTER" sm on qb.o_m_site_master_site_id_formula=sm.site_id_formula
left join reference.source_sites ss on 
    (sm.site_id_insolar!='61a6bfc2-e958-11e6-934a-42010afa015a' and ss.site_id=sm.site_id_insolar) or
    (sm.site_id_insolar='61a6bfc2-e958-11e6-934a-42010afa015a' and contains(regexp_replace(site_name_formula, 'Lough Road 2 | Road',''),ss.site_name))
left join reference.source_measurements smsr on smsr.measurement_id = met.meter_id
left join reference.source_devices sd on smsr.device_fkey = sd.device_key;