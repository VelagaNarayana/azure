use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace table curated.dim_solar_gis_satellite(
    skey int not null identity(1,1),
    measure_short_name varchar(10) not null,
    measure_long_name varchar(100) not null,
    measure_source_idx smallint not null,
    updated_ts datetime default sysdate(),
    CONSTRAINT pk_dimsolargis_skey  PRIMARY KEY (skey),
    CONSTRAINT uniqk_dimsolargis_shortname  UNIQUE (measure_short_name)
);

insert into curated.dim_solar_gis_satellite(skey, measure_short_name, measure_long_name,measure_source_idx) values(-1,'?','Unknown',-2);
insert into curated.dim_solar_gis_satellite(skey, measure_short_name, measure_long_name,measure_source_idx) values(0,'!','Missing',-1);
insert into curated.dim_solar_gis_satellite(measure_short_name, measure_long_name,measure_source_idx) values('GHI','Global Horizontal Irradiation',0);
insert into curated.dim_solar_gis_satellite(measure_short_name, measure_long_name,measure_source_idx) values('GTI','Global Tilted Irradiation',1);
insert into curated.dim_solar_gis_satellite(measure_short_name, measure_long_name,measure_source_idx) values('TEMP','Air Temperature',2);