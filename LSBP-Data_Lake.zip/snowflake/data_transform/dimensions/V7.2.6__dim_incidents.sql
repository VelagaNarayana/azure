use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

CREATE OR REPLACE TABLE CURATED.DIM_INCIDENTS
(
    INCIDENT_KEY                                        INT IDENTITY(1,1) NOT NULL,
    SITE_FKEY                                           INTEGER,
    INCIDENT_ID                                         INTEGER NOT NULL       		comment 'record_id',  
    INCIDENT_START                                      TIMESTAMP					comment 'incident_start',  
    INCIDENT_END                                        TIMESTAMP					comment 'incident_end',  	 	
    INCIDENT_STATUS                                     VARCHAR     				comment 'incident_status',  	
    INCIDENT_CATEGORY                                   VARCHAR 					comment 'incident_category',  
    EXCLUSION_PERIOD_START                              TIMESTAMP					comment 'exclusion_period_start',  	
    EXCLUSION_PERIOD_END                                TIMESTAMP					comment 'exclusion_period_end',  	
    EXCLUSION_REQUESTED_BY_REGIONAL_MANAGER    			VARCHAR 					comment 'exclusion_requested_by_regional_manager',  	
    TYPE_OF_OUTAGE                                      VARCHAR 					comment 'type_of_outage',  	
    AM_EXCLUSION_STATUS                                 VARCHAR 					comment 'am_exclusion_status',  
    TEST_KPI                                            VARCHAR	    				comment 'test_kpi',  
    FLAG_AS_EXCLUSION                                   VARCHAR                     comment 'flag_as_exclusion',
    DATE_CREATED                                        TIMESTAMP					comment 'date_created',  
    DATE_MODIFIED                                       TIMESTAMP					comment 'date_modified', 
	INCIDENT_CAUSE                                      VARCHAR(1000) comment 'incident_cause',
	MAIN_CAUSE											VARCHAR(1000) comment 'main_cause',
	ROOT_CAUSE											VARCHAR(1000) comment 'root_cause',
	MAINTENANCE_PERFORMED								VARCHAR(5000) comment 'maintenance_performed',
	REQUESTER											VARCHAR(1000) comment 'requester',
	AVAILABILITY_EXCLUSION_STATUS						VARCHAR(1000) comment 'availability_exclusion_status',
	ACCEPTED_REJECTED_BY								VARCHAR(1000) comment 'accepted_rejected_by',
	DATE_AVAILABILITY_EXCLUSION_RAISED					DATE		  comment 'date_availability_exclusion_raised',
	EXCLUSION_COMMENTS									VARCHAR(5000) comment 'exclusion_comments',
	AM_EXCLUSION_COMMENTS								VARCHAR(5000) comment 'AM_EXCLUSION_COMMENTS',			
	SV_JOB_NUMBER_S 									VARCHAR(1000) comment 'SV_JOB_NUMBER_S',
	EVIDENCE_OWNER 										VARCHAR(1000) comment 'EVIDENCE_OWNER',
	LATEST_EXCLUSION_STATUS 							VARCHAR(5000) comment 'LATEST_EXCLUSION_STATUS',
	PRODUCTION_CONFIRMED 								VARCHAR(1000) comment 'PRODUCTION_CONFIRMED_',
	PLANNED_OR_FAULT 									VARCHAR(1000) comment 'PLANNED_OR_FAULT',
	IRRADIANCE_SOURCE_AVAILABLE 						VARCHAR(1000) comment 'IRRADIANCE_SOURCE_AVAILABLE',
	ACTION_TAKEN 										VARCHAR(5000) comment 'ACTION_TAKEN',
	ENGINEERING_ASSISTANCE 								VARCHAR(5000) comment 'ENGINEERING_ASSISTANCE',
	ENGINEERING_SUPPORT_CATEGORY 						VARCHAR(5000) comment 'ENGINEERING_SUPPORT_CATEGORY',
	ENGINEERING_SUPPORT_PRIORITY 						VARCHAR(5000) comment 'ENGINEERING_SUPPORT_PRIORITY',
	ENGINEER_ASSIGNED 									VARCHAR(1000) comment 'ENGINEER_ASSIGNED',
	SITE_VISIT_ATTENDANCE 								VARCHAR(1000) comment 'SITE_VISIT_ATTENDANCE',
	SITE_VISIT_ESTIMATE_DATE 							DATE comment 'SITE_VISIT_ESTIMATE_DATE',
	COMMENTS							VARCHAR(10000) comment 'COMMENTS',								
	O_M_EXCLUSION_COMMENTS				VARCHAR(10000) comment 'O_M_EXCLUSION_COMMENTS',						
	RM_COMMENT							VARCHAR(10000) comment 'RM_COMMENT',
	LATEST_COMMENT						VARCHAR(10000) comment 'LATEST_COMMENT',
	ENGINEER_COMMENTS					VARCHAR(10000) comment 'ENGINEER_COMMENTS',
	NUMBER_OF_DEVICES_NOT_PRODUCING		NUMBER(38,0) comment 'NUMBER_OF_DEVICES_NOT_PRODUCING',
	NUMBER_OF_DEVICES_NOT_COMMUNICATING	NUMBER(38,0) comment 'NUMBER_OF_DEVICES_NOT_COMMUNICATING',
	ENGINEERING_SUPPORT_STATUS			VARCHAR(1000) comment 'ENGINEERING_SUPPORT_STATUS',
	HEALTH_AND_SAFETY_ISSUE				VARCHAR(5000) comment 'HEALTH_AND_SAFETY_ISSUE',
	INCIDENT_SOURCE						VARCHAR(1000) comment 'INCIDENT_SOURCE',
	INVERTER_S_N_S_NEW					VARCHAR(1000) comment 'INVERTER_S_N_S_NEW',
	INVERTER_S_N_S_OLD					VARCHAR(1000) comment 'INVERTER_S_N_S_OLD',
	INCIDENT_RESOLUTION					VARCHAR(5000) comment 'INCIDENT_RESOLUTION',
	ONGOING_ISSUES_CHECK				VARCHAR(5000) comment '	ONGOING_ISSUES_CHECK',
	INCIDENT_REFERENCE					VARCHAR(1000) comment 'INCIDENT_REFERENCE',
	ACCEPTED_REJECTED_DATE_AND_TIME DATETIME comment 'ACCEPTED_REJECTED_DATE_AND_TIME',
	REQUESTED_DATE_AND_TIME				DATETIME comment 'REQUESTED_DATE_AND_TIME',
	TICKET_PRIORITY						VARCHAR(1000) comment 'TICKET_PRIORITY',
    PROCESS_EXEC_ID                     VARCHAR(255),
    CREATED_TS                          TIMESTAMP,
    UPDATED_TS                          TIMESTAMP
) comment = "Table of site capacity calculation";

CREATE OR REPLACE PROCEDURE  "RAW"."PROC_UPSERT_DIM_INCIDENTS"(SOURCE_TABLE_NAME_WITH_SCHEMA VARCHAR ,PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller 
AS
 $$
    try{
         snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','stage2ref'))"});
         snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} ); 
          
         var stmtColumnList = snowflake.createStatement({
         sqlText: "select listagg(column_name,',') WITHIN GROUP ( order by ordinal_position ),listagg(concat('new.',comment),', ') WITHIN GROUP ( order by ordinal_position ), listagg(concat('old.',column_name,' = ','new.',comment),', ') WITHIN GROUP ( order by ordinal_position ) from INFORMATION_SCHEMA.COLUMNS where table_schema = 'CURATED' and table_name = 'DIM_INCIDENTS' and comment is not null  group by table_name, table_schema"});  
         var rsSelectQuery = stmtColumnList.execute();
         rsSelectQuery.next()         
         var targetColumnList  = rsSelectQuery.getColumnValue(1);
         var insertColumnList  = rsSelectQuery.getColumnValue(2);         
         var updateColumnList  = rsSelectQuery.getColumnValue(3);
         
         var sqlCmd;
        
         var loadCmd = "merge into curated.dim_incidents old using (select inc.*,common.resolve_unknown_dims(site.site_key) as site_fkey from "+SOURCE_TABLE_NAME_WITH_SCHEMA+" inc left join curated.dim_sites site on (inc.site_id = site.site_id_formula or inc.site_reference = site.site_reference_formula)) new on old.incident_id = new.record_id when matched then update set "+updateColumnList+",old.site_fkey = new.site_fkey,old.PROCESS_EXEC_ID = ?, UPDATED_TS = SYSDATE() when not matched then insert("+targetColumnList+",SITE_FKEY,PROCESS_EXEC_ID,CREATED_TS,UPDATED_TS) values("+insertColumnList+",new.site_fkey,?,SYSDATE(),SYSDATE())",
         
         sqlCmd = {sqlText: loadCmd, binds:[PROCESS_RUN_ID, PROCESS_RUN_ID]};
         var stmt = snowflake.createStatement(sqlCmd);
         var rs = stmt.execute();
         rs.next();      
         rowInserted= rs.getColumnValue(1);
         rowUpdated= rs.getColumnValue(2);
     }       
     finally{
        snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
     }

     return JSON.stringify({"Inserted":rowInserted,"Updated":rowUpdated});                      
$$;
