use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace table CURATED.DIM_SATELLITE_MEASUREMENTS(
    skey int not null identity(1,1),
    measure_short_name varchar(10) not null,
    measure_long_name varchar(100) not null,
	profile varchar(3) not null,
	measure_name varchar(20),
    measure_source_idx smallint not null,
    updated_ts datetime default sysdate(),
    CONSTRAINT pk_dimsolargis_skey  PRIMARY KEY (skey),
    CONSTRAINT uniqk_dimsolargis_shortname  UNIQUE (measure_short_name)
);
insert into CURATED.DIM_SATELLITE_MEASUREMENTS(skey, measure_short_name, measure_long_name,profile,measure_source_idx) values(-1,'?','Unknown','-1',-2);
insert into CURATED.DIM_SATELLITE_MEASUREMENTS(skey, measure_short_name, measure_long_name,profile,measure_source_idx) values(0,'!','Missing','0',-1);
insert into CURATED.DIM_SATELLITE_MEASUREMENTS(measure_short_name, measure_long_name,profile,measure_name,measure_source_idx) values('GHI','Global Horizontal Irradiation','1','GHI 1',0);
insert into CURATED.DIM_SATELLITE_MEASUREMENTS(measure_short_name, measure_long_name,profile,measure_name,measure_source_idx) values('GTI','Global Tilted Irradiation','1','GTI 1',1);
insert into CURATED.DIM_SATELLITE_MEASUREMENTS(measure_short_name, measure_long_name,profile,measure_name,measure_source_idx) values('TEMP','Air Temperature','1','TEMP 1',2);
insert into CURATED.DIM_SATELLITE_MEASUREMENTS(measure_short_name, measure_long_name,profile,measure_name,measure_source_idx) values('GHI','Global Horizontal Irradiation','2','GHI 2',0);
insert into CURATED.DIM_SATELLITE_MEASUREMENTS(measure_short_name, measure_long_name,profile,measure_name,measure_source_idx) values('GTI','Global Tilted Irradiation','2','GTI 2',1);
insert into CURATED.DIM_SATELLITE_MEASUREMENTS(measure_short_name, measure_long_name,profile,measure_name,measure_source_idx) values('TEMP','Air Temperature','2','TEMP 2',2);


