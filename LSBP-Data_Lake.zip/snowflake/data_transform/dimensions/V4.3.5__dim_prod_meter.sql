use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace table reference.source_prod_meter_details (
    meter_key int IDENTITY(1,1) NOT NULL,
    meter_id varchar(255) not null,
    data_source varchar(50),
    updated_ts datetime NULL,
    process_exec_id varchar(255) NULL,
    CONSTRAINT   pk_refprodmeter_meterkey  PRIMARY KEY (meter_key)
) DATA_RETENTION_TIME_IN_DAYS = 31;

create or replace procedure "REFERENCE"."PROC_INSERT_NEW_METER_REF"(PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller 
AS
 $$
        try{
            var dataSource = "QB";
            snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','stage2dim'))"});
            snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} ); 
            
            var stmt = snowflake.createStatement({
                       sqlText: "insert into reference.source_prod_meter_details(meter_id,data_source,updated_ts,process_exec_id) select meter_id,? as data_source,sysdate() as updated_ts,? as process_exec_id from reference.qb_o_m_meters_database new where not exists (select * from reference.source_prod_meter_details dim where dim.meter_id=new.meter_id and dim.data_source=?)",
                       binds:[ dataSource, PROCESS_RUN_ID,dataSource]
                   });  
            var rs = stmt.execute();
            rs.next();
            var count = rs.getColumnValue(1);
            
        }finally{
            snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
        }

    return JSON.stringify({"Meters keyed(inserted)":count});
 $$
 ;


create or replace view curated.dim_prod_meter_details as
select 
     met.meter_key as METER_KEY 
     , met.meter_id as METER_ID
    , common.resolve_unknown_dims(ss.site_key) as SITE_FKEY
    , METER_REFERENCE
    , MPAN
    , SOURCE 
    , EXPORT_OR_IMPORT 
    , TYPE_OF_METER 
    , METER_USED_IN_REPORTING 
    , METER_SERIAL_NUMBER 
    , SIM_NUMBER_IP_DIALLER 
    , METER_MAKE_MODEL 
    , met.data_source
    , met.PROCESS_EXEC_ID 
    , met.updated_ts  
from (select -1 as meter_key, 'Unknown' as meter_id,'Unknown' as data_source,NULL as updated_ts,'NA' as process_exec_id
      union
      select 0 as meter_key, 'Missing' as meter_id,'Missing' as data_source,NULL as updated_ts,'NA' as process_exec_id
      union
      select * from reference.source_prod_meter_details) met
left join "REFERENCE"."QB_O_M_METERS_DATABASE" qb on met.meter_id=qb.meter_id
left join "REFERENCE"."QB_O_M_SITE_MASTER" sm on qb.o_m_site_master_site_id_formula=sm.site_id_formula
left join reference.source_sites ss on ss.site_id=sm.site_id_insolar;