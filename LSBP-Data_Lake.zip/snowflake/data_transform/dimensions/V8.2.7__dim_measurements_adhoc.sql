use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

insert into "REFERENCE"."SOURCE_MEASUREMENTS"  ( DEVICE_FKEY, MEASUREMENT_ID, MEASUREMENT_APCODE, MEASUREMENT_NAME, PARAMETER_TYPE, MEASUREMENT_TYPE, CALCULATION_PERIOD_NAME, DATA_TYPE, ENGINEERING_UNIT, DATA_SOURCE, CREATED_TS, UPDATED_TS, PROCESS_EXEC_ID )  
select devices.device_key as device_fkey, concat(site_name_formula,'-',msrmnts.name) as measurement_id, msrmnts.apcode as measurement_apcode, msrmnts.name as measurement_name, msrmnts.ptype as measurement_type, msrmnts.mtype as measurement_type, msrmnts.calc_period as calculation_period_name, msrmnts.dtype as data_type, msrmnts.eunit as engineering_unit,'Adhoc/Manual',sysdate(),sysdate(),'DevOps V8.2.6' as process_exec_id
from
(select 'Portable Pyros Irradiance' as apcode, 'IrrAve' as name, NULL as ptype ,'Irradiance' as mtype ,'15m' as  calc_period,'Float' as dtype, NULL as eunit
union select 'Portable Pyros Irradiance' as apcode, 'IrrMin' as name, NULL as ptype ,'Irradiance' as mtype ,'15m' as  calc_period,'Float' as dtype, NULL as eunit
union select 'Portable Pyros Irradiance' as apcode, 'IrrMax' as name, NULL as ptype ,'Irradiance' as mtype ,'15m' as  calc_period,'Float' as dtype, NULL as eunit
union select 'Portable Pyros Irradiance' as apcode, 'IrrSD' as name, NULL as ptype ,'Irradiance' as mtype ,'15m' as  calc_period,'Float' as dtype, NULL as eunit
union select 'Portable Pyros Irradiance' as apcode, 'VbAve' as name, NULL as ptype ,'Irradiance' as mtype ,'15m' as  calc_period,'Float' as dtype, NULL as eunit
union select 'Portable Pyros Irradiance' as apcode, 'Vbmin' as name, NULL as ptype ,'Irradiance' as mtype ,'15m' as  calc_period,'Float' as dtype, NULL as eunit
union select 'Portable Pyros Irradiance' as apcode, 'CSQAve' as name, NULL as ptype ,'Irradiance' as mtype ,'15m' as  calc_period,'Float' as dtype, NULL as eunit
union select 'Portable Pyros Irradiance' as apcode, 'CSQMin' as name, NULL as ptype ,'Irradiance' as mtype ,'15m' as  calc_period,'Float' as dtype, NULL as eunit) msrmnts
join curated.dim_sites sites on site_name_formula='Howton Farm'
join curated.dim_devices devices on devices.device_apcode='Site' and sites.site_key=devices.site_fkey
where measurement_id not in (select measurement_id from curated.dim_measurements)