use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

CREATE TABLE IF NOT EXISTS reference.source_measurements
(
    measurement_key int IDENTITY(1,1) NOT NULL,
    device_fkey int NOT NULL,
    measurement_id varchar(255) NOT NULL,
    measurement_apcode	varchar(255),
    measurement_name	varchar(255),
    parameter_type	varchar(255),
    measurement_type	varchar(255),
    calculation_period_name	VARCHAR(50),
	data_type	varchar(30),
	engineering_unit	varchar(255),
    data_source varchar(30) NULL,
    created_ts datetime NULL,
	updated_ts datetime NULL,
    process_exec_id varchar(255) NULL,
    CONSTRAINT pk_dimmeasures_msrkey  PRIMARY KEY (measurement_key),
    CONSTRAINT uniqk_dimmeasures_msrid  UNIQUE (measurement_id),
    CONSTRAINT fk_dim_measures_devices FOREIGN KEY (device_fkey) REFERENCES reference.source_devices(device_key)
) DATA_RETENTION_TIME_IN_DAYS = 31
 CLUSTER BY (measurement_id);

ALTER TABLE "REFERENCE"."SOURCE_MEASUREMENTS" ADD COLUMN  LOAD_FILE VARCHAR(1000);

CREATE OR REPLACE PROCEDURE "RAW"."PROC_UPSERT_SOURCE_MEASUREMENTS"(SOURCE_FILTER_OR_PATH VARCHAR,SOURCE_SYSTEM VARCHAR ,PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller 
AS
 $$
        try{
            snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','stage2ref'))"});
            snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} ); 
            
            var stmt = snowflake.createStatement({
            sqlText: "select common.replace_query(query,'"+SOURCE_FILTER_OR_PATH+"','"+SOURCE_SYSTEM+"','"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"') from CONTROL.DIMENSION_TABLE_LOAD_QUERIES where data_source = '"+SOURCE_SYSTEM+"' and dim_table = 'SOURCE_MEASUREMENTS'"});  
            var rsSelectQuery = stmt.execute();
			var selectQueryForTempTable;
			if(rsSelectQuery.next()){
				selectQueryForTempTable = rsSelectQuery.getColumnValue(1);
			} else {
				throw "Parsing for source system - "+SOURCE_SYSTEM+" not configured in the table CONTROL.DIMENSION_TABLE_LOAD_QUERIES"
			};
			
            var select_query = "create or replace temporary table common.tmp_measurements_meta as "+selectQueryForTempTable;

            snowflake.execute({sqlText: select_query});       
       
            stmt = snowflake.createStatement({
                       sqlText: "merge into reference.source_measurements dim using common.tmp_measurements_meta new on dim.measurement_id = new.measurement_id  and dim.data_source = '"+SOURCE_SYSTEM+"' when matched then update set dim.DEVICE_FKEY = new.DEVICE_FKEY,dim.MEASUREMENT_APCODE = new.MEASUREMENT_APCODE,dim.MEASUREMENT_NAME = new.MEASUREMENT_NAME,dim.PARAMETER_TYPE = new.PARAMETER_TYPE,dim.MEASUREMENT_TYPE = new.MEASUREMENT_TYPE,dim.CALCULATION_PERIOD_NAME = new.CALCULATION_PERIOD_NAME,dim.DATA_TYPE = new.DATA_TYPE,dim.ENGINEERING_UNIT = new.ENGINEERING_UNIT,dim.UPDATED_TS = sysdate(),dim.PROCESS_EXEC_ID =?,dim.data_source=?,dim.LOAD_FILE = new.LOAD_FILE when not matched then insert (DEVICE_FKEY, MEASUREMENT_ID, MEASUREMENT_APCODE, MEASUREMENT_NAME, PARAMETER_TYPE, MEASUREMENT_TYPE, CALCULATION_PERIOD_NAME, DATA_TYPE, ENGINEERING_UNIT, CREATED_TS, UPDATED_TS, PROCESS_EXEC_ID, DATA_SOURCE,LOAD_FILE) values (new.DEVICE_FKEY,new.MEASUREMENT_ID,new.MEASUREMENT_APCODE,new.MEASUREMENT_NAME,new.PARAMETER_TYPE,new.MEASUREMENT_TYPE,new.CALCULATION_PERIOD_NAME,new.DATA_TYPE,new.ENGINEERING_UNIT,sysdate(),sysdate(),?,?,new.LOAD_FILE)",
                       binds:[ PROCESS_RUN_ID,SOURCE_SYSTEM,PROCESS_RUN_ID,SOURCE_SYSTEM]
                   });  
            var rs = stmt.execute();
            rs.next();
            var msrCnt = {"Inserted":rs.getColumnValue(1),"Updated":rs.getColumnValue(2)};

        }finally{
            snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
        }
    return JSON.stringify({ "measurements" : msrCnt });
 $$
 ;


create or replace view curated.dim_measurements as
select 0 as MEASUREMENT_KEY ,0 as DEVICE_FKEY ,'!' as MEASUREMENT_ID ,'Missing' as MEASUREMENT_APCODE ,'Missing' as MEASUREMENT_NAME ,'Missing' as PARAMETER_TYPE ,'Missing' as MEASUREMENT_TYPE ,'Missing' as CALCULATION_PERIOD_NAME ,'Missing' as DATA_TYPE ,'Missing' as ENGINEERING_UNIT ,'Missing' as DATA_SOURCE ,NULL as CREATED_TS ,NULL as UPDATED_TS ,'NA' as PROCESS_EXEC_ID,'NA' as LOAD_FILE
union
select -1 as MEASUREMENT_KEY ,-1 as DEVICE_FKEY ,'?' as MEASUREMENT_ID ,'Unknown' as MEASUREMENT_APCODE ,'Unknown' as MEASUREMENT_NAME ,'Unknown' as PARAMETER_TYPE ,'Unknown' as MEASUREMENT_TYPE ,'Unknown' as CALCULATION_PERIOD_NAME ,'Unknown' as DATA_TYPE ,'Unknown' as ENGINEERING_UNIT ,'Unknown' as DATA_SOURCE ,NULL as CREATED_TS ,NULL as UPDATED_TS ,'NA' as PROCESS_EXEC_ID, 'NA' as LOAD_FILE
union
select * from reference.source_measurements;