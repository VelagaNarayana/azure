use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';


create or replace view curated.dim_devices as
select 0 as DEVICE_KEY ,0 as SITE_FKEY ,'!' as DEVICE_ID ,'Missing' as DEVICE_APCODE ,'Missing' as DEVICE_NAME ,'Missing' as DEVICE_MODEL ,'Missing' as DEVICE_SERIAL_NUMBER ,'Missing' as DEVICE_TYPE ,'Missing' as MANUFACTURER ,'Missing' as PARENT ,'Missing' as DATA_SOURCE ,NULL as CREATED_TS ,NULL as UPDATED_TS ,'NA' as PROCESS_EXEC_ID, 'NA' as LOAD_FILE,NULL as capacity
union
select -1 as DEVICE_KEY ,-1 as SITE_FKEY ,'?' as DEVICE_ID ,'Unknown' as DEVICE_APCODE ,'Unknown' as DEVICE_NAME ,'Unknown' as DEVICE_MODEL ,'Unknown' as DEVICE_SERIAL_NUMBER ,'Unknown' as DEVICE_TYPE ,'Unknown' as MANUFACTURER ,'Unknown' as PARENT ,'Unknown' as DATA_SOURCE ,NULL as CREATED_TS ,NULL as UPDATED_TS ,'NA' as PROCESS_EXEC_ID, 'NA' as LOAD_FILE,NULL as capacity
union
select device.*,device_capacity.calculated_capacity as capacity from reference.source_devices device left join reference.source_device_capacity device_capacity ON device.site_fkey = device_capacity.site_key and device.device_key = device_capacity.device_key;


