use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

CREATE OR REPLACE PROCEDURE  "RAW"."PROC_UPSERT_DIM_INCIDENTS"(SOURCE_TABLE_NAME_WITH_SCHEMA VARCHAR ,PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller 
AS
 $$
    try{
         snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','stage2ref'))"});
         snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} ); 
          
         var stmtColumnList = snowflake.createStatement({
         sqlText: "select listagg(column_name,',') WITHIN GROUP ( order by ordinal_position ),listagg(concat('new.',comment),', ') WITHIN GROUP ( order by ordinal_position ), listagg(concat('old.',column_name,' = ','new.',comment),', ') WITHIN GROUP ( order by ordinal_position ),listagg(concat('inc.',comment),',') WITHIN GROUP ( order by ordinal_position ) from INFORMATION_SCHEMA.COLUMNS where table_schema = 'CURATED' and table_name = 'DIM_INCIDENTS' and comment is not null  group by table_name, table_schema"});  
         var rsSelectQuery = stmtColumnList.execute();
         rsSelectQuery.next()         
         var targetColumnList  = rsSelectQuery.getColumnValue(1);
         var insertColumnList  = rsSelectQuery.getColumnValue(2);         
         var updateColumnList  = rsSelectQuery.getColumnValue(3);
         var sourceColumnList  = rsSelectQuery.getColumnValue(4);
         
         var sqlCmd;
        
         var loadCmd = "merge into curated.dim_incidents old using (select distinct "+sourceColumnList+",common.resolve_unknown_dims(site.site_key) as site_fkey from "+SOURCE_TABLE_NAME_WITH_SCHEMA+" inc left join curated.dim_sites site on (inc.site_id = site.site_id_formula or inc.site_reference = site.site_reference_formula) WHERE inc.incident_category ilike '%not producing%' ) new on old.incident_id = new.record_id when matched then update set "+updateColumnList+",old.site_fkey = new.site_fkey,old.PROCESS_EXEC_ID = ?, UPDATED_TS = SYSDATE() when not matched then insert("+targetColumnList+",SITE_FKEY,PROCESS_EXEC_ID,CREATED_TS,UPDATED_TS) values("+insertColumnList+",new.site_fkey,?,SYSDATE(),SYSDATE())",
         
         sqlCmd = {sqlText: loadCmd, binds:[PROCESS_RUN_ID, PROCESS_RUN_ID]};
         var stmt = snowflake.createStatement(sqlCmd);
         var rs = stmt.execute();
         rs.next();      
         rowInserted= rs.getColumnValue(1);
         rowUpdated= rs.getColumnValue(2);
     }       
     finally{
        snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
     }

     return JSON.stringify({"Inserted":rowInserted,"Updated":rowUpdated});                      
$$;
