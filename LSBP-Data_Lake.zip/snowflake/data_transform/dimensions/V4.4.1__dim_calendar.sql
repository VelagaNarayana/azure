use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace table curated.dim_calendar_date
(
    date_key BIGINT,
    epoch_date	BIGINT,
    DATE	DATE NULL,
    YEAR	SMALLINT,
    QUARTER	SMALLINT,
    MONTH	SMALLINT,
    DAY	SMALLINT,
    DAY_NAME	VARCHAR(30),
    DAY_OF_WEEK	SMALLINT,
    DAY_OF_YEAR	SMALLINT,
    WEEK_OF_YEAR	SMALLINT,
    WEEK_OF_YEAR_ISO	SMALLINT,
    MONTH_NAME	VARCHAR(30),
    MONTH_START	DATE,
    MONTH_END	DATE,
    YEAR_START	DATE,
    YEAR_END	DATE,
    UPDATED_TS	datetime,
    CONSTRAINT pk_dimcaldate_date  PRIMARY KEY (date_key)
);

create or replace table curated.dim_calendar_time
(
    TIME_KEY SMALLINT,
    TIME TIME NULL,
    HOUR SMALLINT,
    MINUTE SMALLINT,
    SECOND SMALLINT,
    SECONDS_OF_DAY SMALLINT,
    MINUTES_OF_DAY SMALLINT,
    UPDATED_TS	datetime,
    CONSTRAINT pk_dimcaltime_time PRIMARY KEY (time_key)
);

create or replace procedure CURATED.GENERATE_DATE_CALENDAR(START_DATE VARCHAR, END_DATE VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller 
AS
 $$
    snowflake.execute( {sqlText: "set num_days = (select '"+END_DATE+"'::date - '"+START_DATE+"'::date + 1);"} ); 
    var stmt = snowflake.createStatement({
               sqlText: "insert overwrite into curated.dim_calendar_date with calendar as ( select '"+START_DATE+"'::date + num as date from( SELECT (ROW_NUMBER() OVER (ORDER BY 1) - 1) as num FROM TABLE(generator(rowcount=>$num_days))) where date<='"+END_DATE+"'::date) select DATE_PART('EPOCH_SECOND', date) as date_key, DATE_PART('EPOCH_SECOND', date) as epoch_date, date,     YEAR(date) as year, QUARTER(date) as quarter, MONTH(date) as month, DAY(date)	as day, decode(DAYNAME(date), 'Mon','Monday', 'Tue','Tuesday', 'Wed','Wednesday','Thu','Thursday','Fri','Friday','Sat','Saturday','Sun','Sunday') as DAY_NAME, DAYOFWEEK(date) as DAY_OF_WEEK, DAYOFYEAR(date) as DAY_OF_YEAR, WEEKOFYEAR(date) as WEEK_OF_YEAR	, WEEKISO(date)  as WEEK_OF_YEAR_ISO,	     TO_CHAR(date,'MMMM') as MONTH_NAME, date_trunc('month', date) as MONTH_START, dateadd('day', -1,dateadd('month', 1,date_trunc('month', date))) as MONTH_END	, date_trunc('year', date) as YEAR_START,dateadd('day', -1, dateadd('year', 1,date_trunc('year', date))) as YEAR_END, sysdate() as UPDATED_TS from calendar union select -1 as date_key, -1 as epoch_date,NULL as date,-1 as year,-1 as quarter,-1 as month,-1	as day,'Missing / Unknown' as DAY_NAME, -1 as DAY_OF_WEEK,-1 as DAY_OF_YEAR,-1 as WEEK_OF_YEAR,-1  as WEEK_OF_YEAR_ISO,'Missing / Unknown' as MONTH_NAME, NULL as MONTH_START,NULL as MONTH_END,NULL as YEAR_START,NULL as YEAR_END,sysdate() as UPDATED_TS"
           });  
    var rs = stmt.execute();
    rs.next();
    var count = {"Inserted":rs.getColumnValue(1)};
    return JSON.stringify({ "Dates" : count});
 $$
 ;

create or REPLACE  procedure CURATED.GENERATE_TIME_CALENDAR(TIME_INTERVAL_IN_SECS FLOAT)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller 
AS
 $$
 sql_command="insert overwrite into curated.dim_calendar_time with calendar as (select * from(SELECT (ROW_NUMBER() OVER (ORDER BY 1) - 1)*"+TIME_INTERVAL_IN_SECS+" as timepart FROM TABLE(generator(rowcount=>(24*60*60)))) where timepart<(24*60*60)) select timepart as time_key, timeadd(second,timepart,'00:00:00'::time) as time, hour(timeadd(second,timepart,'00:00:00'::time)) as hour,minute(timeadd(second,timepart,'00:00:00'::time)) as minute,second(timeadd(second,timepart,'00:00:00'::time)) as second,timepart as seconds_of_day, (timepart/60)::INTEGER as minutes_of_day,sysdate() as UPDATED_TS from calendar union select -1 as time_key, NULL as time,-1 as hour,-1 as minute,-1 as second,-1 as seconds_of_day,-1 as minutes_of_day,sysdate() as UPDATED_TS";

 var stmt=snowflake.createStatement({sqlText:sql_command})
 var rs=stmt.execute();
 rs.next();
 var count = {"Inserted":rs.getColumnValue(1)};
 return JSON.stringify({ "Time" : count});
 $$
;

BEGIN WORK;
    CALL CURATED.GENERATE_DATE_CALENDAR('2010-01-01', '2030-12-31') ;
    call CURATED.GENERATE_TIME_CALENDAR(1*60::FLOAT);
COMMIT WORK;