use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

CREATE OR REPLACE PROCEDURE "RAW"."PROC_LOAD_DEVICE_AVAILABILITY"(SOURCE_TABLE_NAME_WITH_SCHEMA VARCHAR,DELETED_TABLE_WITH_SCHEMA VARCHAR,TYPE_OF_AVAILABILTY VARCHAR,PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller
AS
$$
snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','factDeviceAvailabilityCalculation'))"});
snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );

var tempAvailabilityMeasurements = "COMMON.\"TEMP_AVAIL_MSR_"+PROCESS_RUN_ID+"\"";
var tempIncidentAffectedTableName = "COMMON.\"TEMP_INC_AFFECTED_"+PROCESS_RUN_ID+"\"";
var tempIncidentHealthyTableName = "COMMON.\"TEMP_INC_HEALTHY_"+PROCESS_RUN_ID+"\"";
var rowsDeleted = 0, rowsInserted=0;

var tempTableSql = "create or replace temporary table "+tempAvailabilityMeasurements+" as with devices as(select distinct site_fkey as site_key,device_id, device_key, device_apcode,device_name,sys_connect_by_path(device_key,'->') as path, level, capacity from curated.dim_devices start with device_id in (select device_id from curated.dim_devices where device_apcode = 'Site' )connect by parent = prior device_id),measurements as (select  d.site_key as site_key, d.device_key, d.device_apcode, d.device_name, d.device_id, d.capacity,path,level, m.measurement_key, m.measurement_id, m.measurement_name, m.measurement_apcode from devices d join curated.dim_measurements m  on m.measurement_type in ('Current', 'Power') and m.calculation_period_name='15m' and m.measurement_apcode in ('StringCurrent','ArrayOutputPower') and m.device_fkey = d.device_key) select * from( select i1.path as parent_path,i2.path as child_path,i1.level as parent_level,i2.level as child_level,i1.site_key as site_key, i1.device_key, i1.device_apcode, i1.device_name, i1.device_id, i1.capacity, i2.measurement_key, i2.measurement_id, i2.measurement_name, i2.measurement_apcode, min(i2.level) over(partition by i1.device_key) as min_level from devices i1 join measurements i2  on i1.site_key = i2.site_key and ((i1.device_key=i2.device_key) or (startswith(i2.path,i1.path) and i2.measurement_key is not null))  ) x where child_level=min_level"

snowflake.execute( {sqlText: tempTableSql}); 

tempTableSql = " create or replace temporary table "+tempIncidentAffectedTableName+" as  select incident_key, timestamp_15_min, local_date, local_time,utc_timestamp_15_min,utc_date, utc_time, local_date_key, local_time_key, site_key, device_key, device_id,device_name,device_capacity,device_apcode, partial_outage, listagg(measurement_key,',') as measurement_key, listagg(measurement_name,',') as measurement_name,sum(msr_value) as current_power_value,sum(normalized_msr_value) as normalized_current_power_value from (SELECT dim_incidents.incident_key, timestamp.fifteen_min_timestamp AS timestamp_15_min, timestamp.date AS local_date, timestamp.time AS local_time, common.Convert_to_local_tz(timestamp.date,timestamp.time,incidents.derived_timezone,'UTC') AS utc_timestamp_15_min, Date(utc_timestamp_15_min) AS utc_date, Try_to_time(utc_timestamp_15_min::varchar,'YYYY-MM-DD HH24:MI:SS.FF') AS utc_time, timestamp.date_key AS local_date_key, timestamp.time_key AS local_time_key, common.Resolve_unknown_dims(incidents.site_key) AS site_key, common.Resolve_unknown_dims(device.device_key) AS device_key, incidents.device_id, device.device_name, device.capacity AS device_capacity, device.device_apcode AS device_apcode, msr.measurement_key  AS measurement_key, msr.measurement_name AS measurement_name, incidents.exclusion_period_start, incidents.exclusion_period_end, fact.measurement_value_numeric as msr_value, msr_value/device_capacity as normalized_msr_value, incidents.type_of_outage != 'Complete Downtime' AS partial_outage FROM ( SELECT record_id AS incident_id, inc.site_id,inc.site_key,inc.derived_timezone,inc.site_reference, inc.incident_start, inc.incident_end, inc.type_of_outage, slice.value AS device_id, flag_as_exclusion, exclusion_period_start, exclusion_period_end, incident_timestamp_start, incident_timestamp_end FROM "+SOURCE_TABLE_NAME_WITH_SCHEMA+" inc, Table(Split_to_table(Trim(combined_device_id), ';')) slice WHERE  incident_category ilike '%not producing%' AND process_incident = true AND inc.type_of_availability = lower('"+TYPE_OF_AVAILABILTY+"') AND length(slice.value) != 0 ) incidents JOIN ( SELECT date_key, time_key, date, time, timestamp_from_parts(date,time) AS fifteen_min_timestamp FROM curated.dim_calendar_date date CROSS JOIN curated.dim_calendar_time time WHERE minute%15 = 0 ) timestamp ON timestamp.fifteen_min_timestamp BETWEEN incidents.incident_timestamp_start AND incidents.incident_timestamp_end INNER JOIN curated.dim_incidents dim_incidents ON incidents.incident_id = dim_incidents.incident_id LEFT JOIN curated.dim_devices device ON incidents.device_id = device.device_id LEFT JOIN "+tempAvailabilityMeasurements+" msr on device.device_key = msr.device_key LEFT JOIN raw.fact_site_measurements fact  ON ( msr.measurement_key = fact.measurement_key) AND to_date(timestamp.fifteen_min_timestamp) = fact.local_date AND to_time(timestamp.fifteen_min_timestamp) = fact.local_time  and  incidents.type_of_outage != 'Complete Downtime' ) x group by incident_key, timestamp_15_min, local_date, local_time,utc_timestamp_15_min,utc_date, utc_time, local_date_key, local_time_key, site_key, device_key, device_id,device_name,device_capacity,device_apcode, partial_outage ";

snowflake.execute( {sqlText: tempTableSql});

tempTableSql = "create or replace temporary table "+tempIncidentHealthyTableName+" as  with incident_devices AS ( SELECT DISTINCT incident_key, site_key, device_key, device_id, device_apcode, timestamp_15_min FROM "+tempIncidentAffectedTableName+" WHERE site_key>0 AND device_key>0 AND partial_outage ),  incidents_meta AS ( SELECT inc.*, sim_devices.device_apcode AS similar_device_apcode, inc2.device_id IS null AS similar_device_healthy, inc2.incident_key AS other_incident_key, sim_devices.device_key AS similar_device_key, sim_devices.device_id AS similar_device_id, sim_devices.device_name AS similar_device_name, sim_devices.capacity AS similar_device_capacity, sim_devices.measurement_key AS similar_measurement_key, sim_devices.measurement_id AS similar_measurement_id, sim_devices.measurement_apcode AS similar_measurement_apcode, sim_devices.measurement_name AS similar_measurement_name FROM incident_devices inc LEFT JOIN "+tempAvailabilityMeasurements+" sim_devices ON inc.device_apcode=sim_devices.device_apcode AND inc.site_key=sim_devices.site_key AND inc.device_id!=sim_devices.device_id LEFT JOIN incident_devices inc2 ON inc.timestamp_15_min=inc2.timestamp_15_min AND inc.incident_key!=inc2.incident_key AND inc.site_key=inc2.site_key AND inc.device_id!=inc2.device_id AND inc2.device_id = sim_devices.device_id ) SELECT meta.*, msr.measurement_value_numeric AS similar_current_power_value, similar_current_power_value/similar_device_capacity AS similar_normalized_current_power_value, (msr.measurement_key is not null) as measurement_exists  FROM incidents_meta meta LEFT JOIN raw.fact_site_measurements msr ON ( meta.similar_measurement_key = msr.measurement_key) AND To_date(timestamp_15_min) = local_date AND To_time(timestamp_15_min) = local_time "

snowflake.execute( {sqlText: tempTableSql});

tempTableSql = " insert into "+DELETED_TABLE_WITH_SCHEMA+" (site_key,local_date,local_time,local_timestamp_15_min,type_of_availability)  select distinct fact.site_key,fact.local_date,fact.local_time,fact.local_timestamp_15_min,fact.type_of_availability from curated.fact_device_availability fact inner join ( select avail.*,dim.incident_key from "+SOURCE_TABLE_NAME_WITH_SCHEMA+" avail inner join curated.dim_incidents dim on avail.record_id = dim.incident_id ) base where fact.incident_key = base.incident_key and fact.local_timestamp_15_min not between base.incident_timestamp_start and base.incident_timestamp_end order by local_timestamp_15_min ";
snowflake.execute( {sqlText: tempTableSql});

snowflake.execute( {sqlText: "BEGIN WORK;"} );

try{

var deleteStmt = snowflake.createStatement({
	sqlText: "DELETE FROM CURATED.FACT_DEVICE_AVAILABILITY irr_incident USING  (SELECT distinct dim.incident_key,? as type_of_availability from "+SOURCE_TABLE_NAME_WITH_SCHEMA+" incident inner join curated.dim_incidents dim ON incident.record_id = dim.incident_id) other_incident WHERE irr_incident.incident_key = other_incident.incident_key and irr_incident.type_of_availability = other_incident.type_of_availability ",
    binds:[TYPE_OF_AVAILABILTY]});
var deleteRs = deleteStmt.execute();
deleteRs.next();
rowsDeleted = deleteRs.getColumnValue(1);

var insertStmt = snowflake.createStatement({
	sqlText: " INSERT INTO curated.fact_device_availability ( incident_key, local_timestamp_15_min, local_date, local_time, local_date_key, local_time_key, site_key, device_key, measurement_key, partial_outage, current_power_value, normalized_current_power_value, healthy_devices_count, healthy_value, avg_healthy_normalized_value, loss_ratio, device_capacity, lost_capacity, available_capacity, final_available_capacity, type_of_availability, healthy_device_names, healthy_device_ids, total_unhealthy_devices, unhealthy_device_names, unhealthy_device_ids, original_device_id, utc_date, utc_time, utc_date_key, utc_time_key, process_exec_id, created_ts ) with avg_healthy_devices AS ( SELECT  incident_key, site_key, device_key, device_id, device_apcode, timestamp_15_min, count(*) AS total_healthy_devices, sum(similar_current_power_value)   AS total_healthy_value, avg(similar_normalized_current_power_value) AS avg_healthy_normalized_value, listagg(similar_device_name,',')   AS healthy_device_names, arrayagg(similar_device_id) AS healthy_device_ids  FROM "+tempIncidentHealthyTableName+"  WHERE  similar_device_healthy AND site_key>0  AND   device_key>0  GROUP BY 1, 2, 3, 4, 5, 6 ) , other_unhealthy_devices AS ( SELECT  incident_key, site_key, device_key, device_id, device_apcode, timestamp_15_min, count(*) AS total_unhealthy_devices, listagg(similar_device_name,',') AS unhealthy_device_names, arrayagg(similar_device_id) AS unhealthy_device_ids FROM   "+tempIncidentHealthyTableName+"  WHERE  NOT similar_device_healthy  AND site_key>0  AND device_key>0  GROUP BY 1, 2, 3, 4, 5, 6 ) SELECT i.incident_key, i.timestamp_15_min AS local_timestamp_15_min,  i.local_date,  i.local_time,  i.local_date_key,  i.local_time_key,  i.site_key,  i.device_key,  i.measurement_key,  i.partial_outage, i.current_power_value,  i.normalized_current_power_value,  h.total_healthy_devices,  h.total_healthy_value, h.avg_healthy_normalized_value,  1-Div0(i.normalized_current_power_value,h.avg_healthy_normalized_value) AS loss_ratio,  i.device_capacity,  CASE WHEN partial_outage THEN loss_ratio*device_capacity ELSE device_capacity END AS lost_capacity, device_capacity - lost_capacity AS available_capacity, CASE WHEN available_capacity > device_capacity THEN device_capacity WHEN available_capacity < 0 THEN 0 ELSE available_capacity END AS final_available_capacity, ? AS type_of_availability,  h.healthy_device_names,  h.healthy_device_ids, uh.total_unhealthy_devices, uh.unhealthy_device_names,  uh.unhealthy_device_ids, i.device_id,  i.utc_date,  i.utc_time, utc_dt.date_key AS utc_date_key, utc_tm.time_key AS utc_time_key, ?  AS process_exec_id, Sysdate() AS created_ts  FROM avg_healthy_devices h  LEFT JOIN other_unhealthy_devices uh ON  h.incident_key=uh.incident_key  AND h.device_key=uh.device_key  AND h.timestamp_15_min=uh.timestamp_15_min  RIGHT JOIN "+tempIncidentAffectedTableName+" i ON  h.incident_key=i.incident_key  AND h.device_key=i.device_key  AND h.timestamp_15_min=i.timestamp_15_min  LEFT JOIN curated.dim_calendar_date utc_dt  ON  i.utc_date = utc_dt.date LEFT JOIN curated.dim_calendar_time utc_tm  ON  i.utc_time = utc_tm.time ",
    binds:[TYPE_OF_AVAILABILTY,PROCESS_RUN_ID]});
var insertRs = insertStmt.execute();
insertRs.next();
rowsInserted = insertRs.getColumnValue(1);
    
snowflake.execute( {sqlText: "COMMIT WORK;"} );
  
}
catch(err){
	snowflake.execute( {sqlText: "ROLLBACK WORK;"} );
	rowsInserted=rowsDeleted=-1;
	throw err;
}
finally{
	snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
}
return JSON.stringify({"Rows inserted":rowsInserted,"Rows deleted":rowsDeleted});
$$;

