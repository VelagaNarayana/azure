use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace TABLE CURATED.IRRADIANCE_CLEANSED_INTERPOLATED (
    SITE_KEY NUMBER(38,0) NOT NULL,
    DEVICE_KEY NUMBER(38,0) NOT NULL,
    MEASUREMENT_KEY NUMBER(38,0) NOT NULL,
    DATE_KEY NUMBER(38,0) NOT NULL,
    TIME_15MIN_KEY NUMBER(38,0) NOT NULL,
    LOCAL_DATE_KEY NUMBER (38,0) NOT NULL,
    LOCAL_TIME_15MIN_KEY NUMBER (38,0) NOT NULL,
    SITE_ID VARCHAR(255) NOT NULL,
    DEVICE_ID VARCHAR(255) NOT NULL,
    MEASUREMENT_ID VARCHAR(255) NOT NULL,
    DATE DATE,
    TIME_15MIN TIME(9),
    LOCAL_DATE DATE,
    LOCAL_TIME_15MIN TIME(9),
    IRRADIANCE_RAW_VALUE FLOAT,
    TRACKER_POSITION_ANGLE FLOAT,
    TRACKER_TARGET_ROLL FLOAT,
    CL_STEP_1_MIN_THRESHOLD_VALUE_APPLIED FLOAT,
    CL_STEP_2_MAX_THRESHOLD_VALUE_APPLIED FLOAT,
    CL_STEP_3_AVGED_IRRADIANCE_VALUE FLOAT,
    CL_STEP_3_ORIGINAL_VALUES_LIST VARCHAR(16777216),
    CL_STEP_3_ORIGINAL_TS_LIST VARCHAR(16777216),
    CL_STEP_4_MISSING_TS_ADDED BOOLEAN,
    CL_STEP_5_SUNRISE_BUFFER_APPLIED VARCHAR(255),
    CL_STEP_5_SUNSET_BUFFER_APPLIED VARCHAR(255),
    CL_STEP_5_IRRADIANCE_VALUE FLOAT,
    CL_STEP_6_EQ_CONSEC_THRESHOLD_APPLIED NUMBER(38,0),
    CL_STEP_6_IRRADIANCE_VALUE FLOAT,
    CL_STEP_7_TRACKER_ANGLE_DEVIATION_APPLED FLOAT,
    CL_STEP_7_TRACKER_DEVIATION FLOAT,
    CL_STEP_7_IRRADIANCE_VALUE FLOAT,
    IS_DAY_RECORD BOOLEAN,
    IRRADIANCE_CLEANSED_VALUE FLOAT,
    IS_REJECTED_RECORD BOOLEAN,
    REJECT_REASON VARCHAR(255),
    IS_GAP BOOLEAN,
    INT_STEP_1_GAPS_THRESHOLD_APPLIED NUMBER(38,0),
    INT_STEP_2_IS_BOUNDARY_GAP BOOLEAN,
    IS_INTERPOLATED BOOLEAN,
    GAP_LENGTH INTEGER,
    GAP_POSITION INTEGER,  
    GAP_START FLOAT,
    GAP_END FLOAT, 
    IRRADIANCE_INTERPOLATED_VALUE FLOAT,
    IRRADIANCE_FINAL_VALUE FLOAT,
    PROCESS_EXEC_ID VARCHAR(255),
    UPDATED_TS TIMESTAMP_NTZ(9)
)DATA_RETENTION_TIME_IN_DAYS = 31 
CLUSTER BY (DATE) 
COMMENT = "Cleansed and Interpolated irradiance data";


create or replace TABLE CURATED.IRRADIANCE_BACKFILLED cluster by (DATE)(
    SITE_KEY NUMBER(38,0),
    DATE_KEY NUMBER(38,0) NOT NULL,
    TIME_15MIN_KEY NUMBER(38,0) NOT NULL,
    LOCAL_DATE_KEY NUMBER(38,0) NOT NULL,
    LOCAL_TIME_15MIN_KEY NUMBER(38,0) NOT NULL,
    SITE_ID VARCHAR(500),
    DATE DATE,
    TIME_15MIN TIME(9),
    LOCAL_DATE DATE,
    LOCAL_TIME_15MIN TIME(9),
    IRRADIANCE_AVERAGED_VALUE FLOAT,
    IRRADIANCE_SATELLITE_VALUE FLOAT,
    IRRADIANCE_VALUE FLOAT,
    RECORD_QUALITY VARCHAR(30),
    DEVICE_GROUP BOOLEAN,
    PROCESS_EXEC_ID VARCHAR(255),
    UPDATED_TS TIMESTAMP_NTZ(9),
    DEVICE_GROUP_DETAILS VARCHAR(1000)
)DATA_RETENTION_TIME_IN_DAYS = 31 
CLUSTER BY (DATE) 
COMMENT = "Backfilled data";


CREATE OR REPLACE PROCEDURE "CURATED"."PROC_LOAD_CLEANSED_DATA"(SOURCE_TABLE_SCHEMA VARCHAR,SOURCE_TABLE_NAME VARCHAR,TARGET_TABLE_SCHEMA VARCHAR, TARGET_TABLE_NAME VARCHAR, KEY_COLS VARCHAR, PROCESS_RUN_ID VARCHAR,PROCESS_NAME VARCHAR)
RETURNS STRING
LANGUAGE JAVASCRIPT
STRICT
EXECUTE AS CALLER
AS
$$
    snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','fact2curated'))"});
    snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );
    
    var transientTable = ""+SOURCE_TABLE_SCHEMA+".\""+SOURCE_TABLE_NAME+"\"";
    var targetTable = ""+TARGET_TABLE_SCHEMA+".\""+TARGET_TABLE_NAME+"\"";
    var rowsDeleted=0, rowsInserted=0;
    
    var stmt = snowflake.createStatement({
       sqlText: "select listagg(concat(coalesce(comment,column_name),' as ',column_name),',') WITHIN GROUP ( order by ordinal_position )  from information_schema.columns  where table_schema='"+TARGET_TABLE_SCHEMA+"' and table_name='"+TARGET_TABLE_NAME+"'" 
    });  
    var rs = stmt.execute();
    rs.next();
    var cols = rs.getColumnValue(1);
    
    var delCondition="";
    var keyCols = KEY_COLS.split(",");
    for(const keyCol in keyCols){
        delCondition+="main."+keyCols[keyCol]+" = temp."+keyCols[keyCol];
        if(keyCol != keyCols.length - 1){
            delCondition+=" and ";
        }
    }    

 

    snowflake.execute( {sqlText: "BEGIN WORK;"} );
    try { 
        stmt = snowflake.createStatement({
            sqlText: "DELETE FROM "+targetTable+" main USING ( SELECT DISTINCT "+KEY_COLS+" FROM "+transientTable+" ) AS temp WHERE "+delCondition
        });  

 

        rs = stmt.execute();
        rs.next()                
        var rowsDeleted = rs.getColumnValue(1);  

 

        stmt = snowflake.createStatement({
            sqlText: "insert into "+targetTable+" select "+cols+" from "+transientTable
        });  

 

        rs = stmt.execute();
        rs.next()                
        var rowsInserted = rs.getColumnValue(1);
        
        snowflake.execute( {sqlText: "COMMIT WORK"} );
     } catch(err){
        snowflake.execute( {sqlText: "ROLLBACK WORK;"} );
        rowsInserted=rowsDeleted=-1;
        throw err;
    }
    finally{
        snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
    }
    return JSON.stringify({"Rows deleted":rowsDeleted,"Rows inserted":rowsInserted});
 $$       

