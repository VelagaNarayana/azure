use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

CREATE OR REPLACE TABLE  CONTROL.CURATED_PROCESS_EXECUTION_LOG
(
    DATE	DATE NOT NULL,
    SITE_KEY INTEGER NOT NULL,
    DEVICE_KEY	INTEGER,
    SOURCE_ROW_COUNT INTEGER,
    DESTINATION_ROW_COUNT INTEGER,
    SOURCE_MEASUREMENT_COUNT INTEGER,
    DESTINATION_MEASUREMENT_COUNT INTEGER,
    PROCESS_NAME VARCHAR(100),
    PROCESS_EXEC_ID	VARCHAR(255),
    CREATED_TS	TIMESTAMP DEFAULT sysdate()
)DATA_RETENTION_TIME_IN_DAYS = 31 
CLUSTER BY (DATE) 
COMMENT = "Process execution details" ;

CREATE OR REPLACE PROCEDURE "CURATED"."PROC_GENERATE_PROCESS_EXECUTION_LOG"(SOURCE_LOG_TABLE_SCHEMA VARCHAR,SOURCE_LOG_TABLE_NAME VARCHAR, DESTINATION_TEMP_TABLE_SCHEMA VARCHAR,DESTINATION_TEMP_TABLE_NAME VARCHAR, KEY_COLS VARCHAR, PROCESS_RUN_ID VARCHAR,PROCESS_NAME VARCHAR)
RETURNS STRING
LANGUAGE JAVASCRIPT
STRICT
EXECUTE AS CALLER
AS
$$
	snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','fact2curated'))"});
	snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );
try{
	var mainTableName = ""+DESTINATION_TEMP_TABLE_SCHEMA+".\""+DESTINATION_TEMP_TABLE_NAME+"\"";
  	var logTableName = ""+SOURCE_LOG_TABLE_SCHEMA+".\""+SOURCE_LOG_TABLE_NAME+"\"";

    var rowsInserted=0;

    var joinCondition="";
    var keyCols = KEY_COLS.split(",");
    for(const keyCol in keyCols){
        joinCondition+="final_log_temp."+keyCols[keyCol]+" = final_temp."+keyCols[keyCol];
        if(keyCol != keyCols.length - 1){
             joinCondition+=" AND ";
        }
     }

    var selectColumns="";
    for(const keyCol in keyCols){
        selectColumns+="final_log_temp."+keyCols[keyCol];
        if(keyCol != keyCols.length - 1){
             selectColumns+=", ";
        }
     }

    var checkMeasurementKeyStmt = snowflake.createStatement({
		sqlText: "SELECT COUNT (*) FROM information_schema.columns WHERE table_schema='"+DESTINATION_TEMP_TABLE_SCHEMA+"' AND TABLE_NAME='"+DESTINATION_TEMP_TABLE_NAME+"'  AND COLUMN_NAME='MEASUREMENT_KEY'"
	});  
                
    var checkMeasurementKeyStmtRs = checkMeasurementKeyStmt.execute();
    checkMeasurementKeyStmtRs.next()                
    var recordCount = checkMeasurementKeyStmtRs.getColumnValue(1);    
    
    
    var measurementKeyCountColumn;
    
    if(recordCount > 0){
    measurementKeyCountColumn = "COUNT(DISTINCT MEASUREMENT_KEY) ";
    }else{
    measurementKeyCountColumn = "NULL ";        
    };

    var insertStmt = snowflake.createStatement({
		sqlText: "INSERT INTO CONTROL.CURATED_PROCESS_EXECUTION_LOG("+KEY_COLS+",source_row_count,destination_row_count,source_measurement_count,destination_measurement_count,process_name,process_exec_id,created_ts) SELECT "+selectColumns+", final_log_temp.source_row_count, COALESCE(final_temp.destination_row_count,0) as destination_row_count, final_log_temp.source_measurement_count, final_temp.destination_measurement_count,final_log_temp.process_name, final_log_temp.process_exec_id, final_log_temp.created_ts  FROM "+logTableName+" final_log_temp LEFT JOIN (SELECT "+KEY_COLS+", COUNT(*) AS destination_row_count, "+measurementKeyCountColumn+" AS destination_measurement_count FROM "+mainTableName+" GROUP BY "+KEY_COLS+") final_temp ON "+joinCondition 
	});  
                
    var insertStmtRs = insertStmt.execute();
    insertStmtRs.next()                
    var insertRecordCounts = insertStmtRs.getColumnValue(1);    

}
finally{
	snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
}
    return JSON.stringify({"Rows inserted":insertRecordCounts});

$$;

