use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';


CREATE OR REPLACE PROCEDURE "RAW"."PROC_LOAD_SITE_AVAILABILITY"(SOURCE_TABLE_FILTER VARCHAR,DELETED_TABLE_WITH_SCHEMA VARCHAR,PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller
AS
$$
snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','factSiteAvailabilityCalculation'))"});
snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );

var tempSiteAvailabilityCalculations = "COMMON.\"TEMP_SITE_AVAIL_CAL_"+PROCESS_RUN_ID+"\"";
var tempSiteAvailCalWithBackfill = "COMMON.\"TEMP_SITE_AVAIL_BACKFILL_"+PROCESS_RUN_ID+"\"";
var tempSiteAvailMissingTimestamp = "COMMON.\"TEMP_SITE_AVAIL_TIMSTAMPS_"+PROCESS_RUN_ID+"\"";
var rowsUpdated=rowsInserted=missingTimestamps=0 ;

var tempTableSql = " create or replace temporary table "+tempSiteAvailabilityCalculations+" as with device_levels as  ( select distinct site_fkey as site_key,device_key, device_apcode,device_name,sys_connect_by_path(device_key,'->') as path, level from curated.dim_devices start with device_id in (select device_id from curated.dim_devices where device_apcode like 'Site%' ) connect by parent = prior device_id  ),  site_incidents as ( select * from (select avail.site_key,timestamp_from_parts(local_date, local_time) as timestamp_15_min,local_date,local_time,local_date_key,local_time_key,utc_date,utc_time, utc_date_key,utc_time_key,lower(replace(type_of_availability,' ','_')) as type_of_availability,path, partial_outage, row_number() over(partition by avail.site_key,local_date,local_time,avail.device_key,type_of_availability order by partial_outage) as rank,level as device_level,lost_capacity,final_available_capacity, device_capacity from device_levels dev  join ( select * from curated.fact_device_availability  where "+SOURCE_TABLE_FILTER+" UNION select fact.* from curated.fact_device_availability fact inner join "+DELETED_TABLE_WITH_SCHEMA+" deleted_tm on fact.site_key = deleted_tm.site_key and fact.type_of_availability = deleted_tm.type_of_availability and fact.local_timestamp_15_min = deleted_tm.local_timestamp_15_min  )  avail on dev.site_key=avail.site_key and avail.device_key = dev.device_key ) tmp where rank=1),filtered_site_incidents as( select si1.* from site_incidents si1 join site_incidents si2 on si1.site_key=si2.site_key and si1.timestamp_15_min=si2.timestamp_15_min and si1.type_of_availability=si2.type_of_availability and si1.device_level > si2.device_level and contains(si1.path,si2.path)) select  p.site_key, p.local_date, p.local_time, p.local_date_key, p.local_time_key, p.utc_date, p.utc_time, p.utc_date_key, p.utc_time_key, scap.capacity as total_site_capacity, round(TOTAL_SITE_CAPACITY - iff(lost1=-1,NULL,coalesce(lost1,0)),10) as TOTAL_AVAILABLE_CAPACITY_INCIDENT, round(TOTAL_SITE_CAPACITY - iff(lost2=-1,NULL,coalesce(lost2,0)),10) as TOTAL_AVAILABLE_CAPACITY_WITH_EXCLUSIONS,round(TOTAL_SITE_CAPACITY - iff(lost3=-1,NULL,coalesce(lost3,0)),10) as TOTAL_AVAILABLE_CAPACITY_WITH_APPROVED_EXCLUSIONS,round(TOTAL_SITE_CAPACITY - iff(lost4=-1,NULL,coalesce(lost4,0)),10) as TOTAL_AVAILABLE_CAPACITY_WITH_TEST_KPI from ( select si.site_key,local_date,local_time,local_date_key,local_time_key,utc_date,utc_time,utc_date_key,utc_time_key,si.type_of_availability,coalesce(sum(device_capacity - final_available_capacity),-1) as lost_capacity from (select * from site_incidents except select * from filtered_site_incidents) si group by 1,2,3,4,5,6,7,8,9,10) pivot(avg(lost_capacity) for type_of_availability in ('all_incidents','all_exclusions','all_approved_exclusions','test_kpi')) as p (site_key,local_date,local_time,local_date_key,local_time_key,utc_date,utc_time,utc_date_key,utc_time_key,lost1,lost2,lost3,lost4) join curated.dim_devices scap on scap.device_apcode='Site' and scap.site_fkey=p.site_key ";

snowflake.execute( {sqlText: tempTableSql});

var tempTableSql = "create or replace temporary table "+tempSiteAvailCalWithBackfill+" as with backfilled as ( select backfill.site_key,local_date,local_time_15min,Timestamp_from_parts(local_date,local_time_15min) as local_15min_timestamp,irradiance_value as backfilled_irradiance_value, parameter_value as irradiance_threshold_value, backfilled_irradiance_value >= irradiance_threshold_value as over_irradiance_threshold_flag from  (select distinct site_key,parameter_date,parameter_value from table(CONTROL.FN_SITE_ACTIVE_CONFIG((select min(local_date) from "+tempSiteAvailabilityCalculations+"),(select max(local_date) from  "+tempSiteAvailabilityCalculations+")))  where parameter_name = 'Irradiance Minimum') config join curated.irradiance_backfilled backfill on config.site_key = backfill.site_key and config.parameter_date = backfill.local_date ) select temp.*,bckfill.irradiance_threshold_value as IRRADIANCE_THRESHOLD, bckfill.over_irradiance_threshold_flag as OVER_IRRADIANCE_THRESHOLD_FLAG from "+tempSiteAvailabilityCalculations+" temp  left join backfilled bckfill on  temp.site_key = bckfill.site_key and  temp.local_date = bckfill.local_date and  temp.local_time = bckfill.local_time_15min ";
snowflake.execute( {sqlText: tempTableSql});


tempTableSql = " create or replace temporary table "+tempSiteAvailMissingTimestamp+" as  with all_day_timestamps as(  select site_dates.*,tm.time as local_time from  ( select distinct site_key,local_date from  "+tempSiteAvailCalWithBackfill+" union select distinct site_key,local_date from  "+DELETED_TABLE_WITH_SCHEMA+" ) site_dates join curated.dim_calendar_time tm on tm.minute%15=0 ), missing_timestamps as  (  select missing_ts.*,deleted_ts.site_key is not null  as update_record_flage from (select * from all_day_timestamps except select distinct site_key,local_date,local_time from "+tempSiteAvailCalWithBackfill+" ) missing_ts left join  (select distinct site_key,local_date,local_time from "+DELETED_TABLE_WITH_SCHEMA+") deleted_ts on missing_ts.site_key = deleted_ts.site_key and missing_ts.local_date = deleted_ts.local_date and missing_ts.local_time = deleted_ts.local_time ), default_capacity_timestamps as ( select mts.*, common.convert_to_local_tz(mts.local_date,mts.local_time,site.derived_timezone,'UTC') as utc_ts_15min, to_date(utc_ts_15min) as utc_date, to_time(utc_ts_15min) as utc_time, dev.capacity as total_site_capacity from missing_timestamps mts join curated.dim_sites site on site.site_key = mts.site_key  join curated.dim_devices dev on dev.device_apcode='Site' and mts.site_key=dev.site_fkey  ), backfilled as ( select backfill.site_key,local_date,local_time_15min,Timestamp_from_parts(local_date,local_time_15min) as local_15min_timestamp,irradiance_value as backfilled_irradiance_value,parameter_value as irradiance_threshold_value, backfilled_irradiance_value >= irradiance_threshold_value as over_irradiance_threshold_flag from  (select distinct site_key,parameter_date,parameter_value from table(CONTROL.FN_SITE_ACTIVE_CONFIG((select min(local_date) from default_capacity_timestamps),(select max(local_date) from default_capacity_timestamps))) where parameter_name = 'Irradiance Minimum') config join curated.irradiance_backfilled backfill on config.site_key = backfill.site_key and config.parameter_date = backfill.local_date ) select defts.site_key, defts.local_date,defts.local_time,locdt.date_key as local_date_key,loctm.time_key as local_time_key,defts.utc_date,defts.utc_time,utcdt.date_key as utc_date_key,utctm.time_key as utc_time_key, defts.total_site_capacity, total_site_capacity as TOTAL_AVAILABLE_CAPACITY_INCIDENT, total_site_capacity as TOTAL_AVAILABLE_CAPACITY_WITH_EXCLUSIONS, total_site_capacity as TOTAL_AVAILABLE_CAPACITY_WITH_APPROVED_EXCLUSIONS, total_site_capacity as TOTAL_AVAILABLE_CAPACITY_WITH_TEST_KPI, bckfill.irradiance_threshold_value as IRRADIANCE_THRESHOLD, bckfill.over_irradiance_threshold_flag as OVER_IRRADIANCE_THRESHOLD_FLAG,defts.update_record_flage from default_capacity_timestamps defts join curated.dim_calendar_date utcdt on defts.utc_date = utcdt.date join curated.dim_calendar_time utctm on defts.utc_time = utctm.time join curated.dim_calendar_date locdt on defts.local_date = locdt.date join curated.dim_calendar_time loctm on defts.local_time = loctm.time left join backfilled bckfill on  defts.site_key = bckfill.site_key and  defts.local_date = bckfill.local_date and  defts.local_time = bckfill.local_time_15min  ";
snowflake.execute( {sqlText: tempTableSql});

snowflake.execute( {sqlText: "BEGIN WORK;"} );

try{
var mergeStmt = snowflake.createStatement({
	sqlText: " merge into curated.fact_site_availability fact using ( select *,true as update_record_flage from "+tempSiteAvailCalWithBackfill+"  union select * from "+tempSiteAvailMissingTimestamp+" where update_record_flage ) new on fact.site_key = new.site_key and fact.local_date = new.local_date and fact.local_time = new.local_time when matched then update set fact.TOTAL_SITE_CAPACITY = new.TOTAL_SITE_CAPACITY,fact.TOTAL_AVAILABLE_CAPACITY_INCIDENT = new.TOTAL_AVAILABLE_CAPACITY_INCIDENT,fact.TOTAL_AVAILABLE_CAPACITY_WITH_EXCLUSIONS = new.TOTAL_AVAILABLE_CAPACITY_WITH_EXCLUSIONS,fact.TOTAL_AVAILABLE_CAPACITY_WITH_APPROVED_EXCLUSIONS = new.TOTAL_AVAILABLE_CAPACITY_WITH_APPROVED_EXCLUSIONS,fact.TOTAL_AVAILABLE_CAPACITY_WITH_TEST_KPI = new.TOTAL_AVAILABLE_CAPACITY_WITH_TEST_KPI,fact.IRRADIANCE_THRESHOLD = new.IRRADIANCE_THRESHOLD,fact.OVER_IRRADIANCE_THRESHOLD_FLAG = COALESCE(new.over_irradiance_threshold_flag, true), fact.PROCESS_EXEC_ID = ?, fact.UPDATED_TS=sysdate() when not matched then insert (SITE_KEY,LOCAL_DATE,LOCAL_TIME,LOCAL_DATE_KEY,LOCAL_TIME_KEY,TOTAL_SITE_CAPACITY,TOTAL_AVAILABLE_CAPACITY_INCIDENT,TOTAL_AVAILABLE_CAPACITY_WITH_EXCLUSIONS,TOTAL_AVAILABLE_CAPACITY_WITH_APPROVED_EXCLUSIONS,TOTAL_AVAILABLE_CAPACITY_WITH_TEST_KPI,IRRADIANCE_THRESHOLD,OVER_IRRADIANCE_THRESHOLD_FLAG,UTC_DATE,UTC_TIME,UTC_DATE_KEY,UTC_TIME_KEY,created_ts,updated_ts,process_exec_id) values (new.SITE_KEY,new.LOCAL_DATE,new.LOCAL_TIME,new.LOCAL_DATE_KEY,new.LOCAL_TIME_KEY,new.TOTAL_SITE_CAPACITY,new.TOTAL_AVAILABLE_CAPACITY_INCIDENT,new.TOTAL_AVAILABLE_CAPACITY_WITH_EXCLUSIONS,new.TOTAL_AVAILABLE_CAPACITY_WITH_APPROVED_EXCLUSIONS,new.TOTAL_AVAILABLE_CAPACITY_WITH_TEST_KPI,new.IRRADIANCE_THRESHOLD,coalesce(new.OVER_IRRADIANCE_THRESHOLD_FLAG,true),new.UTC_DATE,new.UTC_TIME,new.UTC_DATE_KEY,new.UTC_TIME_KEY, sysdate(), sysdate(),?)  ",
    binds:[PROCESS_RUN_ID,PROCESS_RUN_ID]});
var mergeRs = mergeStmt.execute();
mergeRs.next();
rowsInserted = mergeRs.getColumnValue(1);
rowsUpdated = mergeRs.getColumnValue(2);

var insertStmt = snowflake.createStatement({
	sqlText: " insert into curated.fact_site_availability(SITE_KEY,LOCAL_DATE,LOCAL_TIME,LOCAL_DATE_KEY,LOCAL_TIME_KEY,TOTAL_SITE_CAPACITY,TOTAL_AVAILABLE_CAPACITY_INCIDENT,TOTAL_AVAILABLE_CAPACITY_WITH_EXCLUSIONS,TOTAL_AVAILABLE_CAPACITY_WITH_APPROVED_EXCLUSIONS,TOTAL_AVAILABLE_CAPACITY_WITH_TEST_KPI,IRRADIANCE_THRESHOLD,OVER_IRRADIANCE_THRESHOLD_FLAG,UTC_DATE,UTC_TIME,UTC_DATE_KEY,UTC_TIME_KEY,created_ts,updated_ts,process_exec_id) select new.SITE_KEY,new.LOCAL_DATE,new.LOCAL_TIME,new.LOCAL_DATE_KEY,new.LOCAL_TIME_KEY,new.TOTAL_SITE_CAPACITY,new.TOTAL_AVAILABLE_CAPACITY_INCIDENT,new.TOTAL_AVAILABLE_CAPACITY_WITH_EXCLUSIONS,new.TOTAL_AVAILABLE_CAPACITY_WITH_APPROVED_EXCLUSIONS,new.TOTAL_AVAILABLE_CAPACITY_WITH_TEST_KPI,new.IRRADIANCE_THRESHOLD, coalesce(new.OVER_IRRADIANCE_THRESHOLD_FLAG,true), new.UTC_DATE,new.UTC_TIME,new.UTC_DATE_KEY,new.UTC_TIME_KEY, sysdate(), sysdate(),? from "+tempSiteAvailMissingTimestamp+" new left join  curated.fact_site_availability fact on fact.site_key = new.site_key and fact.local_date = new.local_date and fact.local_time = new.local_time where fact.site_key is null and update_record_flage = false ",
    binds:[PROCESS_RUN_ID]});
var insertRs = insertStmt.execute();
insertRs.next();
missingTimestamps = insertRs.getColumnValue(1);

snowflake.execute( {sqlText: "COMMIT WORK;"} );
}
catch(err){
	snowflake.execute( {sqlText: "ROLLBACK WORK;"} );
    var rowsUpdated=rowsInserted=missingTimestamps=-1 ;
    throw err;
}
finally{
	snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
}
return JSON.stringify({"Rows inserted":rowsInserted,"Rows updated":rowsUpdated,"Missing timestamp added":missingTimestamps});
$$;

