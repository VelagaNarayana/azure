use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace table curated.bridge_site_availability_incident
(
SITE_AVAILABILITY_INCIDENT_KEY INT IDENTITY(1,1) NOT NULL,
FACT_SITE_AVAILABILITY_KEY INTEGER,
DIM_INCIDENT_KEY INTEGER,
PROCESS_EXEC_ID VARCHAR(255),
CREATED_TS TIMESTAMP  
)  DATA_RETENTION_TIME_IN_DAYS = 7
comment='Bridge table for fact site availability (all incidents listed)';


CREATE OR REPLACE PROCEDURE "RAW"."PROC_LOAD_BRIDGE_INCIDENT_DEVICE"(SOURCE_TABLE_FILTER VARCHAR,PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller
AS
$$
snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','bridgeIncidents'))"});
snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );

var tempSiteAvailabilityIncidentsBridge = "COMMON.\"TEMP_SITE_AVAIL_BRIDGE_"+PROCESS_RUN_ID+"\"";
var rowsDeleted=rowsInserted=0 ;

var tempTableSql = " create or replace table "+tempSiteAvailabilityIncidentsBridge+" as select distinct site_availability_key, incident_key from (select * from curated.fact_site_availability where "+SOURCE_TABLE_FILTER+") fact_site inner join curated.fact_device_availability fact_device on fact_site.site_key=fact_device.site_key and fact_site.local_date=fact_device.local_date and fact_site.local_time=fact_device.local_time ";
snowflake.execute( {sqlText: tempTableSql});

snowflake.execute( {sqlText: "BEGIN WORK;"} );

try{
var deleteStmt = snowflake.createStatement({
	sqlText: " delete from curated.bridge_site_availability_incident trgt using "+tempSiteAvailabilityIncidentsBridge+" src where trgt.fact_site_availability_key = src.site_availability_key  "
    });
var deleteRs = deleteStmt.execute();
deleteRs.next();
rowsDeleted = deleteRs.getColumnValue(1);

var insertStmt = snowflake.createStatement({
	sqlText: " insert into curated.bridge_site_availability_incident (site_availability_incident_key,fact_site_availability_key,dim_incident_key,process_exec_id,created_ts) select hash(site_availability_key,incident_key), site_availability_key, incident_key, ? as process_exec_id,sysdate() as created_ts from "+tempSiteAvailabilityIncidentsBridge+" ",
    binds:[PROCESS_RUN_ID]
    });
var insertRs = insertStmt.execute();
insertRs.next();
rowsInserted = insertRs.getColumnValue(1);

snowflake.execute( {sqlText: "COMMIT WORK;"} );

}
catch(err){
	snowflake.execute( {sqlText: "ROLLBACK WORK;"} );
    var rowsUpdated=rowsInserted=missingTimestamps=-1 ;
    throw err;
}
finally{
	snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
}
return JSON.stringify({"Rows inserted":rowsInserted,"Rows deleted":rowsDeleted});
$$;

