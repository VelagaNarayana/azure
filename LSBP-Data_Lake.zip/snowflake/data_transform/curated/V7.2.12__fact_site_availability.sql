use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

CREATE OR REPLACE stream "REFERENCE"."STRM_QB_INCIDENTS" on table "REFERENCE"."QB_INCIDENTS";
