use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

drop table if exists "CONTROL"."TBL_QUICKBASE_LOAD";

 create or replace table "CONTROL"."QUICKBASE_LOAD" (
    qb_table_code varchar(20) not null,
    qb_table_name varchar(50) not null,
    sf_schema varchar(30) not null,
    sf_table_name varchar(50) not null,
    daily_load boolean not null
);

insert into "CONTROL"."QUICKBASE_LOAD" values ('bmjditiru','O&M Site Master','REFERENCE','QB_O_M_SITE_MASTER',true);
insert into "CONTROL"."QUICKBASE_LOAD" values ('bpp7fff5z','O&M Meters Database','REFERENCE', 'QB_O_M_METERS_DATABASE',true);
insert into "CONTROL"."QUICKBASE_LOAD" values ('bnaz7cqj2','O&M Performance Reporting SQL','REFERENCE','QB_O_M_PERFORMANCE_REPORTING_SQL',true);
insert into "CONTROL"."QUICKBASE_LOAD" values ('bpsuegws4','O&M Sharepoint','REFERENCE','QB_O_M_SHAREPOINT',true);
insert into "CONTROL"."QUICKBASE_LOAD" values ('bmmvyw6fg','O&M Site Devices','REFERENCE','QB_O_M_SITE_DEVICES',true);
--insert into "CONTROL"."QUICKBASE_LOAD" values ('bja8fjw96','daily site summaries','REFERENCE','QB_DAILY_SITE_SUMMARIES',true); 
insert into "CONTROL"."QUICKBASE_LOAD" values ('bm6adgc8r','O&M DNO Outages','REFERENCE','QB_O_M_DNO_OUTAGES',true);
insert into "CONTROL"."QUICKBASE_LOAD" values ('bjbw8k8ae','Monthly Resume','REFERENCE','QB_MONTHLY_RESUME',true);
insert into "CONTROL"."QUICKBASE_LOAD" values ('bkce6eipf', 'Geographic Regions','REFERENCE','QB_GEOGRAPHIC_REGIONS',true);
