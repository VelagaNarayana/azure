use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

CREATE OR REPLACE TABLE CONTROL.CONTROL_PARAMETERS
(
    PARAM_KEY	INTEGER IDENTITY PRIMARY KEY,
    PARAM_NAME	VARCHAR (1000) NOT NULL,
    PARAM_TYPE	VARCHAR (1000),
    UPDATED_TS	TIMESTAMP NOT NULL,
    UPDATED_BY	VARCHAR (1000) NOT NULL
)DATA_RETENTION_TIME_IN_DAYS = 31
COMMENT = "Configuration table for parameters" ;

CREATE OR REPLACE TABLE CONTROL.SITE_CONFIG
(
    CONFIG_KEY	INTEGER IDENTITY , 
    SITE_FKEY	INTEGER,
    CONTROL_PARAMETER_FKEY	INTEGER  references CONTROL.CONTROL_PARAMETERS (PARAM_KEY),
    CONTROL_PARAMETER_VALUE	VARCHAR,
    STATUS	VARCHAR(50) NOT NULL,
    ACTIVE_FROM	DATE,
    ACTIVE_TO	DATE,
    UPDATED_TS	TIMESTAMP DEFAULT sysdate() , 
    UPDATED_BY	VARCHAR (1000)
)DATA_RETENTION_TIME_IN_DAYS = 31
comment = "Configuration table for sites parameter" ;

CREATE OR REPLACE VIEW CONTROL.VW_SITE_ACTIVE_CONFIG
AS
SELECT 
	site_config.site_fkey as site_key,
	param.param_name as parameter_name,
	param.param_type as parameter_type,
	site_config.control_parameter_value as parameter_value,
	STATUS,
	active_from,
	active_to 
FROM 
	"CONTROL"."SITE_CONFIG" site_config INNER JOIN "CONTROL"."CONTROL_PARAMETERS" param 
ON site_config.control_parameter_fkey = param.param_key
WHERE STATUS IN ('DEFAULT','OVERRIDE');

CREATE OR REPLACE FUNCTION CONTROL.FN_SITE_ACTIVE_CONFIG(FROM_DT DATE, TO_DT DATE)
RETURNS TABLE (SITE_KEY INTEGER, PARAMETER_DATE DATE, PARAMETER_NAME VARCHAR, PARAMETER_TYPE VARCHAR, PARAMETER_VALUE VARCHAR, ACTIVE_FROM DATE, ACTIVE_TO DATE, STATUS VARCHAR)
 AS
 $$
 SELECT SITE_KEY,PARAMETER_DATE,PARAMETER_NAME,PARAMETER_TYPE,PARAMETER_VALUE,ACTIVE_FROM,ACTIVE_TO,STATUS FROM
      (
          SELECT dt.date as PARAMETER_DATE,
          config.*,
          NVL(config.active_to,to_date(SYSDATE())) as todate_tocompare,
          CASE WHEN (status = 'DEFAULT') OR (status = 'OVERRIDE' AND dt.date BETWEEN config.active_from and todate_tocompare) THEN TRUE ELSE FALSE END AS VALID_PARAMETER,           
          row_number() over (PARTITION BY  site_key,parameter_name,parameter_type,dt.date ORDER BY status desc) as row_number          
          FROM "CURATED"."DIM_CALENDAR_DATE" dt
          CROSS JOIN  "CONTROL"."VW_SITE_ACTIVE_CONFIG" config       
          WHERE date between FROM_DT and TO_DT
          AND VALID_PARAMETER = TRUE  
      )config WHERE row_number = 1        
$$;