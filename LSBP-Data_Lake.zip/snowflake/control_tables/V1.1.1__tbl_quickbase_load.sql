use database data_lake_{{ env }};
use warehouse DATA_LOAD_{{ env }}_WH;
use role dl_{{ env }}_data_engineers;

create table if not exists "CONTROL"."TBL_QUICKBASE_LOAD" (
    qb_table_code varchar(20) not null,
    qb_table_name varchar(30) not null
);

insert into "CONTROL"."TBL_QUICKBASE_LOAD" values ('bmjditiru','O&M Site Master');
insert into "CONTROL"."TBL_QUICKBASE_LOAD" values ('bpp7fff5z','O&M Meters Database');
insert into "CONTROL"."TBL_QUICKBASE_LOAD" values ('bnaz7cqj2','O&M Performance Reporting SQL');
insert into "CONTROL"."TBL_QUICKBASE_LOAD" values ('bpsuegws4','O&M Sharepoint');

