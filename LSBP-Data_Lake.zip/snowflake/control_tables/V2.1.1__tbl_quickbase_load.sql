use database data_lake_{{ env }};
use warehouse DATA_LOAD_{{ env }}_WH;
use role dl_{{ env }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

drop table if exists "CONTROL"."TBL_QUICKBASE_LOAD";

create table "CONTROL"."TBL_QUICKBASE_LOAD" (
    qb_table_code varchar(20) not null,
    qb_table_name varchar(50) not null,
    sf_schema varchar(30) not null,
    sf_table_name varchar(50) not null
);

insert into "CONTROL"."TBL_QUICKBASE_LOAD" values ('bmjditiru','O&M Site Master','REFERENCE','QB_O_M_SITE_MASTER');
insert into "CONTROL"."TBL_QUICKBASE_LOAD" values ('bpp7fff5z','O&M Meters Database','REFERENCE', 'QB_O_M_METERS_DATABASE');
insert into "CONTROL"."TBL_QUICKBASE_LOAD" values ('bnaz7cqj2','O&M Performance Reporting SQL','REFERENCE','QB_O_M_PERFORMANCE_REPORTING_SQL');
insert into "CONTROL"."TBL_QUICKBASE_LOAD" values ('bpsuegws4','O&M Sharepoint','REFERENCE','QB_O_M_SHAREPOINT');
insert into "CONTROL"."TBL_QUICKBASE_LOAD" values ('bmmvyw6fg','O&M Site Devices','REFERENCE','QB_O_M_SITE_DEVICES');
insert into "CONTROL"."TBL_QUICKBASE_LOAD" values ('bm6adgc8r','O&M DNO Outages','REFERENCE','QB_O_M_DNO_OUTAGES');
--insert into "CONTROL"."TBL_QUICKBASE_LOAD" values ('bja8fjw96','daily site summaries','REFERENCE','QB_DAILY_SITE_SUMMARIES');
insert into "CONTROL"."TBL_QUICKBASE_LOAD" values ('bjbw8k8ae','Monthly Resume','REFERENCE','QB_MONTHLY_RESUME');
insert into "CONTROL"."TBL_QUICKBASE_LOAD" values ('bkce6eipf', 'Geographic Regions','REFERENCE','QB_GEOGRAPHIC_REGIONS');

ALTER TABLE IF EXISTS  "CONTROL"."TBL_QUICKBASE_LOAD" RENAME TO "CONTROL"."QUICKBASE_LOAD";
