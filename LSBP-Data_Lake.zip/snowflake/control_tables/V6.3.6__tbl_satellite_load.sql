use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

update control.satellite_load set other_config=to_variant('<pv:system installedPower="1" installationType="FREE_STANDING" selfShading="false">
            <pv:module type="CSI"></pv:module>
            <pv:inverter></pv:inverter>
            <pv:losses></pv:losses>
             <pv:topology xsi:type="pv:TopologyColumn" relativeSpacing="3.5" type="UNPROPORTIONAL2"/>             
        </pv:system>') where insolar_site_id='15e1d6a1-9807-4146-b241-f5340a65150d';


update control.satellite_load set other_config=to_variant('<pv:system installedPower="1" installationType="FREE_STANDING" selfShading="false">
            <pv:module type="CSI"></pv:module>
            <pv:inverter></pv:inverter>
            <pv:losses></pv:losses>
             <pv:topology xsi:type="pv:TopologyColumn" relativeSpacing="3.3" type="UNPROPORTIONAL2"/>             
        </pv:system>') where insolar_site_id='fb5416c5-2783-4f04-b819-6b3405e4fe69';

update control.satellite_load set other_config=to_variant('<pv:system installedPower="1" installationType="FREE_STANDING" selfShading="false">
            <pv:module type="CSI"></pv:module>
            <pv:inverter></pv:inverter>
            <pv:losses></pv:losses>
             <pv:topology xsi:type="pv:TopologyColumn" relativeSpacing="3.4" type="UNPROPORTIONAL2"/>             
        </pv:system>') where insolar_site_id='dfbfda61-241b-4a3f-9228-adb697cb8bcf';


update control.satellite_load set other_config=to_variant('<pv:system installedPower="1" installationType="FREE_STANDING" selfShading="false">
            <pv:module type="CSI"></pv:module>
            <pv:inverter></pv:inverter>
            <pv:losses></pv:losses>
             <pv:topology xsi:type="pv:TopologyColumn" relativeSpacing="2.3" type="UNPROPORTIONAL2"/>             
        </pv:system>') where insolar_site_id='eb6eb532-1105-462c-a1a2-8b1ca2f3e24e'; 

update control.satellite_load set other_config=to_variant('<pv:system installedPower="1" installationType="FREE_STANDING" selfShading="false">
            <pv:module type="CSI"></pv:module>
            <pv:inverter></pv:inverter>
            <pv:losses></pv:losses>
             <pv:topology xsi:type="pv:TopologyColumn" relativeSpacing="2.1" type="UNPROPORTIONAL2"/>             
        </pv:system>') where insolar_site_id='5c4ba477-84d2-45d6-8666-cb280f08f1b4';


update control.satellite_load set other_config=to_variant('<pv:system installedPower="1" installationType="FREE_STANDING" selfShading="false">
            <pv:module type="CSI"></pv:module>
            <pv:inverter></pv:inverter>
            <pv:losses></pv:losses>
             <pv:topology xsi:type="pv:TopologyColumn" relativeSpacing="2.5" type="UNPROPORTIONAL2"/>             
        </pv:system>') where insolar_site_id='2db3996d-007b-4e47-ad6b-5382fffdb55f';
 