use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

delete from control.fact_table_load_queries where query_source = 'Stage' and data_source = 'Insolar';

INSERT INTO control.fact_table_load_queries(data_source,fact_table,parse_query,query_source) VALUES ('Insolar','RAW.FACT_SITE_MEASUREMENTS',$$ SELECT PAYLOAD:measurement_source_id::STRING AS MSRMNT_ID, PAYLOAD:measurement_time::STRING as MSRMNT_TS, TRY_TO_DATE(SUBSTR(MSRMNT_TS,0,10)) AS MSRMNT_DATE, TRY_TO_TIME(SUBSTR(MSRMNT_TS,12,19)) AS MSRMNT_TIME, CASE WHEN second(MSRMNT_TIME) > 30 THEN date_trunc('MINUTE',TIMEADD('MINUTE',1,MSRMNT_TIME))  ELSE date_trunc('MINUTE', MSRMNT_TIME) END AS MSRMNT_TIME_IN_MIN, PAYLOAD:value::varchar AS VALUE, concat_ws('-','${process_run_id}',process_exec_id) as process_exec_id, DATE_PART('EPOCH_SECOND', file_arrival_date)+coalesce(regexp_substr(filename, '(str|dbl)_(\\d+)\.',1,1,'e',2)::integer,0) as  file_arrival_date, filename FROM RAW.STAGE_INSOLAR_TS where ${filter_or_path} $$,'Stage');


delete from control.fact_table_load_queries where query_source = 'Stream' and data_source = 'Insolar';

INSERT INTO control.fact_table_load_queries(data_source,fact_table,parse_query,query_source) VALUES ('Insolar','RAW.FACT_SITE_MEASUREMENTS',$$ select * from (SELECT PAYLOAD:measurement_source_id::STRING AS MSRMNT_ID, PAYLOAD:measurement_time::STRING as MSRMNT_TS, TRY_TO_DATE(SUBSTR(MSRMNT_TS,0,10)) AS MSRMNT_DATE, TRY_TO_TIME(SUBSTR(MSRMNT_TS,12,19)) AS MSRMNT_TIME, CASE WHEN second(MSRMNT_TIME) > 30 THEN date_trunc('MINUTE',TIMEADD('MINUTE',1,MSRMNT_TIME)) ELSE date_trunc('MINUTE', MSRMNT_TIME) END AS MSRMNT_TIME_IN_MIN, PAYLOAD:value::varchar AS VALUE, concat_ws('-','${process_run_id}',process_exec_id) as process_exec_id, regexp_substr(filename, '(str|dbl)_(\\d+)\.',1,1,'e',2)::integer as fileno, file_arrival_date, row_number() over (partition by MSRMNT_ID,MSRMNT_TS order by file_arrival_date,fileno DESC) as rank, filename FROM RAW.STRM_STAGE_INSOLAR_TS_FACT_INSOLAR_TS where ${filter_or_path} ) fact_data where rank = 1  $$,'Stream');