use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace view control.satellite_tz_load as
select sat.*, nvl(coalesce(site.derived_timezone, site.source_timezone ),'UTC') as timezone from 
control.satellite_load sat left join curated.dim_sites site 
on sat.insolar_site_id = site.site_id 