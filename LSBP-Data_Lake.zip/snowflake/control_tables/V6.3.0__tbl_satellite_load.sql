use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

alter table control.satellite_load 
add column other_config variant;

create or replace view control.satellite_tz_load as
select sat.*, coalesce(to_varchar(sat.other_config),'') as other_config_str, nvl(coalesce(site.derived_timezone, site.source_timezone ),'UTC') as timezone from 
control.satellite_load sat left join curated.dim_sites site 
on sat.insolar_site_id = site.site_id;

update control.satellite_load set other_config=to_variant('<pv:system installedPower="1" installationType="FREE_STANDING" selfShading="false">
            <pv:module type="CSI"></pv:module>
            <pv:inverter></pv:inverter>
            <pv:losses></pv:losses>
             <pv:topology xsi:type="pv:TopologyColumn" relativeSpacing="2.3" type="UNPROPORTIONAL2"/>             
        </pv:system>') where insolar_site_id='305673d4-98a1-446e-a8cb-d1464e9407ee';
        
        
update control.satellite_load set other_config=to_variant('<pv:system installedPower="1" installationType="FREE_STANDING" selfShading="false">
            <pv:module type="CSI"></pv:module>
            <pv:inverter></pv:inverter>
            <pv:losses></pv:losses>
             <pv:topology xsi:type="pv:TopologyColumn" relativeSpacing="3.3" type="UNPROPORTIONAL2"/>             
        </pv:system>') where insolar_site_id='f7f47eb7-3063-4933-b314-36906b439626';

update control.satellite_load set other_config=to_variant('<pv:system installedPower="1" installationType="FREE_STANDING" selfShading="false">
            <pv:module type="CSI"></pv:module>
            <pv:inverter></pv:inverter>
            <pv:losses></pv:losses>
             <pv:topology xsi:type="pv:TopologyColumn" relativeSpacing="3.0" type="UNPROPORTIONAL2"/>             
        </pv:system>') where insolar_site_id='6bb02858-6a46-44d7-827c-53e03fb95cfc';
        
        
update control.satellite_load set other_config=to_variant('<pv:system installedPower="1" installationType="FREE_STANDING" selfShading="false">
            <pv:module type="CSI"></pv:module>
            <pv:inverter></pv:inverter>
            <pv:losses></pv:losses>
             <pv:topology xsi:type="pv:TopologyColumn" relativeSpacing="2.4" type="UNPROPORTIONAL2"/>             
        </pv:system>') where insolar_site_id='78384234-b6f9-49af-a0d8-d7566f5afa9a'; 
 