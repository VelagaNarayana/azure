use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

DELETE FROM control.fact_table_load_queries where FACT_TABLE  = 'RAW.FACT_SITE_MEASUREMENTS' AND DATA_SOURCE = 'Insolar' AND QUERY_SOURCE = 'Stage';

INSERT INTO control.fact_table_load_queries(data_source,fact_table,parse_query,query_source) VALUES ('Insolar','RAW.FACT_SITE_MEASUREMENTS',$$ SELECT PAYLOAD:measurement_source_id::STRING AS MSRMNT_ID,'UTC' as source_data_tz, PAYLOAD:measurement_time::STRING as MSRMNT_TS, TRY_TO_DATE(SUBSTR(MSRMNT_TS,0,10)) AS MSRMNT_DATE, TRY_TO_TIME(SUBSTR(MSRMNT_TS,12,19)) AS MSRMNT_TIME, CASE WHEN second(MSRMNT_TIME) > 30 THEN date_trunc('MINUTE',TIMEADD('MINUTE',1,MSRMNT_TIME))  ELSE date_trunc('MINUTE', MSRMNT_TIME) END AS MSRMNT_TIME_IN_MIN, PAYLOAD:value::varchar AS VALUE, concat_ws('-','${process_run_id}',process_exec_id) as process_exec_id, file_arrival_date, filename FROM RAW.STAGE_INSOLAR_TS where ${filter_or_path} $$,'Stage');


DELETE FROM control.fact_table_load_queries where  FACT_TABLE  = 'RAW.FACT_SITE_MEASUREMENTS' AND DATA_SOURCE = 'Insolar' AND QUERY_SOURCE = 'Stream';

INSERT INTO control.fact_table_load_queries(data_source,fact_table,parse_query,query_source) VALUES ('Insolar','RAW.FACT_SITE_MEASUREMENTS',$$ SELECT PAYLOAD:measurement_source_id::STRING AS MSRMNT_ID,'UTC' as source_data_tz, PAYLOAD:measurement_time::STRING as MSRMNT_TS, TRY_TO_DATE(SUBSTR(MSRMNT_TS,0,10)) AS MSRMNT_DATE,TRY_TO_TIME(SUBSTR(MSRMNT_TS,12,19)) AS MSRMNT_TIME, CASE WHEN second(MSRMNT_TIME) > 30 THEN date_trunc('MINUTE',TIMEADD('MINUTE',1,MSRMNT_TIME))  ELSE date_trunc('MINUTE', MSRMNT_TIME) END AS MSRMNT_TIME_IN_MIN, PAYLOAD:value::varchar AS VALUE, concat_ws('-','${process_run_id}',process_exec_id) as process_exec_id, file_arrival_date, filename FROM RAW.STRM_STAGE_INSOLAR_TS_FACT_INSOLAR_TS where ${filter_or_path}$$,'Stream');


DELETE FROM control.fact_table_load_queries where  FACT_TABLE  = 'RAW.FACT_SITE_MEASUREMENTS' AND DATA_SOURCE = 'Meteo Control' AND QUERY_SOURCE = 'Meteo Control LZ';

INSERT INTO CONTROL.FACT_TABLE_LOAD_QUERIES(data_source,fact_table,parse_query,query_source) VALUES ('Meteo Control','RAW.FACT_SITE_MEASUREMENTS',$$ select  case  when metadata.typeofmeasurement in ('basics','calculations') then concat(metadata.systemkey,'/',metadata.typeofmeasurement,'/',metadata.abbreviationid) else concat(metadata.systemkey,'/',metadata.typeofmeasurement,'/',metadata.deviceid,'/',metadata.abbreviationid) end as MSRMNT_ID, 'UTC' as source_data_tz, timeseries.split_column[0]::timestamp as MSRMNT_TS, TRY_TO_DATE(SUBSTR(MSRMNT_TS,0,10)) AS MSRMNT_DATE,  TRY_TO_TIME(SUBSTR(MSRMNT_TS,12,19)) AS MSRMNT_TIME, CASE WHEN second(MSRMNT_TIME) > 30 THEN date_trunc('MINUTE',TIMEADD('MINUTE',1,MSRMNT_TIME))  ELSE date_trunc('MINUTE', MSRMNT_TIME) END AS MSRMNT_TIME_IN_MIN,  timeseries.split_column[metadata.index]::varchar as VALUE, '${process_run_id}' as process_exec_id, TO_DATE(REGEXP_SUBSTR (timeseries.filename,'(\\d{4}\/\\d{2}\/\\d{2})'),'YYYY/MM/DD') as file_arrival_date, timeseries.filename from "COMMON"."METEOCONTROL_METADATA_${process_run_id}" metadata cross join  "COMMON"."METEOCONTROL_TIMESERIES_${process_run_id}" timeseries    $$,'Meteo Control LZ');

update control.fact_table_load_queries set parse_query=regexp_replace(parse_query,'select',$$select 'UTC' as source_data_tz,$$,1,1) where fact_table='RAW.FACT_PRODUCTION_METER'
