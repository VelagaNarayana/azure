use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

CREATE OR REPLACE TEMPORARY TABLE COMMON.CONFIG_LOAD
(
    Site_Master_Site_ID INTEGER,
    Site_Reference VARCHAR(255),
    Site_Master_Site_Name VARCHAR(4000),    
    Data_Series_Type VARCHAR(255),   
    Consecutive_Values_to_Reject VARCHAR(100),
    Maximum_Gap_to_Interpolate VARCHAR(100),
    Maximum_Records_to_Backfill varchar(100),
    Irradiance_Minimum VARCHAR(100),
    Irradiance_Maximum VARCHAR(100),
    Sunrise_Buffer_Mins VARCHAR(100),
    Sunset_Buffer_Mins VARCHAR(100),
    Maximum_Tracker_Deviation VARCHAR(100),
    Site_ID_Insolar VARCHAR(255),
    Site_ID_Meteocontrol VARCHAR(255), 
    Client_ID_Meteocontrol  VARCHAR(255) 
);

PUT file:///home/vsts/work/1/s/snowflake/control_tables/config_load/irradiance_control_parameters.csv @common.%config_load;

COPY INTO COMMON.CONFIG_LOAD 
file_format  = (TYPE = 'CSV' COMPRESSION = 'AUTO' FIELD_DELIMITER = ',' RECORD_DELIMITER = '\n' 
                SKIP_HEADER = 1 FIELD_OPTIONALLY_ENCLOSED_BY = '\042' TRIM_SPACE = FALSE ERROR_ON_COLUMN_COUNT_MISMATCH = TRUE 
                ESCAPE = 'NONE' ESCAPE_UNENCLOSED_FIELD = '\134' DATE_FORMAT = 'AUTO' TIMESTAMP_FORMAT = 'AUTO' NULL_IF = ('\\N'));

insert into control.site_config(site_fkey,site_id,control_parameter_fkey, control_parameter_value, status, active_from, active_to,updated_by)
with config as (SELECT Site_ID_Insolar as site_id, config.site_master_site_id,
max(CONSECUTIVE_VALUES_TO_REJECT) as "Consecutive Values to Reject",
max(MAXIMUM_GAP_TO_INTERPOLATE) as "Maximum Gap to Interpolate",
max(Irradiance_Maximum) as "Irradiance Maximum",
max(abs(SUNRISE_BUFFER_MINS)::string) as "Sunrise Buffer",
max(abs(SUNSET_BUFFER_MINS)::string) as "Sunset Buffer",
max(Irradiance_Minimum) as "Irradiance Minimum",
max(Maximum_Tracker_Deviation) as "Maximum Tracker Deviation"
FROM COMMON.CONFIG_LOAD config 
WHERE site_id is not null
group by 1,2)
select site.site_key as site_fkey, tmp.site_id as site_id, cp.param_key as control_parameter_fkey, 
       cvalues as control_parameter_value, 'DEFAULT' as status, '2010-01-01' as active_from,  '2030-12-31' as active_to, 'DevOps' as updated_by from 
(select * from config
    unpivot(cvalues for params in ( "Consecutive Values to Reject","Maximum Gap to Interpolate", "Irradiance Maximum","Sunrise Buffer", "Sunset Buffer", "Irradiance Minimum" ,"Maximum Tracker Deviation"))) tmp
join control.control_parameters cp on tmp.params=cp.param_name
join curated.dim_sites site ON tmp.site_master_site_id = site_id_formula;