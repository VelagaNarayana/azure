use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

CREATE OR REPLACE TEMPORARY TABLE COMMON.SITE_CONFIG_LOAD
(
    SITE_ID VARCHAR(255)
    ,CONTROL_PARAMETER_FKEY NUMBER(38,0) 
    ,CONTROL_PARAMETER_VALUE VARCHAR(16777216)
   -- ,STATUS VARCHAR(50)   
   -- ,ACTIVE_FROM DATE
   -- ,ACTIVE_TO DATE
   -- ,UPDATED_TS TIMESTAMP_NTZ(9)
   -- ,UPDATED_BY VARCHAR(1000)
);

PUT file:///home/vsts/work/1/s/snowflake/control_tables/config_load/site_config_control_table_8.0.2.csv @common.%site_config_load;

COPY INTO COMMON.SITE_CONFIG_LOAD
file_format  = (TYPE = 'CSV' COMPRESSION = 'AUTO' FIELD_DELIMITER = ',' RECORD_DELIMITER = '\n' 
                SKIP_HEADER = 1 FIELD_OPTIONALLY_ENCLOSED_BY = '\042' TRIM_SPACE = FALSE ERROR_ON_COLUMN_COUNT_MISMATCH = TRUE 
                ESCAPE = 'NONE' ESCAPE_UNENCLOSED_FIELD = '\134' DATE_FORMAT = 'AUTO' TIMESTAMP_FORMAT = 'AUTO' NULL_IF = ('\\N'));


insert into control.site_config(site_fkey,site_id,control_parameter_fkey, control_parameter_value, status, active_from, active_to,updated_by)
select site.site_key as site_fkey, tmp.site_id as site_id, tmp.control_parameter_fkey as control_parameter_fkey, 
       tmp.control_parameter_value, 'DEFAULT' as status, null as active_from,  null as active_to, 'DevOps V8.0.2' as updated_by from 
common.site_config_load tmp
join curated.dim_sites site on tmp.site_id = site.site_id;