use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

INSERT INTO control.control_parameters (param_name,param_type,updated_ts,updated_by)
select  'Satellite Minimum' as param_name,'Value' as param_type,SYSDATE() as updated_ts,'DevOps V6.3.7' as updated_by
where param_name not in (select param_name from control.control_parameters )
;

CREATE OR REPLACE TEMPORARY TABLE COMMON.SATELLITE_THRESHOLD_CONFIG_LOAD
(
    Site_Reference VARCHAR(255),
    Site_Master_Site_Name VARCHAR(4000),   
    Satellite_Threshold varchar(10)
);

PUT file:///home/vsts/work/1/s/snowflake/control_tables/config_load/satellite_threshold_control_parameters.csv @common.%satellite_threshold_config_load;

COPY INTO COMMON.SATELLITE_THRESHOLD_CONFIG_LOAD 
file_format  = (TYPE = 'CSV' COMPRESSION = 'AUTO' FIELD_DELIMITER = ',' RECORD_DELIMITER = '\n' 
                SKIP_HEADER = 1 FIELD_OPTIONALLY_ENCLOSED_BY = '\042' TRIM_SPACE = FALSE ERROR_ON_COLUMN_COUNT_MISMATCH = TRUE 
                ESCAPE = 'NONE' ESCAPE_UNENCLOSED_FIELD = '\134' DATE_FORMAT = 'AUTO' TIMESTAMP_FORMAT = 'AUTO' NULL_IF = ('\\N'));

delete from control.site_config 
where status='DEFAULT' and control_parameter_fkey in 
(select param_key from control.control_parameters where param_name = 'Satellite Minimum');

insert into control.site_config(site_fkey,site_id,control_parameter_fkey, control_parameter_value, status, active_from, active_to,updated_by)
with config as (select site.site_key as site_fkey, 
            site.site_id as site_id, 
            cp.param_key as control_parameter_fkey, 
            coalesce(tmp.Satellite_Threshold,'30') as control_parameter_value, 
            'DEFAULT' as status, 
            NULL as active_from,  
            NULL as active_to, 'DevOps V6.3.7' as updated_by 
        from  COMMON.SATELLITE_THRESHOLD_CONFIG_LOAD tmp
    join curated.dim_sites site ON tmp.Site_Reference = site.site_reference_formula 
    join control.control_parameters cp on cp.param_name = 'Satellite Minimum') 
select site_fkey,site_id,control_parameter_fkey, control_parameter_value, status, active_from, active_to, updated_by
from config;         


