use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

CREATE OR REPLACE TEMPORARY TABLE COMMON.CONFIG_LOAD
(
    Site_Reference VARCHAR(255),
    Site_Master_Site_Name VARCHAR(4000),   
    Source_System varchar(100), 
    Data_Series_Type VARCHAR(255),   
    Data_Series_Name VARCHAR(500),
    Typical_Filename VARCHAR(500),
    Site_ID_Insolar VARCHAR(255),
    Segment_ID VARCHAR(255), 
    Parameter_ID  VARCHAR(255),
    Segment_Name VARCHAR(255)
);

PUT file:///home/vsts/work/1/s/snowflake/control_tables/config_load/international_pyranometers_control_table.csv @common.%config_load;

COPY INTO COMMON.CONFIG_LOAD 
file_format  = (TYPE = 'CSV' COMPRESSION = 'AUTO' FIELD_DELIMITER = ',' RECORD_DELIMITER = '\n' 
                SKIP_HEADER = 1 FIELD_OPTIONALLY_ENCLOSED_BY = '\042' TRIM_SPACE = FALSE ERROR_ON_COLUMN_COUNT_MISMATCH = TRUE 
                ESCAPE = 'NONE' ESCAPE_UNENCLOSED_FIELD = '\134' DATE_FORMAT = 'AUTO' TIMESTAMP_FORMAT = 'AUTO' NULL_IF = ('\\N'));

create or replace temporary table common.temp_config as
SELECT Site_ID_Insolar as site_id, case when stg.data_series_type='Production' then 'Production Data Meters' else 'Irradiance' end as param_name,
listagg(distinct parameter_id,',') as param_values
FROM COMMON.CONFIG_LOAD stg
where  site_id is not null      
group by 1,2
union
select distinct site_id_insolar as site_id, 'Satellite' as param_name,
'GTI' as param_values
FROM COMMON.CONFIG_LOAD stg;

insert into control.site_config(site_fkey,site_id,control_parameter_fkey, control_parameter_value, status, active_from, active_to,updated_by)
select site.site_key as site_fkey, tmp.site_id as site_id, cp.param_key as control_parameter_fkey, 
       param_values as control_parameter_value, 'DEFAULT' as status, '2010-01-01' as active_from,  '2099-12-31' as active_to, 'DevOps' as updated_by from 
common.temp_config tmp
join control.control_parameters cp on tmp.param_name=cp.param_name
join curated.dim_sites site ON tmp.site_id = site.site_id;            