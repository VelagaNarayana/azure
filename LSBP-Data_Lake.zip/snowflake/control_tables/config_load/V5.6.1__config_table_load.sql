use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

CREATE OR REPLACE TEMPORARY TABLE COMMON.CONFIG_LOAD
(   
    Site_Master_Site_ID INTEGER,
    Site_Reference VARCHAR(255),
    Site_Master_Site_Name VARCHAR(4000),     
    Data_Series_Type VARCHAR(255),
    Filename_Lookup VARCHAR(4000),
    Site_ID_Insolar VARCHAR(255),
    Site_ID_Meteocontrol VARCHAR(255), 
    Device_ID_Insolar VARCHAR(255),
    Device_ID_Meteocontrol VARCHAR(255),
    Device_Group_Multiplier VARCHAR(255), 
    Device_Group VARCHAR(255)
);

PUT file:///home/vsts/work/1/s/snowflake/control_tables/config_load/uk_pyranometers_control_table.csv @common.%config_load;

COPY INTO COMMON.CONFIG_LOAD 
file_format  = (TYPE = 'CSV' COMPRESSION = 'AUTO' FIELD_DELIMITER = ',' RECORD_DELIMITER = '\n' 
                SKIP_HEADER = 1 FIELD_OPTIONALLY_ENCLOSED_BY = '\042' TRIM_SPACE = FALSE ERROR_ON_COLUMN_COUNT_MISMATCH = TRUE 
                ESCAPE = 'NONE' ESCAPE_UNENCLOSED_FIELD = '\134' DATE_FORMAT = 'AUTO' TIMESTAMP_FORMAT = 'AUTO' NULL_IF = ('\\N'));

create or replace temporary table common.temp_config as
SELECT Site_ID_Insolar as site_id, stg.site_master_site_id,
max('GTI') as "Satellite",
listagg(distinct device_id_insolar,',') as "Irradiance"
FROM COMMON.CONFIG_LOAD stg
where  site_id is not null               
group by 1,2;

insert into control.site_config(site_fkey,site_id,control_parameter_fkey, control_parameter_value, status, active_from, active_to,updated_by)
select site.site_key as site_fkey, tmp.site_id as site_id, cp.param_key as control_parameter_fkey, 
       cvalues as control_parameter_value, 'DEFAULT' as status, '2010-01-01' as active_from,  '2099-12-31' as active_to, 'DevOps' as updated_by from 
(select * from common.temp_config config
    unpivot(cvalues for params in ( "Irradiance","Satellite"))) tmp
join control.control_parameters cp on tmp.params=cp.param_name
join curated.dim_sites site ON tmp.site_master_site_id = site_id_formula;

insert into control.site_config(site_fkey,site_id,control_parameter_fkey, control_parameter_value, status, active_from, active_to, updated_by)
with config as (SELECT Site_ID_Insolar as site_id, config.site_master_site_id,              
device_group as "name",
concat('Device group ',rank() over (partition by Site_ID_Insolar, site_master_site_id order by device_group)) as device_group,            
avg(device_group_multiplier)::string as "multiplier",   
listagg(distinct device_id_insolar,',') as "irradiance",
'GTI' as "satellite" 
from COMMON.CONFIG_LOAD config 
WHERE site_id is not null and device_group is not null
group by 1,2,3)
select site.site_key as site_fkey, tmp.site_id as site_id, cp.param_key as control_parameter_fkey, 
       cvalues as control_parameter_value, 'DEFAULT' as status, '2010-01-01' as active_from,  '2030-12-31' as active_to, 'DevOps' as updated_by from 
(select site_id, site_master_site_id, concat(device_group,' - ',params) as param, cvalues from config
unpivot(cvalues for params in ( "name","irradiance","multiplier", "satellite") ))tmp
join control.control_parameters cp on tmp.param=cp.param_name
join curated.dim_sites site ON tmp.site_master_site_id = site_id_formula;