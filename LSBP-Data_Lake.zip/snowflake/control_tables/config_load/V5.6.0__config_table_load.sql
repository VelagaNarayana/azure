use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';


INSERT INTO control.control_parameters (param_name,param_type,updated_ts,updated_by)
select  'Production Data Meters' as param_name,'Meters' as param_type,SYSDATE() as updated_ts,'DevOps' as updated_by
where param_name not in (select param_name from control.control_parameters )
;
create temporary table common.config_load 
(
  SITE_ID VARCHAR(50),PARAM_NAME VARCHAR(1000),CONTROL_PARAMETER_VALUE VARCHAR,STATUS VARCHAR(50),ACTIVE_FROM DATE,ACTIVE_TO DATE
 );
PUT file:///home/vsts/work/1/s/snowflake/control_tables/config_load/config_prod_meter.csv @common.%config_load;
COPY INTO common.config_load
FILE_FORMAT= (TYPE=CSV SKIP_HEADER = 1 FIELD_OPTIONALLY_ENCLOSED_BY = '\042');
insert into control.site_config(site_fkey,control_parameter_fkey,control_parameter_value,status,active_from, active_to, updated_ts, updated_by)
select s.site_key as site_fkey, cp.param_key, sc.control_parameter_value, sc.status, sc.active_from, sc.active_to,sysdate(),'DevOps'
from common.config_load sc inner join curated.dim_sites s on sc.site_id = s.site_id
inner join control.control_parameters cp on sc.param_name = cp.param_name;