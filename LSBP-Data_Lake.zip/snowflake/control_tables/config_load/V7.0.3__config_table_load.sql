use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

update control.site_config sc set control_parameter_value=concat(control_parameter_value,' 1'), updated_ts=sysdate(), updated_by='DevOps 7.2.9'
 from control.control_parameters cp 
where cp.param_key = sc.control_parameter_fkey and cp.param_name='Satellite';

update control.site_config sc set control_parameter_value=concat(control_parameter_value,' 1'), updated_ts=sysdate(), updated_by='DevOps 7.2.9'
 from control.control_parameters cp 
where cp.param_key = sc.control_parameter_fkey and cp.param_name='Device group 1 - satellite';

update control.site_config sc set control_parameter_value=concat(control_parameter_value,' 2'), updated_ts=sysdate(), updated_by='DevOps 7.2.9'
 from control.control_parameters cp 
where cp.param_key = sc.control_parameter_fkey and cp.param_name='Device group 2 - satellite';