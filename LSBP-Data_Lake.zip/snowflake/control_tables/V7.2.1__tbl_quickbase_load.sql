use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

insert into "CONTROL"."QUICKBASE_LOAD" values ('bja8fjw95','Incidents','REFERENCE','QB_INCIDENTS',false);
