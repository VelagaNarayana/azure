use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

DELETE FROM control.fact_table_load_queries where FACT_TABLE  = 'RAW.FACT_PRODUCTION_METER' AND DATA_SOURCE = 'Pentaho History' AND QUERY_SOURCE = 'Pentaho History';

INSERT INTO control.fact_table_load_queries(data_source,fact_table,parse_query,query_source) VALUES ('Pentaho History','RAW.FACT_PRODUCTION_METER',$$ select 'UTC' as source_data_tz, meta.device_id_insolar as meter_id,to_date(timestamp) as pdate,to_time(timestamp) as ptime,raw_value as meter_value,timestamp as original_date_time,'REFERENCE.PENTAHO_GENERATION_ADJUSTED_DATA_SERIES_INSOLAR'||to_char(TO_DATE(record_timestamp),'YYYY/MM/DD') as filename from reference.pentaho_generation_adjusted_data_series_insolar dat JOIN REFERENCE.PENTAHO_DEVICE_INFORMATION_FOR_REPORTING  meta on dat.data_series = meta.data_series and year(timestamp) =  year(reporting_month_start) and month(timestamp) =  month(reporting_month_start) and dat.site_id = meta.site_id and meta.device_id_insolar is not null where ${filter_or_path} $$,'Pentaho History');