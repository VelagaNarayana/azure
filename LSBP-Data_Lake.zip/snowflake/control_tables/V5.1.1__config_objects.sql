use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';


CREATE OR REPLACE TABLE CONTROL.CONTROL_PARAMETERS
(
    PARAM_KEY	INTEGER IDENTITY PRIMARY KEY,
    PARAM_NAME	VARCHAR (1000) NOT NULL,
    PARAM_TYPE	VARCHAR (1000),
    UPDATED_TS	TIMESTAMP NOT NULL,
    UPDATED_BY	VARCHAR (1000) NOT NULL
)DATA_RETENTION_TIME_IN_DAYS = 31
COMMENT = "Configuration table for parameters" ;


CREATE OR REPLACE FILE FORMAT CONTROL.FF_CSV_TRACKER_PYRO_CONFIG 
        TYPE = 'CSV' COMPRESSION = 'AUTO' 
        FIELD_DELIMITER = ',' 
        RECORD_DELIMITER = '\n' 
        SKIP_HEADER = 1 
        FIELD_OPTIONALLY_ENCLOSED_BY = 'NONE' 
        TRIM_SPACE = TRUE 
        ERROR_ON_COLUMN_COUNT_MISMATCH = TRUE 
        ESCAPE = '\134' 
        ESCAPE_UNENCLOSED_FIELD = '\134' 
        DATE_FORMAT = 'AUTO' 
        TIMESTAMP_FORMAT = 'AUTO' 
        NULL_IF = ('\\N') 
        COMMENT = 'File Format to read pyranometer site configurations ';        
                
CREATE OR REPLACE  STAGE  "CONTROL".STG_TRACKER_PYRO_CONFIG 
	URL = 'azure://lsbpdata{{ blobsuffix }}.blob.core.windows.net/adhoc-data-sources/configuration/' 
	STORAGE_INTEGRATION = sint_lsbpdata_lz_{{ integration }}
	FILE_FORMAT = "CONTROL".FF_CSV_TRACKER_PYRO_CONFIG 
	COMMENT = 'Stage to read pyronameter config files';


CREATE OR REPLACE TABLE CONTROL.SITE_CONFIG
(
    CONFIG_KEY	INTEGER IDENTITY , 
    SITE_FKEY	INTEGER,
    SITE_ID	VARCHAR(255),
    CONTROL_PARAMETER_FKEY	INTEGER  references CONTROL.CONTROL_PARAMETERS (PARAM_KEY),
    CONTROL_PARAMETER_VALUE	VARCHAR,
    STATUS	VARCHAR(50) NOT NULL,
    ACTIVE_FROM	DATE,
    ACTIVE_TO	DATE,
    UPDATED_TS	TIMESTAMP DEFAULT sysdate() , 
    UPDATED_BY	VARCHAR (1000)
)DATA_RETENTION_TIME_IN_DAYS = 31
comment = "Configuration table for sites parameter" ;


CREATE or replace VIEW CONTROL.VW_SITE_ACTIVE_CONFIG
AS
SELECT 
	site_config.site_fkey as site_key,
    site_config.site_id as site_id,
	param.param_name as parameter_name,
	param.param_type as parameter_type,
	site_config.control_parameter_value as parameter_value,
	STATUS,
	active_from,
	active_to 
FROM 
	"CONTROL"."SITE_CONFIG" site_config INNER JOIN "CONTROL"."CONTROL_PARAMETERS" param 
ON site_config.control_parameter_fkey = param.param_key
WHERE STATUS IN ('DEFAULT','OVERRIDE');

CREATE OR REPLACE FUNCTION CONTROL.FN_SITE_ACTIVE_CONFIG(FROM_DT DATE, TO_DT DATE)
RETURNS TABLE (SITE_KEY INTEGER, SITE_ID VARCHAR,PARAMETER_DATE DATE, PARAMETER_NAME VARCHAR, PARAMETER_TYPE VARCHAR, PARAMETER_VALUE VARCHAR, ACTIVE_FROM DATE, ACTIVE_TO DATE, STATUS VARCHAR)
 AS
 $$
 SELECT SITE_KEY,SITE_ID,PARAMETER_DATE,PARAMETER_NAME,PARAMETER_TYPE,PARAMETER_VALUE,ACTIVE_FROM,ACTIVE_TO,STATUS FROM
      (
          SELECT dt.date as PARAMETER_DATE,
          config.*,
          NVL(config.active_to,to_date(SYSDATE())) as todate_tocompare,
          CASE WHEN (status = 'DEFAULT') OR (status = 'OVERRIDE' AND dt.date BETWEEN config.active_from and todate_tocompare) THEN TRUE ELSE FALSE END AS VALID_PARAMETER,           
          row_number() over (PARTITION BY  site_key,parameter_name,parameter_type,dt.date ORDER BY status desc) as row_number          
          FROM "CURATED"."DIM_CALENDAR_DATE" dt
          CROSS JOIN  "CONTROL"."VW_SITE_ACTIVE_CONFIG" config       
          WHERE date between FROM_DT and TO_DT
          AND VALID_PARAMETER = TRUE  
      )config WHERE row_number = 1        
$$;


CREATE OR REPLACE FUNCTION CONTROL.FN_ACTIVE_DEVICE_GROUPS(FROM_DT DATE, TO_DT DATE)
RETURNS TABLE (SITE_KEY INTEGER,SITE_ID VARCHAR, PARAMETER_DATE DATE, DEVICE_GROUP_NAME VARCHAR, DEVICE_GROUP_PARAMETER_NAME VARCHAR,DEVICE_GROUP_PARAMETER_VALUE VARCHAR)
AS
$$        
		SELECT grp_name.site_key as SITE_KEY,
			   grp_name.site_id as SITE_ID,
			   grp_name.parameter_date as PARAMETER_DATE, 
			   grp_name.parameter_value as DEVICE_GROUP_NAME,
			   grp_param.parameter_name as DEVICE_GROUP_PARAMETER_NAME,
			   grp_param.parameter_value as DEVICE_GROUP_PARAMETER_VALUE FROM         
		(        
		SELECT *,regexp_replace(parameter_name,'[^[:digit:]]') as group_number FROM table( CONTROL.FN_SITE_ACTIVE_CONFIG( FROM_DT, TO_DT) )   
		where parameter_name ilike '%Device Group%' and parameter_name ilike '%name%'
		) grp_name 
		inner join  
		(        
		SELECT *,regexp_replace(parameter_name,'[^[:digit:]]') as group_number FROM table( CONTROL.FN_SITE_ACTIVE_CONFIG( FROM_DT, TO_DT ) )   
		where parameter_name ilike '%Device Group%' and (parameter_name ilike '%irradiance%' or parameter_name ilike '%satellite%' or parameter_name ilike '%multiplier%')
		) grp_param
		 on grp_name.site_key = grp_param.site_key and grp_name.parameter_date = grp_param.parameter_date and grp_name.group_number = grp_param.group_number 
$$;


CREATE OR REPLACE FUNCTION CONTROL.FN_SITE_ACTIVE_PYRO_MAPPING(FROM_DT DATE, TO_DT DATE)
RETURNS TABLE (SITE_FKEY INTEGER,SITE_ID VARCHAR, PARAMETER_DATE DATE,IRRADIANCE_MEASUREMENT_FKEY INTEGER, IRRADIANCE_MEASUREMENT_ID VARCHAR,TARGET_ROLL_MEASUREMENT_FKEY INTEGER, TARGET_ROLL_MEASUREMENT_ID VARCHAR,TARGET_POSITION_ANGLE_MEASUREMENT_FKEY INTEGER,TARGET_POSITION_ANGLE_MEASUREMENT_ID VARCHAR)
AS
$$        
		SELECT 
				config_file.site_key,
				config_file.site_id,
				config_file.parameter_date,
				irradiance.measurement_key as irradiance_measurement_fkey,
				config_data.irradiance_measurement_id, 
				target_role.measurement_key as target_roll_measurement_fkey,        
				config_data.target_roll_measurement_id,
				target_position.measurement_key as target_position_angle_measurement_fkey,
				config_data.target_position_angle_measurement_id
		FROM table( CONTROL.FN_SITE_ACTIVE_CONFIG( FROM_DT,TO_DT ) )  config_file
		left join         
		(select $1 as site_id,$2 as irradiance_measurement_id,$3 as target_roll_measurement_id, $4 as target_position_angle_measurement_id, metadata$filename as config_filename from @"CONTROL".STG_TRACKER_PYRO_CONFIG) config_data
		on  config_file.parameter_value = config_data.config_filename and config_file.site_id =    config_data.site_id
		left join curated.dim_measurements irradiance
		on config_data.irradiance_measurement_id = irradiance.measurement_id        
		left join curated.dim_measurements target_role
		on config_data.target_roll_measurement_id = target_role.measurement_id        
		left join curated.dim_measurements target_position
		on config_data.target_position_angle_measurement_id = target_position.measurement_id                
		where  parameter_name = 'Tracker Pyro Mapping File'                 
$$;        

TRUNCATE TABLE CONTROL.CONTROL_PARAMETERS;

INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Irradiance','Measurement(s)',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Consecutive Values to Reject','Value',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Maximum Gap to Interpolate','Value',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Sunrise Buffer','Value',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Sunset Buffer','Value',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Irradiance Maximum','Value',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Irradiance Minimum','Value',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Maximum Tracker Deviation','Value',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 1 - name','Value',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 1 - irradiance','Measurement(s)',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 1 - satellite','Measurement(s)',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 1 - multiplier','Value',sysdate(),'DevOps');                
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 2 - name','Value',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 2 - irradiance','Measurement(s)',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 2 - satellite','Measurement(s)',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 2 - multiplier','Value',sysdate(),'DevOps');        
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 3 - name','Value',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 3 - irradiance','Measurement(s)',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 3 - satellite','Measurement(s)',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 3 - multiplier','Value',sysdate(),'DevOps');        
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 4 - name','Value',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 4 - irradiance','Measurement(s)',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 4 - satellite','Measurement(s)',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 4 - multiplier','Value',sysdate(),'DevOps'); 
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 5 - name','Value',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 5 - irradiance','Measurement(s)',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 5 - satellite','Measurement(s)',sysdate(),'DevOps');
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Device group 5 - multiplier','Value',sysdate(),'DevOps');               
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Tracker Pyro Mapping File','Value',sysdate(),'DevOps');        
INSERT INTO CONTROL.CONTROL_PARAMETERS (PARAM_NAME,PARAM_TYPE,UPDATED_TS,UPDATED_BY) VALUES('Satellite','Measurement(s)',sysdate(),'DevOps');


DROP TABLE IF EXISTS CONTROL.MAPPING_TRACKER_PYRO;        
DROP TABLE IF EXISTS CONTROL.DEVICE_GROUPS;
DROP VIEW IF EXISTS  CONTROL.VW_DEVICE_ACTIVE_GROUPS;        