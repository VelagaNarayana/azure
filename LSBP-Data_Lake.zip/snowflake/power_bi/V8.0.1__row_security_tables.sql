use role dl_{{ role }}_data_engineers;
use warehouse DATA_LOAD_{{ wh }}_WH;

create or replace view raw.vw_rls_fact_production_meter as
select 
   SITE_KEY,METER_KEY,DATE_KEY,TIME_KEY,PDATE,PTIME,
   PRODUCTION_VALUE,ORIGINAL_METER_ID,ORIGINAL_DATE_TIME,
   DATA_SOURCE,CREATED_TS,UPDATED_TS,PROCESS_EXEC_ID,LOAD_FILE,
   LOCAL_DATE_KEY,LOCAL_TIME_KEY,LOCAL_DATE,LOCAL_TIME,
   (case when status IN ('DEFAULT','OVERRIDE') then PRODUCTION_VALUE END) AS PRODUCTION_VALUE_ACTIVE_METERS
from raw.fact_production_meter;
