use database data_lake_{{ db }};
use warehouse REPORTING_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace view curated.vw_dim_calendar_date as
select cal.*, 
concat(left(month_name,3),'-',year) as month_mmm_yyyy, to_varchar(date,'YYYYMM') as sort_yyyymm, 
date_trunc('MONTH', add_months(date,-1)) as previous_month_start,
dateadd(day,-1,add_months(previous_month_start,1)) as previous_month_end
from curated.dim_calendar_date cal;