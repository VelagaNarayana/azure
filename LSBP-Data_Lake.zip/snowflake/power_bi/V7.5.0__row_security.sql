-- ------------------------------------------------------------
-- Create security schema
-- ------------------------------------------------------------	

use role dl_{{ role }}_admin;
create or replace schema data_lake_{{ db }}.security with managed access;

-- ------------------------------------------------------------
-- Create Access Roles 
-- ------------------------------------------------------------	
-- Schema roles --

use role securityadmin;

create or replace role SF_ACR_{{ role }}_SECURITY_R;
create or replace role SF_ACR_{{ role }}_SECURITY_RW;
create or replace role SF_ACR_{{ role }}_SECURITY_FULL;

-- ------------------------------------------------------------
-- Grant permissions on DEV database schema to Access roles 
-- ------------------------------------------------------------ 


-- SECURITY schema Full access --

grant ownership on schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant all on schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant ownership on all tables in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant ownership on all views  in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant ownership on all stages in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant ownership on all file formats in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant ownership on all streams in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant ownership on all procedures in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant ownership on all functions in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant ownership on all sequences in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant ownership on all tasks in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;

-- SECURITY schema Full (Future grant) access --

grant ownership on future tables in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant ownership on future views  in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant ownership on future stages in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant ownership on future file formats in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant ownership on future streams in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant ownership on future procedures in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant ownership on future functions in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant ownership on future sequences in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;
grant ownership on future tasks in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_FULL;


-- SECURITY schema read only access --

grant usage on schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;
grant select on all tables in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;
grant select on all external tables in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;
grant select on all views in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;
grant select on all MATERIALIZED views in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;
grant usage, read on all stages in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;
grant usage on all file formats in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;
grant select on all streams in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;
grant usage on all functions in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;
grant usage on all procedures in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;

-- SECURITY schema read only (Future grant) access --

grant select on future tables in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;
grant select on future external tables in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;
grant select on future views in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;
grant select on future MATERIALIZED views in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;
grant usage, read on future stages in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;
grant usage on future file formats in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;
grant select on future streams in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;
grant usage on future functions in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;
grant usage on future procedures in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_R;

-- SECURITY schema read write access --

grant MODIFY , MONITOR , USAGE on schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;
grant select, insert, update, delete, references on all tables in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;
grant select on all views in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;
grant usage, read, write on all stages in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;
grant usage on all file formats in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;
grant select on all streams in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;
grant usage on all procedures in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;
grant usage on all functions in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;
grant usage on all sequences in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;
grant monitor, operate on all tasks in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;

-- SECURITY schema read write (Future grant) access --

grant select, insert, update, delete, references on future tables in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;
grant select on future views in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;
grant usage, read, write on future stages in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;
grant usage on future file formats in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;
grant select on future streams in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;
grant usage on future procedures in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;
grant usage on future functions in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;
grant usage on future sequences in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;
grant monitor, operate on future tasks in schema data_lake_{{ db }}.SECURITY to role SF_ACR_{{ role }}_SECURITY_RW;



grant role SF_ACR_{{ role }}_SECURITY_R to role dl_{{ role }}_data_engineers;
grant role SF_ACR_{{ role }}_SECURITY_FULL to role dl_{{ role }}_admin;


use role dl_{{ role }}_admin;
use schema data_lake_{{ db }}.security;
create table security.row_access_sites (site_key integer, site_name varchar(500), role varchar(500));


create or replace row access policy security.sites_policy as (dim_site_key integer) returns boolean ->
current_role() ilike 'dl%' -- by default allow access to dl_*_engineers, analysts, admin etc.
or exists (
select 1 from row_access_sites -- restrictive for business user roles
where role=current_role()
and site_key = dim_site_key
);

insert into security.row_access_sites(site_key,site_name,role)
 select
 site_key,site as site_name,case when team='ASSET_MGMT' then 'POWER_BI_ASSET_MANAGEMENT'
      when team='O_M' then 'POWER_BI_OPERATIONS_AND_MAINTENANCE'
      when team='GP_M' then 'POWER_BI_GLOBAL_PERFORMANCE_AND_MONITORING'
   end as role
 from control.power_bi_data_security_site
 where role is not null and access='Y';

grant apply on row access policy security.sites_policy to role dl_{{ role }}_data_engineers;


