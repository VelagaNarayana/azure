use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';


CREATE OR REPLACE VIEW CONTROL.VW_ACTIVE_PRODUCTION_DATA_METERS
AS
(
    SELECT d.date_key
    ,   sc.site_key
    ,   md.meter_key
    ,   d.date_key||sc.site_key||md.meter_key AS date_site_meter_key_utc
    ,   sc.parameter_date
    ,   sc.parameter_name
    ,   sc.parameter_value
    ,   sc.value
    ,   sc.status
    FROM
    (
        SELECT site_key,parameter_date,parameter_name,parameter_value, split.value,status, seq, index
        FROM
        (
            SELECT  site_key
                ,   parameter_date
                ,   parameter_name
                ,   parameter_value
                ,   status 
            FROM    table( CONTROL.FN_SITE_ACTIVE_CONFIG(TO_DATE('2010-01-01'),TO_DATE('2099-12-31')) )) config,
                    lateral split_to_table(config.parameter_value, ',') split
            WHERE   parameter_name='Production Data Meters'
        ) sc
    INNER JOIN curated.dim_prod_meter_details md ON sc.value=md.meter_id
    INNER JOIN curated.dim_calendar_date d ON sc.parameter_date=d.date
);