use database data_lake_{{ db }};
use warehouse REPORTING_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace view curated.vw_dim_sites as
select sites.*, case when site_key>0 then to_date(convert_timezone('UTC',derived_timezone,current_date())) end as local_today,
       case when month(full_o_m_reporting_start_date) > month(local_today) 
                or ( month(full_o_m_reporting_start_date) = month(local_today) and day(full_o_m_reporting_start_date) > day(local_today))
              then date_from_parts(year(local_today)-1,month(full_o_m_reporting_start_date),day(full_o_m_reporting_start_date))
          else
             date_from_parts(year(local_today),month(full_o_m_reporting_start_date),day(full_o_m_reporting_start_date))
        end as current_reporting_period_start_date,
        dateadd(day,-1,dateadd(year,1,current_reporting_period_start_date)) as current_reporting_period_end_date,
        dateadd(year,-1,current_reporting_period_start_date) as previous_reporting_period_start_date,
         dateadd(day,-1,dateadd(year,1,previous_reporting_period_start_date)) as previous_reporting_period_end_date
from curated.dim_sites sites;