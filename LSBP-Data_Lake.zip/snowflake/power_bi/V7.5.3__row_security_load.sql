use database data_lake_{{ db }};
use role dl_{{ role }}_admin;
use warehouse DATA_LOAD_{{ wh }}_WH;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace temporary table common.power_bi_security_tmp
(
    site varchar(255),
    code varchar(255),
    portfolio varchar(255),
    capacity float,
    country varchar(50),
    status varchar(255),
    owner varchar(255),
    active_operator varchar(255),
    active_asset_manager varchar(255),
    asset_mgmt varchar(10),
    o_m varchar(10),
    data_mgmt varchar(10),
    asset_svcs varchar(10),
    gp_m varchar(10)
);

PUT file:///home/vsts/work/1/s/snowflake/power_bi/power_bi_site_security.csv @common.%power_bi_security_tmp;

COPY INTO common.power_bi_security_tmp
file_format  = (TYPE = 'CSV' COMPRESSION = 'AUTO' FIELD_DELIMITER = ',' RECORD_DELIMITER = '\n' 
                SKIP_HEADER = 1 FIELD_OPTIONALLY_ENCLOSED_BY = '\042' TRIM_SPACE = FALSE ERROR_ON_COLUMN_COUNT_MISMATCH = TRUE 
                ESCAPE = 'NONE' ESCAPE_UNENCLOSED_FIELD = '\134' DATE_FORMAT = 'AUTO' TIMESTAMP_FORMAT = 'AUTO' NULL_IF = ('\\N'));

delete from security.row_access_sites;

insert into security.row_access_sites(site_key,site_name,role)
 select
 distinct site_key,site as site_name,case when team='ASSET_MGMT' then 'POWER_BI_ASSET_MANAGEMENT'
      when team='O_M' then 'POWER_BI_OPERATIONS_AND_MAINTENANCE'
      when team='GP_M' then 'POWER_BI_GLOBAL_PERFORMANCE_AND_MONITORING'
   end as role
from 
(select sites.site_key, 
        sec.*
from (select *  from common.power_bi_security_tmp 
        unpivot (access for team in (asset_mgmt, o_m,data_mgmt, asset_svcs, gp_m))
    ) sec 
    left join curated.dim_sites sites
     on sec.code = sites.site_reference_formula or sec.site=sites.site_name_formula
      or contains(sites.site_name, sec.site)) tmp
 where role is not null and access='Y'
 union
select site_key,site_name,role from curated.dim_sites join (select 'POWER_BI_DATA_AND_ANALYTICS' as role) 
union
select  site_key,site_name,role from curated.dim_sites join (select 'POWER_BI_OPERATIONS_AND_MAINTENANCE' as role
                                                            union 
                                                            select 'POWER_BI_GLOBAL_PERFORMANCE_AND_MONITORING' as role
                                                            union
                                                            select 'POWER_BI_ASSET_MANAGEMENT' as role) on site_key<1;
