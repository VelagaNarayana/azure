use role dl_{{ role }}_data_engineers;
use warehouse DATA_LOAD_{{ wh }}_WH;

create or replace view raw.vw_rls_fact_production_meter as
select * from raw.fact_production_meter;

create or replace view raw.vw_rls_fact_site_measurements as 
select * from raw.fact_site_measurements;

create or replace view raw.vw_rls_fact_satellite_measurements as 
select * from RAW.FACT_SATELLITE_MEASUREMENTS;

create or replace view curated.vw_rls_irradiance_cleansed_interpolated as 
select * from CURATED.IRRADIANCE_CLEANSED_INTERPOLATED;



alter table CURATED.DIM_BUDGETS add row access policy security.sites_policy on (SITE_KEY);
alter table CURATED.DIM_INCIDENTS add row access policy security.sites_policy on (SITE_FKEY);
alter table CURATED.FACT_DEVICE_AVAILABILITY add row access policy security.sites_policy on (site_key);
alter table CURATED.FACT_SITE_AVAILABILITY add row access policy security.sites_policy on (site_key);
alter table CURATED.DIM_DEVICES add row access policy security.sites_policy on (SITE_FKEY);
alter table CURATED.DIM_PROD_METER_DETAILS add row access policy security.sites_policy on (SITE_FKEY);
alter table CURATED.DIM_SITES add row access policy security.sites_policy on (site_key);
alter table CURATED.MVW_AGG_FACT_IRRADIANCE_BACKFILLED_DATE_SITE add row access policy security.sites_policy on (site_key);
alter table CURATED.MVW_AGG_FACT_IRRADIANCE_CLEANSED_INTERPOLATED_DATE_MEASUREMENT add row access policy security.sites_policy on (site_key);

alter table RAW.FACT_BUDGETS add row access policy security.sites_policy on (SITE_KEY);
alter table RAW.FACT_HS_INCIDENT_DETAILS add row access policy security.sites_policy on (SITE_KEY);
alter table RAW.FACT_O_M_MONTHLY_REPORTING_COMMENTS add row access policy security.sites_policy on (SITE_KEY);
alter table RAW.MVW_AGG_FACT_PRODUCTION_DATA_DATE_SITE_METER add row access policy security.sites_policy on (SITE_KEY);
alter table RAW.MVW_AGG_FACT_SATELLITE_MEASUREMENTS_SITE_DATE_MEASUREMENT add row access policy security.sites_policy on (SITE_KEY);
alter table RAW.FACT_SV_SCHEDULED_SERVICES add row access policy security.sites_policy on (SITE_FKEY);
alter table RAW.FACT_SV_SERVICE_ORDERS_JOBS add row access policy security.sites_policy on (SITE_FKEY);

alter table CONTROL.SITE_CONFIG add row access policy security.sites_policy on (SITE_FKEY);

alter table REFERENCE.SUNRISE_SUNSET_DETAILS add row access policy security.sites_policy on (SITE_FKEY);

alter table raw.vw_rls_fact_production_meter add row access policy security.sites_policy on (site_key);
alter table raw.vw_rls_fact_site_measurements add row access policy security.sites_policy on (site_key);
alter table raw.vw_rls_fact_satellite_measurements add row access policy security.sites_policy on (site_key);
alter table curated.vw_irradiance_backfilled add row access policy security.sites_policy on (site_key);
alter table curated.vw_rls_irradiance_cleansed_interpolated add row access policy security.sites_policy on (site_key);