use database data_lake_{{ db }};
use warehouse REPORTING_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace view curated.vw_irradiance_backfilled as
select *, COMMON.RESOLVE_RECORD_SOURCE(record_quality) as record_source
from curated.irradiance_backfilled;