use database data_lake_{{ db }};
use warehouse REPORTING_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';


create or replace view curated.vw_dim_devices as 
with recursive device_heirarchy  
    (device_name, device_id,parent,path,device_names,level ) as
    (
         select device_name, device_id, parent, device_name as path, split(device_name,'->') as device_names, 1 as level from curated.dim_devices where (device_apcode='Site' and parent is null) or device_apcode='Cluster'
         union all
         select   child.device_name, child.device_id, child.parent,concat(path,'->',child.device_name) as path, split(concat(path,'->',child.device_name),'->') as device_names, level+1 as level  from curated.dim_devices child
         join device_heirarchy parent on child.parent = parent.device_id 
    )
select
  device_key,site_fkey,devices.device_id,device_apcode,devices.device_name,device_model,device_serial_number,device_type,manufacturer,
  devices.parent,device_names[0]::string as level1,device_names[1]::string as level2,device_names[2]::string as level3,device_names[3]::string as level4,
  device_names[4]::string as level5,device_names[5]::string as level6,device_names[6]::string as level7,device_names[7]::string as level8,
  device_names[8]::string as level9,device_names[9]::string as level10,device_names[10]::string as level11,level,
  data_source, created_ts, updated_ts, process_exec_id,load_file
from curated.dim_devices devices left join device_heirarchy hrchy on devices.device_id = hrchy.device_id