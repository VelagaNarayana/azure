use database data_lake_{{ db }};
use warehouse DATA_TRANSFORM_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';


CREATE OR REPLACE VIEW RAW.VW_FACT_PRODUCTION_METER ( site_key, meter_key, date_key, time_key, date_site_meter_key_utc, local_date_key, local_time_key, date_site_meter_key_local, pdate, ptime, production_value, original_meter_id, original_date_time, data_source
                                                 , created_ts, updated_ts, process_exec_id, load_file )
AS
(
    SELECT  site_key
        ,   meter_key
        ,   date_key
        ,   time_key
        ,   date_key||site_key||meter_key AS date_site_meter_key_utc
        ,   local_date_key
        ,   local_time_key
        ,   local_date_key||site_key||meter_key AS date_site_meter_key_local
        ,   pdate
        ,   ptime
        ,   production_value
        ,   original_meter_id
        ,   original_date_time
        ,   data_source
        ,   created_ts
        ,   updated_ts
        ,   process_exec_id
        ,   load_file
    FROM    raw.fact_production_meter
);