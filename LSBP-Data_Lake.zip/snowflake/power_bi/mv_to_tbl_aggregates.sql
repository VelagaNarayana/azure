use database data_lake_{{ db }};
use warehouse REPORTING_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';


CREATE OR REPLACE TABLE CURATED.AGG_FACT_PRODUCTION_DATA_DATE_SITE_METER (
SITE_KEY NUMBER(38,0) comment '^GRP_KEY SITE_KEY',
METER_KEY NUMBER(38,0) comment '^GRP_KEY METER_KEY',
DATE_KEY_UTC NUMBER(38,0) comment '^GRP_KEY DATE_KEY',
DATE_KEY_LOCAL NUMBER(38,0) comment '^GRP_KEY LOCAL_DATE_KEY',
PRODUCTION_VALUE_ACTIVE_METERS FLOAT comment 'sum(case when status IN (\'DEFAULT\',\'OVERRIDE\') then PRODUCTION_VALUE END)',
PRODUCTION_VALUE_ALL_METERS FLOAT comment 'sum(PRODUCTION_VALUE)',
PROCESS_EXEC_ID varchar(100),
updated_ts datetime 
)comment = 'RAW.FACT_PRODUCTION_METER';



CREATE OR REPLACE TABLE CURATED.AGG_FACT_SITE_MEASUREMENTS_DATE_MEASUREMENT(
DATE_KEY_UTC NUMBER(38,0) comment '^GRP_KEY DATE_KEY',
DATE_KEY_LOCAL NUMBER(38,0) comment '^GRP_KEY LOCAL_DATE_KEY',
MEASUREMENT_KEY NUMBER(38,0) comment '^GRP_KEY MEASUREMENT_KEY',
MEASUREMENT_VALUE_NUMERIC FLOAT comment 'SUM(MEASUREMENT_VALUE_NUMERIC)',
PROCESS_EXEC_ID varchar(100),
updated_ts datetime 
)comment = 'RAW.FACT_SITE_MEASUREMENTS';

CREATE OR REPLACE TABLE CURATED.AGG_FACT_SATELLITE_MEASUREMENTS_SITE_DATE_MEASUREMENT(
SITE_KEY NUMBER(38,0) comment '^GRP_KEY SITE_KEY',
DATE_KEY_UTC NUMBER(38,0) comment '^GRP_KEY DATE_KEY',
DATE_KEY_LOCAL NUMBER(38,0) comment '^GRP_KEY LOCAL_DATE_KEY',
MEASURE_KEY NUMBER(38,0) comment '^GRP_KEY MEASURE_KEY',
SATELLITE_VALUE FLOAT comment 'SUM(SATELLITE_VALUE)',
PROCESS_EXEC_ID varchar(100),
updated_ts datetime 
)comment = 'RAW.FACT_SATELLITE_MEASUREMENTS';


CREATE OR REPLACE TABLE CURATED.AGG_FACT_IRRADIANCE_BACKFILLED_DATE_SITE (
SITE_KEY NUMBER(38,0) comment '^GRP_KEY SITE_KEY',
DATE_KEY_UTC NUMBER(38,0) comment '^GRP_KEY DATE_KEY',
DATE_KEY_LOCAL NUMBER(38,0) comment '^GRP_KEY LOCAL_DATE_KEY',
RECORD_QUALITY VARCHAR(30) comment '^GRP_KEY RECORD_QUALITY',
DEVICE_GROUP BOOLEAN comment '^GRP_KEY DEVICE_GROUP',
DEVICE_GROUP_DETAILS VARCHAR(1000) comment '^GRP_KEY DEVICE_GROUP_DETAILS',
RECORD_SOURCE VARCHAR(23) comment '^GRP_KEY COMMON.RESOLVE_RECORD_SOURCE(record_quality)',
IRRADIANCE_SATELLITE_VALUE FLOAT comment 'SUM(IRRADIANCE_SATELLITE_VALUE)',
IRRADIANCE_VALUE FLOAT comment 'SUM(IRRADIANCE_VALUE)',
PROCESS_EXEC_ID varchar(100),
updated_ts datetime 
)comment = 'CURATED.IRRADIANCE_BACKFILLED';

CREATE OR REPLACE TABLE CURATED.AGG_FACT_IRRADIANCE_CLEANSED_INTERPOLATED_DATE_MEASUREMENT (   
SITE_KEY NUMBER(38,0) comment '^GRP_KEY SITE_KEY',
DATE_KEY_UTC NUMBER(38,0) comment '^GRP_KEY DATE_KEY',
DATE_KEY_LOCAL NUMBER(38,0) comment '^GRP_KEY LOCAL_DATE_KEY',
MEASUREMENT_KEY NUMBER(38,0) comment '^GRP_KEY MEASUREMENT_KEY',
IRRADIANCE_RAW_VALUE FLOAT comment 'SUM(IRRADIANCE_RAW_VALUE)',
IRRADIANCE_CLEANSED_VALUE FLOAT comment 'SUM(IRRADIANCE_CLEANSED_VALUE)',
IRRADIANCE_INTERPOLATED_VALUE FLOAT comment 'SUM(IRRADIANCE_INTERPOLATED_VALUE)',
IRRADIANCE_FINAL_VALUE FLOAT comment 'SUM(IRRADIANCE_FINAL_VALUE)',
PROCESS_EXEC_ID varchar(100),
updated_ts datetime 
)comment = 'CURATED.IRRADIANCE_CLEANSED_INTERPOLATED';


-- SP to populate/refresh aggregate tables.
CREATE OR REPLACE PROCEDURE "CURATED"."PROC_LOAD_AGG_FACT_DATA"(TARGET_SCHEMA VARCHAR, TARGET_TBL VARCHAR, BASE_TBL_FILTER VARCHAR, PIPELINE_RUN_ID VARCHAR, PIPELINE_NAME VARCHAR)
    RETURNS string
    LANGUAGE javascript
    strict
    EXECUTE AS CALLER 
    AS
    $$             
        
		var cols_command = "select listagg(column_name,',') WITHIN GROUP ( order by ordinal_position ),listagg(iff(startswith(comment,'^GRP_KEY '),concat(substr(comment,10),' as ',column_name),concat(comment,' as ',column_name)),', ') WITHIN GROUP ( order by ordinal_position ),  replace(listagg(iff(startswith(comment,'^GRP_KEY '),substr(comment,10),','),', ') WITHIN GROUP ( order by ordinal_position ),', ,',''),replace(listagg(iff(startswith(comment,'^GRP_KEY '),concat('tmp.',column_name,' = ','agg.',column_name),' and '),' and ') WITHIN GROUP ( order by ordinal_position ) ,'and  and','')  from INFORMATION_SCHEMA.COLUMNS where table_schema='"+TARGET_SCHEMA+"' and table_name='"+TARGET_TBL+"' and comment is not null;"
        
		
		var sql_command = {sqlText: cols_command};
		
        var stmt = snowflake.createStatement(sql_command);
        var res = stmt.execute();
        res.next();
        var TARGET_COLS = res.getColumnValue(1)+",PROCESS_EXEC_ID,UPDATED_TS";
        var PARSE_COLS = res.getColumnValue(2)+",'"+PIPELINE_RUN_ID+"' AS PROCESS_EXEC_ID, SYSDATE() AS UPDATED_TS";
		var GROUP_BY_KEYS = res.getColumnValue(3);
		var DELETE_COLS = res.getColumnValue(4);
		
        var TEMP_TABLE = "common.\"TMP_CUR_AGG_FACT_"+PIPELINE_RUN_ID+"\"";
        
		var tbl_command = "select comment from INFORMATION_SCHEMA.TABLES where table_schema='"+TARGET_SCHEMA+"' and table_name='"+TARGET_TBL+"';"
		sql_command = {sqlText: tbl_command};
		
        var stmt = snowflake.createStatement(sql_command);
        var res = stmt.execute();
        res.next();
        var SRC_TBL = res.getColumnValue(1);
		
        snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = '"+PIPELINE_NAME+"~"+PIPELINE_RUN_ID+"';"} ) 
        snowflake.execute( {sqlText: "BEGIN WORK;"} ); 
        var numRecInserted = 0;
        try{        
        
           var tempTableQuery = "create or replace temporary table "+TEMP_TABLE+" as select "+PARSE_COLS+" from "+SRC_TBL+" ";
		   if(BASE_TBL_FILTER){
				tempTableQuery+=" where "+BASE_TBL_FILTER+" "
		   }
		   
		   if(GROUP_BY_KEYS){
				tempTableQuery+=" group by "+GROUP_BY_KEYS+" "
		   }
		   
		   tempTableQuery+=" ;";
           snowflake.execute( {sqlText:tempTableQuery} ); 
          
		   var delQuery= "DELETE FROM "+TARGET_SCHEMA+"."+TARGET_TBL+" agg USING "+TEMP_TABLE+" tmp where "+DELETE_COLS+" ;"
          
           var delRs = snowflake.execute( {sqlText:delQuery} );
		   delRs.next();
		   numRecsDeleted = delRs.getColumnValue(1);  
		   
           var load_command = "insert into "+TARGET_SCHEMA+"."+TARGET_TBL+"("+TARGET_COLS+") select "+TARGET_COLS+" from "+TEMP_TABLE;
           var stmt = snowflake.createStatement({
               sqlText: load_command
           });  
          var rs = stmt.execute();
          rs.next();
          numRecInserted = rs.getColumnValue(1);         
          snowflake.execute( {sqlText: "COMMIT WORK;"} );
          
		           
        }
        catch(err){
            snowflake.execute( {sqlText: "ROLLBACK WORK;"} );
            throw err;
        }
        finally{
            snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
        }
                
         return JSON.stringify({ "Rows deleted":numRecsDeleted, "Rows inserted":numRecInserted });
   
    $$;