/* Creating Database and schema */
use role sysadmin;

CREATE DATABASE IF NOT EXISTS data_lake_{{ env }};
CREATE SCHEMA IF NOT EXISTS data_lake_{{ env }}.raw;
CREATE SCHEMA IF NOT EXISTS data_lake_{{ env }}.curated;
CREATE SCHEMA IF NOT EXISTS data_lake_{{ env }}.control;
CREATE SCHEMA IF NOT EXISTS data_lake_{{ env }}.reference;
CREATE SCHEMA IF NOT EXISTS data_lake_{{ env }}.common;

/* End */

/* Creating WH */
use role sysadmin;

CREATE WAREHOUSE IF NOT EXISTS DATA_LOAD_{{ env }}_WH WITH WAREHOUSE_SIZE = 'XSMALL' AUTO_SUSPEND = 60 AUTO_RESUME = TRUE MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 3 SCALING_POLICY = 'STANDARD' COMMENT = 'Virtual Warehouse for loading data';

CREATE WAREHOUSE IF NOT EXISTS DATA_TRANSFORM_{{ env }}_WH WITH WAREHOUSE_SIZE = 'XSMALL' AUTO_SUSPEND = 60 AUTO_RESUME = TRUE MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 3 SCALING_POLICY = 'STANDARD' COMMENT = 'Virtual Warehouse for transforming data';

CREATE WAREHOUSE IF NOT EXISTS REPORTING_{{ env }}_WH WITH WAREHOUSE_SIZE = 'XSMALL' AUTO_SUSPEND = 60 AUTO_RESUME = TRUE MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 3 SCALING_POLICY = 'STANDARD' COMMENT = 'Virtual Warehouse for reporting data';

CREATE WAREHOUSE IF NOT EXISTS ANALYTICS_{{ env }}_WH WITH WAREHOUSE_SIZE = 'XSMALL' AUTO_SUSPEND = 60 AUTO_RESUME = TRUE MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 3 SCALING_POLICY = 'STANDARD' COMMENT = 'Virtual Warehouse for data analytics ';
/* End */

/* Assign permissions to data_engineers */

grant usage on database data_lake_{{ env }} to role dl_{{ env }}_data_engineers;
grant all on schema data_lake_{{ env }}.raw to role dl_{{ env }}_data_engineers;
grant all on schema data_lake_{{ env }}.control to role dl_{{ env }}_data_engineers;
grant all on schema data_lake_{{ env }}.curated to role dl_{{ env }}_data_engineers;
grant all on schema data_lake_{{ env }}.reference to role dl_{{ env }}_data_engineers;
grant all on schema data_lake_{{ env }}.common to role dl_{{ env }}_data_engineers;

/* End */


/* Assign permissions to data_analysts */

grant usage on database data_lake_{{ env }} to role dl_{{ env }}_data_analysts;
grant all on schema data_lake_{{ env }}.curated to role dl_{{ env }}_data_analysts;
grant usage on schema data_lake_{{ env }}.control to role dl_{{ env }}_data_analysts;
grant select on all tables in schema data_lake_{{ env }}.control to role dl_{{ env }}_data_analysts;
grant usage on schema data_lake_{{ env }}.control to role dl_{{ env }}_data_analysts;
grant usage on schema data_lake_{{ env }}.reference to role dl_{{ env }}_data_analysts;
grant usage on schema data_lake_{{ env }}.raw to role dl_{{ env }}_data_analysts;

grant all on all MATERIALIZED views in schema data_lake_{{ env }}.curated to role dl_{{ env }}_data_analysts;
grant all on future MATERIALIZED views in schema data_lake_{{ env }}.curated to role dl_{{ env }}_data_analysts;
grant all on all views in schema data_lake_{{ env }}.curated to role dl_{{ env }}_data_analysts;
grant all on future views in schema data_lake_{{ env }}.curated to role dl_{{ env }}_data_analysts;
grant all on all tables in schema data_lake_{{ env }}.curated to role dl_{{ env }}_data_analysts;
grant all on future tables in schema data_lake_{{ env }}.curated to role dl_{{ env }}_data_analysts;
grant all on all external tables in schema data_lake_{{ env }}.curated to role dl_{{ env }}_data_analysts;
grant all on future external tables in schema data_lake_{{ env }}.curated to role dl_{{ env }}_data_analysts;


grant all on all MATERIALIZED views in schema data_lake_{{ env }}.common to role dl_{{ env }}_data_analysts;
grant all on future MATERIALIZED views in schema data_lake_{{ env }}.common to role dl_{{ env }}_data_analysts;
grant all on all views in schema data_lake_{{ env }}.common to role dl_{{ env }}_data_analysts;
grant all on future views in schema data_lake_{{ env }}.common to role dl_{{ env }}_data_analysts;
grant all on all tables in schema data_lake_{{ env }}.common to role dl_{{ env }}_data_analysts;
grant all on future tables in schema data_lake_{{ env }}.common to role dl_{{ env }}_data_analysts;
grant all on all external tables in schema data_lake_{{ env }}.common to role dl_{{ env }}_data_analysts;
grant all on future external tables in schema data_lake_{{ env }}.common to role dl_{{ env }}_data_analysts;
grant all on all functions in schema data_lake_{{ env }}.common to role dl_{{ env }}_data_analysts;
grant all on future functions in schema data_lake_{{ env }}.common to role dl_{{ env }}_data_analysts;
grant all on all procedures in schema data_lake_{{ env }}.common to role dl_{{ env }}_data_analysts;
grant all on future procedures in schema data_lake_{{ env }}.common to role dl_{{ env }}_data_analysts;



grant select on all tables in schema data_lake_{{ env }}.raw to role dl_{{ env }}_data_analysts;
grant select on future tables in schema data_lake_{{ env }}.raw to role dl_{{ env }}_data_analysts;
grant select on all external tables in schema data_lake_{{ env }}.raw to role dl_{{ env }}_data_analysts;
grant select on future external tables in schema data_lake_{{ env }}.raw to role dl_{{ env }}_data_analysts;
grant select on all views in schema data_lake_{{ env }}.raw to role dl_{{ env }}_data_analysts;
grant select on future views in schema data_lake_{{ env }}.raw to role dl_{{ env }}_data_analysts;
grant select on all MATERIALIZED views in schema data_lake_{{ env }}.raw to role dl_{{ env }}_data_analysts;
grant select on future MATERIALIZED views in schema data_lake_{{ env }}.raw to role dl_{{ env }}_data_analysts;

grant select on all tables in schema data_lake_{{ env }}.control to role dl_{{ env }}_data_analysts;
grant select on future tables in schema data_lake_{{ env }}.control to role dl_{{ env }}_data_analysts;
grant select on all external tables in schema data_lake_{{ env }}.control to role dl_{{ env }}_data_analysts;
grant select on future external tables in schema data_lake_{{ env }}.control to role dl_{{ env }}_data_analysts;
grant select on all views in schema data_lake_{{ env }}.control to role dl_{{ env }}_data_analysts;
grant select on future views in schema data_lake_{{ env }}.control to role dl_{{ env }}_data_analysts;
grant select on all MATERIALIZED views in schema data_lake_{{ env }}.control to role dl_{{ env }}_data_analysts;
grant select on future MATERIALIZED views in schema data_lake_{{ env }}.control to role dl_{{ env }}_data_analysts;

grant select on all tables in schema data_lake_{{ env }}.reference to role dl_{{ env }}_data_analysts;
grant select on future tables in schema data_lake_{{ env }}.reference to role dl_{{ env }}_data_analysts;
grant select on all external tables in schema data_lake_{{ env }}.reference to role dl_{{ env }}_data_analysts;
grant select on future external tables in schema data_lake_{{ env }}.reference to role dl_{{ env }}_data_analysts;
grant select on all views in schema data_lake_{{ env }}.reference to role dl_{{ env }}_data_analysts;
grant select on future views in schema data_lake_{{ env }}.reference to role dl_{{ env }}_data_analysts;
grant select on all MATERIALIZED views in schema data_lake_{{ env }}.reference to role dl_{{ env }}_data_analysts;
grant select on future MATERIALIZED views in schema data_lake_{{ env }}.reference to role dl_{{ env }}_data_analysts;

grant usage on all functions in schema data_lake_dev.control to role dl_dev_data_analysts;
grant usage on all functions in schema data_lake_qa.control to role dl_qa_data_analysts;
grant usage on all functions in schema data_lake_uat.control to role dl_qa_data_analysts;
grant usage on all functions in schema data_lake_prd.control to role dl_prd_data_analysts;

/* End */

/* Grant Usage on WH to roles */

grant usage on warehouse data_load_{{ env }}_wh to role dl_{{ env }}_data_engineers;
grant usage on warehouse data_transform_{{ env }}_wh to role dl_{{ env }}_data_engineers;

grant modify on warehouse data_load_{{ env }}_wh to role dl_{{ env }}_data_engineers;
grant modify on warehouse data_transform_{{ env }}_wh to role dl_{{ env }}_data_engineers;

grant monitor on warehouse data_load_{{ env }}_wh to role dl_{{ env }}_data_engineers;
grant monitor on warehouse data_transform_{{ env }}_wh to role dl_{{ env }}_data_engineers;

grant usage on warehouse reporting_{{ env }}_wh to role dl_{{ env }}_data_analysts;
grant usage on warehouse analytics_{{ env }}_wh to role dl_{{ env }}_data_analysts;

/* Power BI data analysts global role */

CREATE ROLE dl_data_analysts

grant role dl_dev_data_analysts to role dl_data_analysts
grant role dl_qa_data_analysts to role dl_data_analysts
grant role dl_prd_data_analysts to role dl_data_analysts

grant role dl_data_analysts to user "NAVNEET.SINGH@LIGHTSOURCEBP.COM";
grant role dl_data_analysts to user "CLAUDIA.PUYALS@LIGHTSOURCEBP.COM";
grant role dl_data_analysts to user "ELLENA.WHITEHEAD@LIGHTSOURCEBP.COM";
grant role dl_data_analysts to user "NATHAN.COLLINS@LIGHTSOURCEBP.COM";
grant role dl_data_analysts to user "VICTORIA.BULLEN@LIGHTSOURCEBP.COM";

ALTER USER "NAVNEET.SINGH@LIGHTSOURCEBP.COM" SET DEFAULT_ROLE = 'DL_DATA_ANALYSTS';
ALTER USER "CLAUDIA.PUYALS@LIGHTSOURCEBP.COM" SET DEFAULT_ROLE = 'DL_DATA_ANALYSTS';
ALTER USER "ELLENA.WHITEHEAD@LIGHTSOURCEBP.COM" SET DEFAULT_ROLE = 'DL_DATA_ANALYSTS';
ALTER USER "NATHAN.COLLINS@LIGHTSOURCEBP.COM" SET DEFAULT_ROLE = 'DL_DATA_ANALYSTS';
ALTER USER "RICKY.MISTRY@LIGHTSOURCEBP.COM" SET DEFAULT_ROLE = 'DL_DATA_ANALYSTS';
ALTER USER "VICTORIA.BULLEN@LIGHTSOURCEBP.COM" SET DEFAULT_ROLE = 'DL_DATA_ANALYSTS';
/* end */

/* Create Queue notification intigration */
CREATE NOTIFICATION INTEGRATION qint_lsbpdata_lz_{{ env }}
  ENABLED = true
  TYPE = QUEUE
  NOTIFICATION_PROVIDER = AZURE_STORAGE_QUEUE
  AZURE_STORAGE_QUEUE_PRIMARY_URI = 'https://lsbpdata{{ env }}.queue.core.windows.net/lsbpdata{{ env }}queue'
  AZURE_TENANT_ID = 'ed5f664a-8752-4c95-8205-40c87d185116';
  
  DESC NOTIFICATION INTEGRATION qint_lsbpdata_lz_{{ env }}
  
  grant usage on integration qint_lsbpdata_lz_{{ env }} to role dl_{{ emv }}_data_engineers

/* end */

/* Grant role data analysts to role data engineers */
use role accountadmin;
grant role dl_{{ env }}_data_analysts to role dl_{{ env }}_data_engineers;

/* End */

grant role dl_{{ env }}_data_engineers to role sysadmin;

/* Create resource monitors for WH */
use role accountadmin;

CREATE RESOURCE MONITOR rm_prod_load_transform WITH CREDIT_QUOTA = 360 
frequency = 'MONTHLY',
START_TIMESTAMP = '2021-04-08 00:00 UTC',
END_TIMESTAMP = '2021-05-08 00:00 UTC'
TRIGGERS 
ON 80 PERCENT DO NOTIFY
ON 95 PERCENT DO NOTIFY 
ON 100 PERCENT DO SUSPEND;
 
CREATE RESOURCE MONITOR rm_prod_reports_analytics WITH CREDIT_QUOTA = 115 
frequency = 'MONTHLY',
START_TIMESTAMP = '2021-04-08 00:00 UTC',
END_TIMESTAMP = '2021-05-08 00:00 UTC'
TRIGGERS 
ON 80 PERCENT DO NOTIFY
ON 95 PERCENT DO NOTIFY 
ON 100 PERCENT DO SUSPEND;
/* End */

/* Apply resource monitors to WH */

ALTER WAREHOUSE data_load_{{ env }}_wh SET RESOURCE_MONITOR = rm_prod_load_transform;
ALTER WAREHOUSE data_transform_{{ env }}_wh SET RESOURCE_MONITOR = rm_prod_load_transform;
 
ALTER WAREHOUSE reporting_{{ env }}_wh SET RESOURCE_MONITOR = rm_prod_reports_analytics;
ALTER WAREHOUSE analytics_{{ env }}_wh SET RESOURCE_MONITOR = rm_prod_reports_analytics;
 
/* End */
grant usage on INTEGRATION SINT_LSBPDATA_LZ_dev to dl_dev_data_engineers;
/* create power BI integration */
create security integration powerbi
    type = external_oauth
    enabled = true
    external_oauth_type = azure
    external_oauth_issuer = 'https://sts.windows.net/ed5f664a-8752-4c95-8205-40c87d185116/'
    external_oauth_jws_keys_url = 'https://login.windows.net/common/discovery/keys'
    external_oauth_audience_list = ('https://analysis.windows.net/powerbi/connector/Snowflake')
    external_oauth_token_user_mapping_claim = 'upn'
    external_oauth_snowflake_user_mapping_attribute = 'login_name'
    external_oauth_any_role_mode = 'ENABLE';
/*end*/

/* create (external function) api integration */
create api integration dl_api_int_dev
    api_provider = azure_api_management
    azure_tenant_id = 'ed5f664a-8752-4c95-8205-40c87d185116'
    azure_ad_application_id = '19a7fad6-b725-48e5-acc6-ed43cf18c306'
    api_allowed_prefixes = ('https://dl-appl-api-mgmt.azure-api.net/dl-func-ext-sf-dev')
    enabled = true;

    desc integration dl_api_int_dev
    grant usage on integration dl_api_int_dev to role dl_dev_data_analysts;
grant usage on integration dl_api_int_dev to role dl_dev_data_engineers;
/* end */

/* grant Task execution priviledge to role */

grant execute task on account to role dl_{{ env }}_data_engineers
/* end */

/* grant permissions to share */

create share irradiance_data;

GRANT USAGE ON DATABASE data_lake_dev TO SHARE irradiance_data

ALTER VIEW DIM_SITES SET SECURE
ALTER VIEW dim_devices SET SECURE
ALTER VIEW dim_measurements SET SECURE

grant select on table DATA_LAKE_DEV.raw.fact_site_measurements to share irradiance_data;
grant select on table DATA_LAKE_DEV.curated.dim_sites to share irradiance_data;
grant select on table DATA_LAKE_DEV.curated.dim_devices to share irradiance_data;
grant select on table DATA_LAKE_DEV.curated.dim_measurements to share irradiance_data;

/* end */

/* transfer ownership to aad role */
grant ownership on user "AJINKYA.JOSHI@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "ANKITA.NAHATA@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "CLAUDIA.PUYALS@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "DARREN.WAUGH@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "DATALAKE.SERVICE@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "DNYANESHWAR.MOHITE@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "ELLENA.WHITEHEAD@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "GARIMA.DOSI@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "KARAN.OSHAN@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "KIERAN.SEEBURN@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "MIHALY.KAVASI@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "NATHAN.COLLINS@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "NAVNEET.SINGH@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "PBITEST.BUSTRAINING@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "PETER.CEJER@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "RICKY.MISTRY@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "SIDDHARTH.JOSHI@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "VICTORIA.BULLEN@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "VISWAJIT.NALAWADE@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "SAYALI.OVHAL@LIGHTSOURCEBP.COM" to role AAD_PROVISIONER;
grant ownership on user "datalake.sf.service" to role AAD_PROVISIONER;

grant ownership on role dl_admin to role AAD_PROVISIONER;
grant ownership on role dl_data_admin to role AAD_PROVISIONER;
grant ownership on role dl_dev_data_analysts to role AAD_PROVISIONER;
grant ownership on role dl_dev_data_engineers to role AAD_PROVISIONER;
grant ownership on role dl_qa_data_analysts to role AAD_PROVISIONER;
grant ownership on role dl_qa_data_engineers to role AAD_PROVISIONER;
grant ownership on role dl_dev_data_analysts to role AAD_PROVISIONER;
grant ownership on role dl_prd_data_engineers to role AAD_PROVISIONER;
grant ownership on role dl_prd_data_analysts to role AAD_PROVISIONER;

/* end */
