----Create storeage integration
CREATE storage integration sint_lsbpdata_lz_{{ env }}
	type = external_stage storage_provider = azure 
	enabled = true 
	azure_tenant_id = 'ed5f664a-8752-4c95-8205-40c87d185116' 
	storage_allowed_locations = 
					(
						'azure://lsbpdata{{ blobsuffix }}.blob.core.windows.net/inaccess-landing-zone/', 
						'azure://lsbpdata{{ blobsuffix }}.blob.core.windows.net/quickbase-landing-zone/', 
						'azure://lsbpdata{{ blobsuffix }}.blob.core.windows.net/stark-landing-zone/', 
						'azure://lsbpdata{{ blobsuffix }}.blob.core.windows.net/upl-landing-zone/',
						'azure://lsbpdata{{ blobsuffix }}.blob.core.windows.net/satellite-landing-zone/'
					);

grant usage on INTEGRATION SINT_LSBPDATA_LZ_{{ env }} to dl_{{ env }}_data_engineers 