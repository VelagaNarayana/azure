-- ------------------------------------------------------------
-- Create Access Roles #Dev (Once per environment)
-- ------------------------------------------------------------	

-- Schema roles --

create or replace role SF_ACR_DEV_REFERENCE_R;
create or replace role SF_ACR_DEV_REFERENCE_RW;
create or replace role SF_ACR_DEV_REFERENCE_FULL;

create or replace role SF_ACR_DEV_COMMON_R;
create or replace role SF_ACR_DEV_COMMON_RW;
create or replace role SF_ACR_DEV_COMMON_FULL;

create or replace role SF_ACR_DEV_CONTROL_R;
create or replace role SF_ACR_DEV_CONTROL_RW;
create or replace role SF_ACR_DEV_CONTROL_FULL;

create or replace role SF_ACR_DEV_CURATED_R;
create or replace role SF_ACR_DEV_CURATED_RW;
create or replace role SF_ACR_DEV_CURATED_FULL;

create or replace role SF_ACR_DEV_RAW_R;
create or replace role SF_ACR_DEV_RAW_RW;
create or replace role SF_ACR_DEV_RAW_FULL;

create or replace role SF_ACR_dev_snowchange_R;
create or replace role SF_ACR_dev_snowchange_RW;
create or replace role SF_ACR_dev_snowchange_FULL;


-- Warehouse roles --

create or replace role SF_ACR_ADMIN_WH_U;
create or replace role SF_ACR_ADMIN_WH_MO;
create or replace role SF_ACR_ADMIN_WH_FULL;

create or replace role SF_ACR_DEV_LOAD_WH_U;
create or replace role SF_ACR_DEV_LOAD_WH_MO;
create or replace role SF_ACR_DEV_LOAD_WH_FULL;

create or replace role SF_ACR_DEV_TRANSFORM_WH_U;
create or replace role SF_ACR_DEV_TRANSFORM_WH_MO;
create or replace role SF_ACR_DEV_TRANSFORM_WH_FULL;

create or replace role SF_ACR_DEV_REPORTING_WH_U;
create or replace role SF_ACR_DEV_REPORTING_WH_MO;
create or replace role SF_ACR_DEV_REPORTING_WH_FULL;

create or replace role SF_ACR_DEV_ANALYTICS_WH_U;
create or replace role SF_ACR_DEV_ANALYTICS_WH_MO;
create or replace role SF_ACR_DEV_ANALYTICS_WH_FULL;

-- Integration roles --

create or replace role SF_ACR_DEV_INTEGRATION_U;
create or replace role SF_ACR_DEV_INTEGRATION_OWNER;

-- Database roles --

create or replace role SF_ACR_DEV_DB_U;
create or replace role SF_ACR_DEV_DB_MO;
create or replace role SF_ACR_DEV_DB_FULL;

-- Resource monitors roles --

create or replace role SF_ACR_DEV_RM_U;
create or replace role SF_ACR_DEV_RM_FULL;

-- Nested Admin access roles --

create or replace role DL_DEV_ADMIN;

-- ------------------------------------------------------------
-- Grant permissions on Database to Access roles 
-- ------------------------------------------------------------  

grant ownership on database DATA_LAKE_DEV to role SF_ACR_DEV_DB_FULL;
grant usage on database DATA_LAKE_DEV to role SF_ACR_DEV_DB_U;
grant MODIFY, MONITOR, USAGE, CREATE SCHEMA on database DATA_LAKE_DEV to role SF_ACR_DEV_DB_MO;


-- ------------------------------------------------------------
-- Grant permissions on Integration to Access roles 
-- ------------------------------------------------------------  

grant ownership on integration DL_API_INT_DEV to role SF_ACR_DEV_INTEGRATION_OWNER;
grant ownership on integration QINT_LSBPDATA_LZ_DEV to role SF_ACR_DEV_INTEGRATION_OWNER;
grant ownership on integration SINT_LSBPDATA_LZ_DEV to role SF_ACR_DEV_INTEGRATION_OWNER;

grant usage on integration DL_API_INT_DEV to role SF_ACR_DEV_INTEGRATION_U;
grant usage on integration QINT_LSBPDATA_LZ_DEV to role SF_ACR_DEV_INTEGRATION_U;
grant usage on integration SINT_LSBPDATA_LZ_DEV to role SF_ACR_DEV_INTEGRATION_U;


-- ------------------------------------------------------------
-- Grant permissions on Resource monitors to Access roles 
-- ------------------------------------------------------------ 


grant usage on RESOURCE MONITOR RM_DEV_QA_LOAD_TRANSFORM to role SF_ACR_DEV_RM_U;
grant usage on RESOURCE MONITOR RM_DEV_QA_REPORTS_ANALYTICS to role SF_ACR_DEV_RM_U;
grant usage on RESOURCE MONITOR RM_PRD_LOAD_TRANSFORM to role SF_ACR_DEV_RM_U;
grant usage on RESOURCE MONITOR RM_PRD_REPORTS_ANALYTICS to role SF_ACR_DEV_RM_U;
 
grant MODIFY, MONITOR on RESOURCE MONITOR RM_DEV_QA_LOAD_TRANSFORM to role SF_ACR_DEV_RM_FULL;
grant MODIFY, MONITOR on RESOURCE MONITOR RM_DEV_QA_REPORTS_ANALYTICS to role SF_ACR_DEV_RM_FULL; 
grant MODIFY, MONITOR on RESOURCE MONITOR RM_PRD_LOAD_TRANSFORM to role SF_ACR_DEV_RM_FULL;
grant MODIFY, MONITOR on RESOURCE MONITOR RM_PRD_REPORTS_ANALYTICS to role SF_ACR_DEV_RM_FULL; 


-- ------------------------------------------------------------
-- Grant permissions on Warehouses to Access roles 
-- ------------------------------------------------------------ 

grant ownership on warehouse admin_WH to role SF_ACR_ADMIN_WH_FULL;
grant usage, monitor on warehouse admin_WH to role SF_ACR_ADMIN_WH_U;
grant usage, monitor, modify on warehouse admin_WH to role SF_ACR_ADMIN_WH_MO;


grant ownership on warehouse DATA_LOAD_DEV_WH to role SF_ACR_DEV_LOAD_WH_FULL;
grant ownership on warehouse DATA_TRANSFORM_DEV_WH to role SF_ACR_DEV_TRANSFORM_WH_FULL;
grant ownership on warehouse ANALYTICS_DEV_WH to role SF_ACR_DEV_ANALYTICS_WH_FULL;
grant ownership on warehouse REPORTING_DEV_WH to role SF_ACR_DEV_REPORTING_WH_FULL;

grant usage, monitor on warehouse DATA_LOAD_DEV_WH to role SF_ACR_DEV_LOAD_WH_U;
grant usage, monitor on warehouse DATA_TRANSFORM_DEV_WH to role SF_ACR_DEV_TRANSFORM_WH_U;
grant usage, monitor on warehouse ANALYTICS_DEV_WH to role SF_ACR_DEV_ANALYTICS_WH_U;
grant usage, monitor on warehouse REPORTING_DEV_WH to role SF_ACR_DEV_REPORTING_WH_U;

grant usage, monitor, modify on warehouse DATA_LOAD_DEV_WH to role SF_ACR_DEV_LOAD_WH_MO;
grant usage, monitor, modify on warehouse DATA_TRANSFORM_DEV_WH to role SF_ACR_DEV_TRANSFORM_WH_MO;
grant usage, monitor, modify on warehouse ANALYTICS_DEV_WH to role SF_ACR_DEV_ANALYTICS_WH_MO;
grant usage, monitor, modify on warehouse REPORTING_DEV_WH to role SF_ACR_DEV_REPORTING_WH_MO;



-- ------------------------------------------------------------
-- Grant permissions on schema to Access roles 
-- ------------------------------------------------------------ 


-- Reference schema Full access --

grant ownership on schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL copy current grants;
grant all on schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;
grant ownership on all tables in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;
grant ownership on all views  in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;
grant ownership on all stages in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;
grant ownership on all file formats in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;
grant ownership on all streams in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;
grant ownership on all procedures in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;
grant ownership on all functions in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;
grant ownership on all sequences in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;


-- Reference schema Full (Future grant) access --

grant ownership on future tables in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;
grant ownership on future views  in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;
grant ownership on future stages in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;
grant ownership on future file formats in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;
grant ownership on future streams in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;
grant ownership on future procedures in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;
grant ownership on future functions in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;
grant ownership on future sequences in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;



-- Reference schema read only access --
grant usage on schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;

grant select on all tables in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;
grant select on all external tables in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;
grant select on all views in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;
grant select on all MATERIALIZED views in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;
grant usage, read on all stages in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;
grant usage on all file formats in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;
grant select on all streams in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;
grant usage on all functions in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;
grant usage on all procedures in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;

-- Reference schema read only (Future grant) access --

grant select on future tables in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;
grant select on future external tables in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;
grant select on future views in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;
grant select on future MATERIALIZED views in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;
grant usage, read on future stages in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;
grant usage on future file formats in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;
grant select on future streams in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;
grant usage on future functions in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;
grant usage on future procedures in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_R;

-- Reference schema read write access --

grant MODIFY , MONITOR , USAGE on schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;
grant select, insert, update, delete, references on all tables in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;
grant select on all views in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;
grant usage, read, write on all stages in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;
grant usage on all file formats in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;
grant select on all streams in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;
grant usage on all procedures in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;
grant usage on all functions in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;
grant usage on all sequences in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;
grant monitor, operate on all tasks in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;

-- Reference schema read write (Future grant) access --

grant select, insert, update, delete, references on future tables in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;
grant select on future views in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;
grant usage, read, write on future stages in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;
grant usage on future file formats in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;
grant select on future streams in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;
grant usage on future procedures in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;
grant usage on future functions in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;
grant usage on future sequences in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;
grant monitor, operate on future tasks in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_RW;



----------------------------------------------------------------------------------------------------------------------------


-- COMMON schema Full access --

grant ownership on schema data_lake_dev.common to role SF_ACR_DEV_common_FULL copy current grants;
grant all on schema data_lake_dev.common to role SF_ACR_DEV_common_FULL;
grant ownership on all tables in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_FULL;
grant ownership on all views  in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_FULL;
grant ownership on all stages in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_FULL;
grant ownership on all file formats in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_FULL;
grant ownership on all streams in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_FULL;
grant ownership on all procedures in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_FULL;
grant ownership on all functions in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_FULL;
grant ownership on all sequences in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_FULL;


-- COMMON schema Full (Future grant) access --

grant ownership on future tables in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_FULL;
grant ownership on future views  in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_FULL;
grant ownership on future stages in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_FULL;
grant ownership on future file formats in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_FULL;
grant ownership on future streams in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_FULL;
grant ownership on future procedures in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_FULL;
grant ownership on future functions in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_FULL;
grant ownership on future sequences in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_FULL;



-- COMMON schema read only access --

grant usage on schema data_lake_dev.common to role SF_ACR_DEV_common_R;
grant select on all tables in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;
grant select on all external tables in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;
grant select on all views in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;
grant select on all MATERIALIZED views in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;
grant usage, read on all stages in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;
grant usage on all file formats in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;
grant select on all streams in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;
grant usage on all functions in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;
grant usage on all procedures in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;

-- COMMON schema read only (Future grant) access --

grant select on future tables in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;
grant select on future external tables in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;
grant select on future views in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;
grant select on future MATERIALIZED views in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;
grant usage, read on future stages in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;
grant usage on future file formats in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;
grant select on future streams in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;
grant usage on future functions in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;
grant usage on future procedures in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_R;

-- COMMON schema read write access --

grant MODIFY , MONITOR , USAGE on schema data_lake_dev.common to role SF_ACR_DEV_common_RW;
grant select, insert, update, delete, references on all tables in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;
grant select on all views in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;
grant usage, read, write on all stages in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;
grant usage on all file formats in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;
grant select on all streams in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;
grant usage on all procedures in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;
grant usage on all functions in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;
grant usage on all sequences in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;
grant monitor, operate on all tasks in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;

-- COMMON schema read write (Future grant) access --

grant select, insert, update, delete, references on future tables in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;
grant select on future views in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;
grant usage, read, write on future stages in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;
grant usage on future file formats in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;
grant select on future streams in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;
grant usage on future procedures in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;
grant usage on future functions in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;
grant usage on future sequences in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;
grant monitor, operate on future tasks in schema data_lake_dev.COMMON to role SF_ACR_DEV_COMMON_RW;


----------------------------------------------------------------------------------------------------------------------------

-- CONTROL schema Full access --

grant ownership on schema data_lake_dev.control to role SF_ACR_DEV_control_FULL copy current grants;
grant all on schema data_lake_dev.control to role SF_ACR_DEV_control_FULL;
grant ownership on all tables in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_FULL;
grant ownership on all views  in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_FULL;
grant ownership on all stages in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_FULL;
grant ownership on all file formats in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_FULL;
grant ownership on all streams in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_FULL;
grant ownership on all procedures in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_FULL;
grant ownership on all functions in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_FULL;
grant ownership on all sequences in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_FULL;


-- CONTROL schema Full (Future grant) access --

grant ownership on future tables in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_FULL;
grant ownership on future views  in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_FULL;
grant ownership on future stages in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_FULL;
grant ownership on future file formats in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_FULL;
grant ownership on future streams in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_FULL;
grant ownership on future procedures in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_FULL;
grant ownership on future functions in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_FULL;
grant ownership on future sequences in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_FULL;



-- CONTROL schema read only access --

grant usage on schema data_lake_dev.control to role SF_ACR_DEV_control_R;
grant select on all tables in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;
grant select on all external tables in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;
grant select on all views in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;
grant select on all MATERIALIZED views in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;
grant usage, read on all stages in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;
grant usage on all file formats in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;
grant select on all streams in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;
grant usage on all functions in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;
grant usage on all procedures in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;

-- CONTROL schema read only (Future grant) access --

grant select on future tables in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;
grant select on future external tables in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;
grant select on future views in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;
grant select on future MATERIALIZED views in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;
grant usage, read on future stages in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;
grant usage on future file formats in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;
grant select on future streams in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;
grant usage on future functions in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;
grant usage on future procedures in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_R;

-- CONTROL schema read write access --

grant MODIFY , MONITOR , USAGE on schema data_lake_dev.control to role SF_ACR_DEV_control_RW;
grant select, insert, update, delete, references on all tables in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;
grant select on all views in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;
grant usage, read, write on all stages in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;
grant usage on all file formats in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;
grant select on all streams in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;
grant usage on all procedures in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;
grant usage on all functions in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;
grant usage on all sequences in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;
grant monitor, operate on all tasks in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;

-- CONTROL schema read write (Future grant) access --

grant select, insert, update, delete, references on future tables in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;
grant select on future views in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;
grant usage, read, write on future stages in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;
grant usage on future file formats in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;
grant select on future streams in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;
grant usage on future procedures in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;
grant usage on future functions in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;
grant usage on future sequences in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;
grant monitor, operate on future tasks in schema data_lake_dev.CONTROL to role SF_ACR_DEV_CONTROL_RW;


----------------------------------------------------------------------------------------------------------------------------


-- CURATED schema Full access --

grant ownership on schema data_lake_dev.curated to role SF_ACR_DEV_curated_FULL copy current grants;
grant all on schema data_lake_dev.curated to role SF_ACR_DEV_curated_FULL;
grant ownership on all tables in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_FULL;
grant ownership on all views  in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_FULL;
grant ownership on all stages in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_FULL;
grant ownership on all file formats in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_FULL;
grant ownership on all streams in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_FULL;
grant ownership on all procedures in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_FULL;
grant ownership on all functions in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_FULL;
grant ownership on all sequences in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_FULL;

-- CURATED schema Full (Future grant) access --

grant ownership on future tables in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_FULL;
grant ownership on future views  in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_FULL;
grant ownership on future stages in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_FULL;
grant ownership on future file formats in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_FULL;
grant ownership on future streams in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_FULL;
grant ownership on future procedures in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_FULL;
grant ownership on future functions in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_FULL;


-- CURATED schema read only access --

grant usage on schema data_lake_dev.curated to role SF_ACR_DEV_curated_R;
grant select on all tables in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;
grant select on all external tables in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;
grant select on all views in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;
grant select on all MATERIALIZED views in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;
grant usage, read on all stages in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;
grant usage on all file formats in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;
grant select on all streams in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;
grant usage on all functions in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;
grant usage on all procedures in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;

-- CURATED schema read only (Future grant) access --

grant select on future tables in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;
grant select on future external tables in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;
grant select on future views in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;
grant select on future MATERIALIZED views in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;
grant usage, read on future stages in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;
grant usage on future file formats in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;
grant select on future streams in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;
grant usage on future functions in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;
grant usage on future procedures in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_R;

-- CURATED schema read write access --

grant MODIFY , MONITOR , USAGE on schema data_lake_dev.curated to role SF_ACR_DEV_curated_RW;
grant select, insert, update, delete, references on all tables in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;
grant select on all views in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;
grant usage, read, write on all stages in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;
grant usage on all file formats in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;
grant select on all streams in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;
grant usage on all procedures in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;
grant usage on all functions in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;
grant usage on all sequences in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;
grant monitor, operate on all tasks in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;

-- CURATED schema read write (Future grant) access --

grant select, insert, update, delete, references on future tables in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;
grant select on future views in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;
grant usage, read, write on future stages in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;
grant usage on future file formats in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;
grant select on future streams in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;
grant usage on future procedures in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;
grant usage on future functions in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;
grant usage on future sequences in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;
grant monitor, operate on future tasks in schema data_lake_dev.CURATED to role SF_ACR_DEV_CURATED_RW;


----------------------------------------------------------------------------------------------------------------------------


-- RAW schema Full access --

grant ownership on schema data_lake_dev.raw to role SF_ACR_DEV_raw_FULL copy current grants;
grant all on schema data_lake_dev.raw to role SF_ACR_DEV_raw_FULL;
grant ownership on all tables in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_FULL;
grant ownership on all views  in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_FULL;
grant ownership on all stages in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_FULL;
grant ownership on all file formats in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_FULL;
grant ownership on all streams in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_FULL;
grant ownership on all procedures in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_FULL;
grant ownership on all functions in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_FULL;
grant ownership on all sequences in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_FULL;

-- RAW schema Full (Future grant) access --

grant ownership on future tables in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_FULL;
grant ownership on future views  in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_FULL;
grant ownership on future stages in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_FULL;
grant ownership on future file formats in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_FULL;
grant ownership on future streams in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_FULL;
grant ownership on future procedures in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_FULL;
grant ownership on future functions in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_FULL;
grant ownership on future sequences in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_FULL;

-- RAW schema read only access --

grant usage on schema data_lake_dev.raw to role SF_ACR_DEV_raw_R;
grant select on all tables in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;
grant select on all external tables in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;
grant select on all views in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;
grant select on all MATERIALIZED views in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;
grant usage, read on all stages in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;
grant usage on all file formats in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;
grant select on all streams in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;
grant usage on all functions in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;
grant usage on all procedures in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;

-- RAW schema read only (Future grant) access --

grant select on future tables in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;
grant select on future external tables in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;
grant select on future views in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;
grant select on future MATERIALIZED views in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;
grant usage, read on future stages in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;
grant usage on future file formats in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;
grant select on future streams in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;
grant usage on future functions in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;
grant usage on future procedures in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_R;

-- RAW schema read write access --

grant MODIFY , MONITOR , USAGE on schema data_lake_dev.raw to role SF_ACR_DEV_raw_RW;
grant select, insert, update, delete, references on all tables in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;
grant select on all views in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;
grant usage, read, write on all stages in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;
grant usage on all file formats in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;
grant select on all streams in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;
grant usage on all procedures in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;
grant usage on all functions in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;
grant usage on all sequences in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;
grant monitor, operate on all tasks in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;

-- RAW schema read write (Future grant) access --

grant select, insert, update, delete, references on future tables in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;
grant select on future views in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;
grant usage, read, write on future stages in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;
grant usage on future file formats in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;
grant select on future streams in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;
grant usage on future procedures in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;
grant usage on future functions in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;
grant usage on future sequences in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;
grant monitor, operate on future tasks in schema data_lake_dev.RAW to role SF_ACR_DEV_RAW_RW;


----------------------------------------------------------------------------------------------------------------------------

-- snowchange schema Full access --

grant ownership on schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL copy current grants;
grant all on schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL;
grant ownership on all tables in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL;
grant ownership on all views  in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL;
grant ownership on all stages in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL;
grant ownership on all file formats in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL;
grant ownership on all streams in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL;
grant ownership on all procedures in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL;
grant ownership on all functions in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL;
grant ownership on all sequences in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL;

-- snowchange schema Full (Future grant) access --

grant ownership on future tables in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL;
grant ownership on future views  in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL;
grant ownership on future stages in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL;
grant ownership on future file formats in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL;
grant ownership on future streams in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL;
grant ownership on future procedures in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL;
grant ownership on future functions in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL;
grant ownership on future sequences in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_FULL;


-- snowchange schema read only access --
grant usage on schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;

grant select on all tables in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;
grant select on all external tables in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;
grant select on all views in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;
grant select on all MATERIALIZED views in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;
grant usage, read on all stages in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;
grant usage on all file formats in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;
grant select on all streams in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;
grant usage on all functions in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;
grant usage on all procedures in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;

-- snowchange schema read only (Future grant) access --

grant select on future tables in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;
grant select on future external tables in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;
grant select on future views in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;
grant select on future MATERIALIZED views in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;
grant usage, read on future stages in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;
grant usage on future file formats in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;
grant select on future streams in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;
grant usage on future functions in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;
grant usage on future procedures in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_R;

-- snowchange schema read write access --

grant MODIFY, MONITOR , USAGE on schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;
grant select, insert, update, delete, snowchanges on all tables in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;
grant select on all views in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;
grant usage, read, write on all stages in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;
grant usage on all file formats in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;
grant select on all streams in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;
grant usage on all procedures in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;
grant usage on all functions in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;
grant usage on all sequences in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;
grant monitor, operate on all tasks in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;

-- snowchange schema read write (Future grant) access --

grant select, insert, update, delete, snowchanges on future tables in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;
grant select on future views in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;
grant usage, read, write on future stages in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;
grant usage on future file formats in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;
grant select on future streams in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;
grant usage on future procedures in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;
grant usage on future functions in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;
grant usage on future sequences in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;
grant monitor, operate on future tasks in schema data_lake_dev.snowchange to role SF_ACR_DEV_snowchange_RW;

-------------------------------------------------------------------------------------------------------------------------------

grant monitor on all tasks in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_r;
grant monitor, operate on all tasks in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_rw;
grant monitor, operate on all tasks in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;

grant monitor on future tasks in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_r;
grant monitor, operate on future tasks in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_rw;
grant monitor, operate on future tasks in schema data_lake_dev.reference to role SF_ACR_DEV_REFERENCE_FULL;

grant monitor on all tasks in schema data_lake_dev.common to role SF_ACR_DEV_common_r;
grant monitor, operate on all tasks in schema data_lake_dev.common to role SF_ACR_DEV_common_rw;
grant monitor, operate on all tasks in schema data_lake_dev.common to role SF_ACR_DEV_common_FULL;

grant monitor on future tasks in schema data_lake_dev.common to role SF_ACR_DEV_common_r;
grant monitor, operate on future tasks in schema data_lake_dev.common to role SF_ACR_DEV_common_rw;
grant monitor, operate on future tasks in schema data_lake_dev.common to role SF_ACR_DEV_common_FULL;


grant monitor on all tasks in schema data_lake_dev.curated to role SF_ACR_DEV_curated_r;
grant monitor, operate on all tasks in schema data_lake_dev.curated to role SF_ACR_DEV_curated_rw;
grant monitor, operate on all tasks in schema data_lake_dev.curated to role SF_ACR_DEV_curated_FULL;

grant monitor on future tasks in schema data_lake_dev.curated to role SF_ACR_DEV_curated_r;
grant monitor, operate on future tasks in schema data_lake_dev.curated to role SF_ACR_DEV_curated_rw;
grant monitor, operate on future tasks in schema data_lake_dev.curated to role SF_ACR_DEV_curated_FULL;

grant monitor on all tasks in schema data_lake_dev.raw to role SF_ACR_DEV_raw_r;
grant monitor, operate on all tasks in schema data_lake_dev.raw to role SF_ACR_DEV_raw_rw;
grant monitor, operate on all tasks in schema data_lake_dev.raw to role SF_ACR_DEV_raw_FULL;

grant monitor on future tasks in schema data_lake_dev.raw to role SF_ACR_DEV_raw_r;
grant monitor, operate on future tasks in schema data_lake_dev.raw to role SF_ACR_DEV_raw_rw;
grant monitor, operate on future tasks in schema data_lake_dev.raw to role SF_ACR_DEV_raw_FULL;


grant monitor on all tasks in schema data_lake_dev.control to role SF_ACR_DEV_control_r;
grant monitor, operate on all tasks in schema data_lake_dev.control to role SF_ACR_DEV_control_rw;
grant monitor, operate on all tasks in schema data_lake_dev.control to role SF_ACR_DEV_control_FULL;

grant monitor on future tasks in schema data_lake_dev.control to role SF_ACR_DEV_control_r;
grant monitor, operate on future tasks in schema data_lake_dev.control to role SF_ACR_DEV_control_rw;
grant monitor, operate on future tasks in schema data_lake_dev.control to role SF_ACR_DEV_control_FULL;


grant ownership on all tasks in schema data_lake_dev.common to role dl_dev_data_engineers;
grant ownership on all tasks in schema data_lake_dev.control to role dl_dev_data_engineers;
grant ownership on all tasks in schema data_lake_dev.curated to role dl_dev_data_engineers;
grant ownership on all tasks in schema data_lake_dev.raw to role dl_dev_data_engineers;
grant ownership on all tasks in schema data_lake_dev.reference to role dl_dev_data_engineers;

grant ownership on future tasks in schema data_lake_dev.common to role dl_dev_data_engineers;
grant ownership on future tasks in schema data_lake_dev.control to role dl_dev_data_engineers;
grant ownership on future tasks in schema data_lake_dev.curated to role dl_dev_data_engineers;
grant ownership on future tasks in schema data_lake_dev.raw to role dl_dev_data_engineers;
grant ownership on future tasks in schema data_lake_dev.reference to role dl_dev_data_engineers;

grant execute task on account to role dl_dev_data_engineers;

----------------------------------------------------------------------------------------------------------------------------

-- ------------------------------------------------------------
-- Grant Access roles to "Engineer" Functional Role 
-- ------------------------------------------------------------ 

-- Granting schema access roles to data_engineers functional role --

grant role SF_ACR_DEV_REFERENCE_FULL to role dl_dev_data_engineers;
grant role SF_ACR_DEV_COMMON_FULL to role dl_dev_data_engineers;
grant role SF_ACR_DEV_CONTROL_FULL to role dl_dev_data_engineers;
grant role SF_ACR_DEV_CURATED_FULL to role dl_dev_data_engineers;
grant role SF_ACR_DEV_RAW_FULL to role dl_dev_data_engineers;

-- Granting Warehouse access roles to data_engineers functional role --

grant role SF_ACR_DEV_LOAD_WH_MO to role dl_dev_data_engineers;
grant role SF_ACR_DEV_TRANSFORM_WH_MO to role dl_dev_data_engineers;
grant role SF_ACR_DEV_ANALYTICS_WH_U to role dl_dev_data_engineers;


-- Granting Database access roles to data_engineers functional role --

grant role SF_ACR_DEV_DB_MO to role dl_dev_data_engineers;

-- Granting Integration access roles to data_engineers functional role --

grant role SF_ACR_DEV_INTEGRATION_U to role dl_dev_data_engineers; 

-- Granting Resource monitor access roles to data_engineers functional role --

grant role SF_ACR_DEV_RM_U to role dl_dev_data_engineers;

----------------------------------------------------------------------------------------------------------------------------

-- ------------------------------------------------------------
-- Grant Access roles to "Analysts" Functional Role 
-- ------------------------------------------------------------ 

-- Granting schema access roles to data_analysts functional role --

grant role SF_ACR_DEV_REFERENCE_R to role dl_dev_data_analysts;
grant role SF_ACR_DEV_COMMON_RW to role dl_dev_data_analysts;
grant role SF_ACR_DEV_CONTROL_RW to role dl_dev_data_analysts;
grant role SF_ACR_DEV_CURATED_RW to role dl_dev_data_analysts;
grant role SF_ACR_DEV_RAW_R to role dl_dev_data_analysts;

-- Granting Warehouse access roles to data_analysts functional role --

grant role SF_ACR_DEV_REPORTING_WH_MO to role dl_dev_data_analysts;
grant role SF_ACR_DEV_ANALYTICS_WH_MO to role dl_dev_data_analysts;


-- Granting Database access roles to data_analysts functional role --

grant role SF_ACR_DEV_DB_U to role dl_dev_data_analysts;

----------------------------------------------------------------------------------------------------------------------------

-- ------------------------------------------------------------
-- Grant Access roles to "Admin" Functional Role 
-- ------------------------------------------------------------ 

-- Granting schema access roles to dev_admin access role --

grant role SF_ACR_DEV_REFERENCE_FULL to role DL_DEV_ADMIN;
grant role SF_ACR_DEV_COMMON_FULL to role DL_DEV_ADMIN;
grant role SF_ACR_DEV_CONTROL_FULL to role DL_DEV_ADMIN;
grant role SF_ACR_DEV_CURATED_FULL to role DL_DEV_ADMIN;
grant role SF_ACR_DEV_RAW_FULL to role DL_DEV_ADMIN;
grant role SF_ACR_dev_snowchange_FULL to role DL_DEV_ADMIN;

-- Granting Warehouse access roles to dev_admin access role --

grant role SF_ACR_DEV_LOAD_WH_FULL to role DL_DEV_ADMIN;
grant role SF_ACR_DEV_TRANSFORM_WH_FULL to role DL_DEV_ADMIN;
grant role SF_ACR_DEV_REPORTING_WH_FULL to role DL_DEV_ADMIN;
grant role SF_ACR_DEV_ANALYTICS_WH_FULL to role DL_DEV_ADMIN;

-- Granting Database access roles to to dev_admin access role --

grant role SF_ACR_DEV_DB_FULL to role DL_DEV_ADMIN;

-- Granting Integration access roles to dev_admin access role --

grant role SF_ACR_DEV_INTEGRATION_OWNER to role DL_DEV_ADMIN; 

-- Granting Resource monitor access roles to dev_admin access role --

grant role SF_ACR_DEV_RM_U to role DL_DEV_ADMIN;

-- Granting Admin warehouse access roles to dev_admin access role --

grant role SF_ACR_ADMIN_WH_FULL to role dl_dev_admin

grant role dl_dev_admin to role dl_admin;

----------------------------------------------------------------------------------------------------------------------------

-- ------------------------------------------------------------
-- Grant Functional roles to "admin" role
-- ------------------------------------------------------------ 

grant role dl_dev_data_engineers to role dl_dev_admin;
grant role dl_dev_data_analysts to role dl_dev_admin;

----------------------------------------------------------------------------------------------------------------------------