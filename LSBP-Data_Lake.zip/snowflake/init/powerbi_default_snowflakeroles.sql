alter user "CLAUDIA.PUYALS@LIGHTSOURCEBP.COM" set default_role = Power_BI_Global_Performance_and_Monitoring;


alter user "PBITEST.OM@LIGHTSOURCEBP.COM" set default_role = Power_BI_Operations_and_Maintenance;

alter user "PBITEST.AM@LIGHTSOURCEBP.COM" set default_role = Power_BI_Asset_Management;

alter user "VICTORIA.BULLEN@LIGHTSOURCEBP.COM" set default_role = Power_BI_Global_Performance_and_Monitoring;
alter user "VITTORIA.GRESELE@LIGHTSOURCEBP.COM" set default_role = Power_BI_Global_Performance_and_Monitoring;
alter user "AMALIA.PERDIKOURI@LIGHTSOURCEBP.COM" set default_role = Power_BI_Global_Performance_and_Monitoring;
alter user "NICHOLAS.RACKHAM@LIGHTSOURCEBP.COM" set default_role = Power_BI_Global_Performance_and_Monitoring;
alter user "DIOGO.COSTA@LIGHTSOURCEBP.COM" set default_role = Power_BI_Global_Performance_and_Monitoring;
alter user "CLAUDIA.PUYALS@LIGHTSOURCEBP.COM" set default_role = Power_BI_Global_Performance_and_Monitoring;
alter user "CRAIG.KENDRICK@LIGHTSOURCEBP.COM" set default_role = Power_BI_Global_Performance_and_Monitoring;
alter user "ACHILLEAS.VOULOUDAKIS@LIGHTSOURCEBP.COM" set default_role = Power_BI_Global_Performance_and_Monitoring;
alter user "RICARDO.BENTO@LIGHTSOURCEBP.COM" set default_role = Power_BI_Global_Performance_and_Monitoring;
alter user "OLIVER.DUGAN@LIGHTSOURCEBP.COM" set default_role = Power_BI_Global_Performance_and_Monitoring;
alter user "GONZALO.JUANCO@LIGHTSOURCEBP.COM" set default_role = Power_BI_Global_Performance_and_Monitoring;
alter user "PBITEST.GPM@LIGHTSOURCEBP.COM" set default_role = Power_BI_Global_Performance_and_Monitoring;

alter user "MIHALY.KAVASI@LIGHTSOURCEBP.COM" set default_role = Power_BI_Data_and_Analytics;
alter user "PBITEST.BUSTRAINING@LIGHTSOURCEBP.COM" set default_role = Power_BI_Data_and_Analytics;

alter user "ELLENA.WHITEHEAD@LIGHTSOURCEBP.COM" set default_role = Power_BI_Data_and_Analytics;
alter user "RICKY.MISTRY@LIGHTSOURCEBP.COM" set default_role = Power_BI_Data_and_Analytics;
alter user "CHRISTINE.BURRIDGE@LIGHTSOURCEBP.COM" set default_role = Power_BI_Data_and_Analytics;
alter user "DARREN.WAUGH@LIGHTSOURCEBP.COM" set default_role = Power_BI_Data_and_Analytics;
alter user "KIERAN.SEEBURN@LIGHTSOURCEBP.COM" set default_role = Power_BI_Data_and_Analytics;


alter user "CHRISTOPHER.MOLTENO@LIGHTSOURCEBP.COM" set default_role = Power_BI_Investment_Management;
alter user "PBITEST.IM@LIGHTSOURCEBP.COM" set default_role = Power_BI_Investment_Management;

alter user "ADELE.ARA@LIGHTSOURCEBP.COM" set default_role = Power_BI_Digitalisation_and_Transformation;
alter user "KENNEDY.MUTONGERWA@LIGHTSOURCEBP.COM" set default_role = Power_BI_Digitalisation_and_Transformation;
alter user "RAHIL.BAIG@LIGHTSOURCEBP.COM" set default_role = Power_BI_Digitalisation_and_Transformation;
alter user "PBITEST.DT@LIGHTSOURCEBP.COM" set default_role = Power_BI_Digitalisation_and_Transformation;