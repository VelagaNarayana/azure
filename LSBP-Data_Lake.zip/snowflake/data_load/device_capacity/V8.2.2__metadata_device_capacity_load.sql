use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

CREATE OR REPLACE PROCEDURE "REFERENCE"."PROC_UPSERT_DEVICE_CAPACITY"(SOURCE_FILES_PATH VARCHAR,PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller 
AS
$$
try{

    snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','stage2ref'))"});
    snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );            


	var tempTableSQL;
	var tempTableName = "COMMON.\"TEMP_DEVICE_CAPACITY_"+PROCESS_RUN_ID+"\"";
    var rowsUpdated=0,rowsInserted=0;


	tempTableSQL = "create or replace temporary table "+tempTableName+" as with device_hierarchy as ( select *, sys_connect_by_path(device_name, ' ') as hrchy_device_names from REFERENCE.SOURCE_DEVICES start with device_id in (select device_id from  REFERENCE.SOURCE_DEVICES where device_apcode = 'PanelGroup') connect by device_id = prior parent ),device_capacity as ( select common.Resolve_unknown_dims(site.site_key) as site_key,capacity.* from ( select $2 as original_device_name, case when lower($7::varchar)='combiner box' then concat(' DC Box ',$2) else concat(' String ',$2) end as device_name,$6::double as original_capacity,metadata$filename as load_file,replace(split_part(load_file,'/',5),'.csv','') as site_name   from '@REFERENCE.STG_DEVICE_CAPACITY/"+SOURCE_FILES_PATH+"' ) capacity left join curated.dim_sites site ON (capacity.site_name = site.site_name or capacity.site_name = site.site_name_formula) ) select cc.site_fkey,cc.device_key,dc.site_name as original_site_name,dc.original_device_name as original_device_name,dc.original_capacity,cc.calculated_capacity,cc.load_file from ( select cap.load_file,device_key,site_fkey,device_id,dev.device_name, sum(original_capacity) as calculated_capacity from device_hierarchy dev join  device_capacity cap on dev.site_fkey=cap.site_key and startswith(dev.hrchy_device_names,cap.device_name) group by 1,2,3,4,5 ) cc left join device_capacity dc on cc.site_fkey = dc.site_key and trim(cc.device_name) = trim(dc.device_name)";
	snowflake.execute({ sqlText:tempTableSQL});


    var stmt = snowflake.createStatement({
         sqlText: "merge into reference.source_device_capacity src using  "+tempTableName+" dest on src.site_key = dest.site_fkey and src.device_key = dest.device_key when matched then update set original_site_name = dest.original_site_name, original_device_name = dest.original_device_name,original_capacity  = dest.original_capacity,calculated_capacity  = dest.calculated_capacity, process_exec_id = ?, updated_ts = sysdate(), load_file = dest.load_file when not matched then insert(SITE_KEY,DEVICE_KEY,ORIGINAL_SITE_NAME,ORIGINAL_DEVICE_NAME,ORIGINAL_CAPACITY,CALCULATED_CAPACITY,PROCESS_EXEC_ID,CREATED_TS,UPDATED_TS,LOAD_FILE) values (dest.site_fkey,dest.device_key,dest.original_site_name,dest.original_device_name,dest.original_capacity,dest.calculated_capacity,?,sysdate(),sysdate(),dest.load_file)",
    binds:[PROCESS_RUN_ID,PROCESS_RUN_ID]
    });  
    var rsMergeQuery = stmt.execute();
    rsMergeQuery.next();
    
    rowsInserted = rsMergeQuery.getColumnValue(1);
    rowsUpdated = rsMergeQuery.getColumnValue(2);
        
    var count = {"Inserted":rowsInserted,"Updated":rowsUpdated};
   }
   catch(err){
		rowsInserted=rowsUpdated=-1;
		throw err;
   }
   finally{
		snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
	}
 	return JSON.stringify({"Rows inserted":rowsInserted,"Rows updated":rowsUpdated});    
$$;


