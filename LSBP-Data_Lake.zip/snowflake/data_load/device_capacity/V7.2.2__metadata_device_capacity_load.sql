use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';


CREATE OR REPLACE FILE FORMAT REFERENCE.FF_CSV_DEVICE_CAPACITY 
    TYPE = 'CSV' 
    COMPRESSION = 'AUTO' 
    FIELD_DELIMITER = ',' 
    RECORD_DELIMITER = '\n' 
    SKIP_HEADER = 1 
    FIELD_OPTIONALLY_ENCLOSED_BY = 'NONE' 
    TRIM_SPACE = TRUE 
    ERROR_ON_COLUMN_COUNT_MISMATCH = TRUE 
    ESCAPE = '/' 
    ESCAPE_UNENCLOSED_FIELD = '\134' 
    DATE_FORMAT = 'AUTO' 
    TIMESTAMP_FORMAT = 'AUTO' 
    NULL_IF = ('\\N') 
    COMMENT = 'File format to read device capacity files';

CREATE OR REPLACE STAGE REFERENCE.STG_DEVICE_CAPACITY
	URL = 'azure://lsbpdata{{ blobsuffix }}.blob.core.windows.net/adhoc-data-sources/device-capacity/' 
	STORAGE_INTEGRATION = sint_lsbpdata_lz_{{ integration }}
	FILE_FORMAT =  REFERENCE.FF_CSV_DEVICE_CAPACITY 
	COMMENT = 'Stage to do load csv files of device capacity data ';



CREATE OR REPLACE TABLE REFERENCE.SOURCE_DEVICE_CAPACITY (
  SITE_KEY          INTEGER		    NOT NULL, 
  SITE_NAME         VARCHAR(255)    NOT NULL,
  DEVICE_NAME       VARCHAR(255)    NULL,
  CAPACITY          FLOAT          NULL,
  PROCESS_EXEC_ID	VARCHAR(100)    NULL,
  CREATED_TS	    TIMESTAMP       NULL,
  UPDATED_TS	    TIMESTAMP       NULL,	
  LOAD_FILE	        VARCHAR(500)    NOT NULL
) comment = "Table of device capacity data";



CREATE OR REPLACE PROCEDURE "REFERENCE"."PROC_UPSERT_DEVICE_CAPACITY"(SOURCE_FILES_PATH VARCHAR,PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller 
AS
$$
try{

    snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','stage2ref'))"});
    snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );            

    var rowsUpdated=0,rowsInserted=0;

    var stmt = snowflake.createStatement({
         sqlText: "merge into reference.source_device_capacity src using ( select common.Resolve_unknown_dims(site.site_key) as site_key,capacity.* from (select $2 as device_name,$6::double as capacity,metadata$filename as load_file,replace(split_part(load_file,'/',5),'.csv','') as site_name  from @REFERENCE.STG_DEVICE_CAPACITY/"+SOURCE_FILES_PATH+") capacity left join curated.dim_sites site ON (capacity.site_name = site.site_name or capacity.site_name = site.site_name_formula)) dest on src.site_name = dest.site_name and src.device_name = dest.device_name when matched then update set site_key = dest.site_key, capacity = dest.capacity, process_exec_id = ?, updated_ts = sysdate(), load_file = dest.load_file when not matched then insert(SITE_KEY,SITE_NAME,DEVICE_NAME,CAPACITY,PROCESS_EXEC_ID,CREATED_TS,UPDATED_TS,LOAD_FILE) values (dest.site_key,dest.site_name,dest.device_name,dest.capacity,?,sysdate(),sysdate(),dest.load_file)",
    binds:[PROCESS_RUN_ID,PROCESS_RUN_ID]
    });  
    var rsMergeQuery = stmt.execute();
    rsMergeQuery.next();
    
    rowsInserted = rsMergeQuery.getColumnValue(1);
    rowsUpdated = rsMergeQuery.getColumnValue(2);
        
    var count = {"Inserted":rowsInserted,"Updated":rowsUpdated};
   }
   catch(err){
		rowsInserted=rowsUpdated=-1;
		throw err;
   }
   finally{
		snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
	}
 	return JSON.stringify({"Rows inserted":rowsInserted,"Rows updated":rowsUpdated});    
$$;



