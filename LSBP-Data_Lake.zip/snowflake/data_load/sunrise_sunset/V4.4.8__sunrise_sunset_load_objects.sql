use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace TABLE reference.SUNRISE_SUNSET_DETAILS (
	SITE_FKEY NUMBER(38,0) NOT NULL,
	SDATE DATE NOT NULL,
    DATE_KEY NUMBER(38,0) NOT NULL,
	SUNRISE_FRACTION FLOAT,
	SUNRISE_HOUR SMALLINT,
	SUNRISE_MIN SMALLINT,
	SUNRISE_MINUTE_OF_DAY SMALLINT,
	SUNRISE_TIME TIME,
	SUNSET_FRACTION FLOAT,
	SUNSET_HOUR SMALLINT,
	SUNSET_MIN SMALLINT,
	SUNSET_MINUTE_OF_DAY SMALLINT,
	SUNSET_TIME TIME,
  	DAYLIGHT_FRACTION FLOAT,
	ELEVATION_AT_SOLAR_NOON FLOAT,
	ACTIVE_MINUTES INTEGER,
	LAST_UPDATED_TS TIMESTAMP_NTZ(9),
	PROCESS_EXEC_ID VARCHAR(50),
	CONSTRAINT fk_dim_sunrisesunset_sites FOREIGN KEY (site_fkey) REFERENCES reference.source_sites(site_key)
) comment = 'Reference table for sunrise sunset details per day';

create or replace procedure REFERENCE.GENERATE_SUNRISE_SUNSET_DETAILS(PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller 
AS
 $$
    snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','generatedim'))"});
    snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );
    
    var stmt = snowflake.createStatement({
               sqlText: "insert into reference.sunrise_sunset_details(SITE_FKEY ,SDATE ,DATE_KEY ,SUNRISE_FRACTION ,SUNRISE_HOUR ,SUNRISE_MIN ,SUNRISE_MINUTE_OF_DAY ,SUNRISE_TIME ,SUNSET_FRACTION ,SUNSET_HOUR ,SUNSET_MIN ,SUNSET_MINUTE_OF_DAY ,SUNSET_TIME ,DAYLIGHT_FRACTION ,ELEVATION_AT_SOLAR_NOON ,ACTIVE_MINUTES ,LAST_UPDATED_TS ,PROCESS_EXEC_ID) with sunrise_sunset as (select     site_key     , date, date_key     , radians(1) as radians     ,(-1)*asin( 0.39799*cos(0.98565*radians*(DAY_OF_YEAR+10) +(1.914*radians*sin(0.98565*radians*(DAY_OF_YEAR-2))))) as delta     , delta / radians as delta_degrees     , radians(latitude) as site_latitude_radians     , acos((-1)*tan(site_latitude_radians)*tan(delta)) as omega     , (PI()-omega) / (2*PI()) as sunrise     , floor(sunrise*24,0)  as sunrise_hour     , round(((sunrise*24) - floor(sunrise*24))*60,0) as sunrise_min         , (PI()+omega) / (2*PI()) as sunset     , floor(sunset * 24) as sunset_hour     , round(((sunset*24) - floor(sunset*24))*60,0) as sunset_min     ,(90.0+latitude)- delta_degrees as elevation     ,case when elevation > 90 then 180 - elevation           else elevation     end as elevation_at_solar_noon,     time_from_parts(sunrise_hour, sunrise_min,0) as sunrise_time,     time_from_parts(sunset_hour, sunset_min,0) as sunset_time     from curated.dim_calendar_date cal, curated.dim_sites sites     where sites.site_key not in (select distinct site_fkey from reference.sunrise_sunset_details)     and cal.date is not null and sites.site_key>0 ) select site_key,date as sdate,date_key,     sunrise as sunrise_fraction,    	hour(sunrise_time) as sunrise_hour, 	minute(sunrise_time) as sunrise_min,     round(sunrise*1440,0) as sunrise_minute_of_day,     sunrise_time,     sunset as sunset_fraction,     hour(sunset_time) as sunset_hour, 	minute(sunset_time) as sunset_min, 	round(sunset*1440,0) as sunset_minute_of_day,     sunset_time ,     (sunset - sunrise) as daylight_fraction,     elevation_at_solar_noon, 	round(round(sunset*1440,2) - round(sunrise*1440,2),0) as active_minutes,     sysdate() as last_updated_ts, ? as process_exec_id from sunrise_sunset",
               binds:[PROCESS_RUN_ID]
           });  
    var rs = stmt.execute();
    rs.next();
    var count = {"Inserted":rs.getColumnValue(1)};
    return JSON.stringify({ "Rows generated" : count});
 
 $$;
