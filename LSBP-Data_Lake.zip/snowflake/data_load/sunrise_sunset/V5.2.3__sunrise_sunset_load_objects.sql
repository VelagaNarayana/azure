use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace TABLE reference.SUNRISE_SUNSET_DETAILS (
	SITE_FKEY NUMBER(38,0) NOT NULL,
	DATE DATE NOT NULL, -- Join
    DATE_KEY NUMBER(38,0) NOT NULL,
	LOCAL_SOLAR_SUNRISE_FRACTION FLOAT,
	LOCAL_SOLAR_SUNRISE_HOUR SMALLINT,
	LOCAL_SOLAR_SUNRISE_MIN SMALLINT,
	LOCAL_SOLAR_SUNRISE_MINUTE_OF_DAY SMALLINT,
	LOCAL_SOLAR_SUNRISE_TIME TIME,
	LOCAL_SOLAR_SUNSET_FRACTION FLOAT,
	LOCAL_SOLAR_SUNSET_HOUR SMALLINT,
	LOCAL_SOLAR_SUNSET_MIN SMALLINT,
	LOCAL_SOLAR_SUNSET_MINUTE_OF_DAY SMALLINT,
	LOCAL_SOLAR_SUNSET_TIME TIME,
  	DAYLIGHT_FRACTION FLOAT,
	ELEVATION_AT_SOLAR_NOON FLOAT,
	ACTIVE_MINUTES INTEGER,
	OMEGA FLOAT,
	OMEGA_DEGREES FLOAT,
	UTC_SUNRISE_NUMBER FLOAT,
	UTC_SUNRISE_FRACTION FLOAT,
	UTC_SUNRISE_DATE DATE,
	UTC_SUNRISE_TIME TIME(9),
	LOCAL_SUNRISE_DATE DATE,
	LOCAL_SUNRISE_TIME TIME(9),
	UTC_SUNSET_NUMBER FLOAT,
	UTC_SUNSET_FRACTION FLOAT,
	UTC_SUNSET_DATE DATE,
	UTC_SUNSET_TIME TIME(9),
	LOCAL_SUNSET_DATE DATE,
	LOCAL_SUNSET_TIME TIME(9),
	LAST_UPDATED_TS TIMESTAMP_NTZ(9),
	PROCESS_EXEC_ID VARCHAR(50),
	CONSTRAINT fk_dim_sunrisesunset_sites FOREIGN KEY (site_fkey) REFERENCES reference.source_sites(site_key)
) comment = 'Reference table for sunrise sunset details per day';

create or replace procedure REFERENCE.GENERATE_SUNRISE_SUNSET_DETAILS(PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller 
AS
 $$
    snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','generatedim'))"});
    snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );
    
    var stmt = snowflake.createStatement({
               sqlText: "insert into reference.sunrise_sunset_details(SITE_FKEY ,DATE ,DATE_KEY , LOCAL_SOLAR_SUNRISE_FRACTION ,LOCAL_SOLAR_SUNRISE_HOUR ,LOCAL_SOLAR_SUNRISE_MIN ,LOCAL_SOLAR_SUNRISE_MINUTE_OF_DAY ,LOCAL_SOLAR_SUNRISE_TIME , LOCAL_SOLAR_SUNSET_FRACTION ,LOCAL_SOLAR_SUNSET_HOUR ,LOCAL_SOLAR_SUNSET_MIN ,LOCAL_SOLAR_SUNSET_MINUTE_OF_DAY ,LOCAL_SOLAR_SUNSET_TIME , DAYLIGHT_FRACTION ,ELEVATION_AT_SOLAR_NOON ,ACTIVE_MINUTES,  OMEGA ,OMEGA_DEGREES ,UTC_SUNRISE_NUMBER,UTC_SUNRISE_FRACTION,UTC_SUNRISE_DATE ,UTC_SUNRISE_TIME ,LOCAL_SUNRISE_DATE ,LOCAL_SUNRISE_TIME , UTC_SUNSET_NUMBER ,UTC_SUNSET_FRACTION ,UTC_SUNSET_DATE ,UTC_SUNSET_TIME ,LOCAL_SUNSET_DATE ,LOCAL_SUNSET_TIME, LAST_UPDATED_TS ,PROCESS_EXEC_ID)with sunrise_sunset as (select       site_key,   coalesce(derived_timezone, source_timezone) as timezone,  date,   date_key,  radians(1) as radians,  (-1)*asin( 0.39799*cos(0.98565*radians*(DAY_OF_YEAR+10) +(1.914*radians*sin(0.98565*radians*(DAY_OF_YEAR-2))))) as delta,   delta / radians as delta_degrees     ,   radians(latitude) as site_latitude_radians     ,   acos((-1)*tan(site_latitude_radians)*tan(delta)) as omega     ,   degrees(omega) as omega_degrees,  (PI()-omega) / (2*PI()) as sunrise     ,   floor(sunrise*24,0)  as sunrise_hour     ,  round(((sunrise*24) - floor(sunrise*24))*60,0) as sunrise_min         ,  (PI()+omega) / (2*PI()) as sunset,     floor(sunset * 24) as sunset_hour     ,   round(((sunset*24) - floor(sunset*24))*60,0) as sunset_min     ,  (90.0+latitude)- delta_degrees as elevation     ,  case when elevation > 90 then 180 - elevation           else elevation     end as elevation_at_solar_noon,       time_from_parts(sunrise_hour, sunrise_min,0) as sunrise_time,       time_from_parts(sunset_hour, sunset_min,0) as sunset_time  ,  (720-4*(longitude+omega_degrees)) as utc_sunrise_number,  utc_sunrise_number/1440 as utc_sunrise_fraction,  case when utc_sunrise_fraction>=0 then utc_sunrise_fraction else utc_sunrise_fraction end as utc_sunrise,    floor(utc_sunrise*24,0)%24 as utc_sunrise_hour,  round(((utc_sunrise*24) - floor(utc_sunrise*24))*60,0) as utc_sunrise_min ,     dateadd(day,floor(utc_sunrise,0),date) as utc_sunrise_date,  time_from_parts(utc_sunrise_hour, utc_sunrise_min,0) as utc_sunrise_time,      convert_timezone('UTC',timezone,timestamp_from_parts(utc_sunrise_date,utc_sunrise_time)) as local_sunrise_ts,  (720-4*(longitude-omega_degrees)) as utc_sunset_number,  utc_sunset_number/1440 as utc_sunset_fraction,  floor(utc_sunset_fraction*24,0)%24  as utc_sunset_hour     ,  round(((utc_sunset_fraction*24) - floor(utc_sunset_fraction*24))*60,0) as utc_sunset_min,  time_from_parts(utc_sunset_hour,utc_sunset_min,0) as utc_sunset_time,  dateadd(day,floor(utc_sunset_fraction,0),date) as utc_sunset_date,  convert_timezone('UTC',timezone,timestamp_from_parts(utc_sunset_date,utc_sunset_time)) as local_sunset_ts from curated.dim_calendar_date cal, curated.dim_sites sites       where sites.site_key not in (select distinct site_fkey from reference.sunrise_sunset_details)  and      cal.date is not null and sites.site_key>0 )     select site_key,date as date,date_key,       sunrise as local_solar_sunrise_fraction,   hour(sunrise_time) as local_solar_sunrise_hour, 	 minute(sunrise_time) as local_solar_sunrise_min,      round(sunrise*1440,0) as local_solar_sunrise_minute_of_day,      sunrise_time,     sunset as local_solar_sunset_fraction,      hour(sunset_time) as local_solar_sunset_hour, 	 minute(sunset_time) as local_solar_sunset_min, 	 round(sunset*1440,0) as local_solar_sunset_minute_of_day,      sunset_time  as local_solar_sunset_time,     (sunset - sunrise) as daylight_fraction,      elevation_at_solar_noon, 	 round(round(sunset*1440,2) - round(sunrise*1440,2),0) as active_minutes,   omega, omega_degrees, utc_sunrise_number,  utc_sunrise_fraction,  utc_sunrise_date,  utc_sunrise_time,  to_date(local_sunrise_ts) as local_sunrise_date,  to_time(local_sunrise_ts) as local_sunrise_time,  utc_sunset_number,  utc_sunset_fraction,   utc_sunset_date,  utc_sunset_time,  to_date(local_sunset_ts) as local_sunset_date,  to_time(local_sunset_ts) as local_sunset_time , sysdate() as last_updated_ts, ? as process_exec_id from sunrise_sunset",
               binds:[PROCESS_RUN_ID]
           });  
    var rs = stmt.execute();
    rs.next();
    var count = {"Inserted":rs.getColumnValue(1)};
    return JSON.stringify({ "Rows generated" : count});
 
 $$;