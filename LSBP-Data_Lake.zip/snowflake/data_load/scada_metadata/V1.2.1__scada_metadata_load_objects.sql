use database data_lake_{{ env }};
use warehouse DATA_LOAD_{{ env }}_WH;
use role dl_{{ env }}_data_engineers;

--Create file format 
CREATE OR REPLACE FILE FORMAT "RAW"."FF_JS_RAW_SCADA_METADATA"
	TYPE = 'JSON' 
	COMPRESSION = 'AUTO' 
	ENABLE_OCTAL = FALSE 
	ALLOW_DUPLICATE = FALSE 
	STRIP_OUTER_ARRAY = TRUE 
	STRIP_NULL_VALUES = FALSE 
	IGNORE_UTF8_ERRORS = FALSE 
	COMMENT = 'JSON format for SCADA metadata files';

-- Create Stage for SCADA METADATA LOAD 
CREATE OR REPLACE STAGE "RAW"."STG_SCADA_METADATA"
	URL = 'azure://lsbpdata{{ blobsuffix }}.blob.core.windows.net/inaccess-landing-zone/_Split_Insolar_Static/' 
	STORAGE_INTEGRATION = sint_lsbpdata_lz_{{ env }}
	FILE_FORMAT = "RAW"."FF_JS_RAW_SCADA_METADATA"
	COMMENT = 'Stage to load SCADA Metadata files'; 

----Drop table for SCADA metadata load if exists 

DROP TABLE  IF EXISTS "RAW"."STAGE_INSOLAR_METADATA" ;

--Create stage table for SCADA metadata load
CREATE TABLE "RAW"."STAGE_INSOLAR_METADATA" 
    (
        "SITE_ID" STRING NOT NULL,
        "PAYLOAD" VARIANT NOT NULL, 
        "FILE_ARRIVAL_DATE" DATE NOT NULL, 
        "ORIGINAL_FILENAME" STRING NOT NULL, 
        "SPLIT_FILENAME"  STRING NOT NULL,
        "LOAD_TS" TIMESTAMP NOT NULL,
        "PROCESS_EXEC_ID" STRING NOT NULL
    ) 
    COMMENT = 'Stores SCADA metadata raw files as payload';


-----DROP OLD PROCEDURE RAW.PROC_STAGE_SCADA_METADATA
DROP PROCEDURE IF EXISTS RAW.PROC_STAGE_SCADA_METADATA(VARCHAR);

-----Create procedure to load scada metadata
CREATE OR REPLACE PROCEDURE RAW.PROC_STAGE_SCADA_METADATA(YEARMONTHJSON VARCHAR, PIPELINE_RUN_ID VARCHAR, PIPELINE_NAME VARCHAR)
    RETURNS string
    LANGUAGE javascript
    strict
    EXECUTE AS CALLER 
    AS
    $$

       var insert_stmt = "";     
       
       var array_obj = JSON.parse(YEARMONTHJSON);

     	snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = '"+PIPELINE_NAME+"~"+PIPELINE_RUN_ID+"';"} ) 

               for(i=0;i<array_obj.length;i++ )  {
 
               if(array_obj[i].year != null && array_obj[i].month == null &&  array_obj[i].day == null){
               
                   var insert_stmt = "COPY INTO DATA_LAKE_{{ env }}.RAW.STAGE_INSOLAR_METADATA FROM (SELECT REPLACE(SPLIT_PART(CAST($1:source_file AS STRING),'/',5),'.json','') as SITE_ID,$1 AS PAYLOAD,TO_DATE(SPLIT_PART(METADATA$FILENAME,'/',2) || '-' || SPLIT_PART(METADATA$FILENAME,'/',3) || '-' || SPLIT_PART(METADATA$FILENAME,'/',4),'YYYY-MM-DD') as FILE_ARRIVAL_DATE,CAST($1:source_file AS STRING) AS ORIGINAL_FILENAME, METADATA$FILENAME AS SPLIT_FILENAME,SYSDATE(),'"+PIPELINE_RUN_ID+"' AS PIPELINE_RUN_ID FROM @DATA_LAKE_{{ env }}.RAW.STG_SCADA_METADATA/"+array_obj[i].year+") pattern='.*.json'";
                   snowflake.execute({sqlText: insert_stmt});

               } else if(array_obj[i].year != null && array_obj[i].month != null &&  array_obj[i].day == null){
               
                   var insert_stmt = "COPY INTO DATA_LAKE_{{ env }}.RAW.STAGE_INSOLAR_METADATA FROM (SELECT REPLACE(SPLIT_PART(CAST($1:source_file AS STRING),'/',5),'.json','') as SITE_ID,$1 AS PAYLOAD,TO_DATE(SPLIT_PART(METADATA$FILENAME,'/',2) || '-' || SPLIT_PART(METADATA$FILENAME,'/',3) || '-' || SPLIT_PART(METADATA$FILENAME,'/',4),'YYYY-MM-DD') as FILE_ARRIVAL_DATE,CAST($1:source_file AS STRING) AS ORIGINAL_FILENAME, METADATA$FILENAME AS SPLIT_FILENAME,SYSDATE(),'"+PIPELINE_RUN_ID+"' AS PIPELINE_RUN_ID FROM @DATA_LAKE_{{ env }}.RAW.STG_SCADA_METADATA/"+array_obj[i].year+"/"+array_obj[i].month+") pattern='.*.json'";
                   snowflake.execute({sqlText: insert_stmt});     
               
               }else if(array_obj[i].year != null && array_obj[i].month != null &&  array_obj[i].day != null) {
              
                   var insert_stmt = "COPY INTO DATA_LAKE_{{ env }}.RAW.STAGE_INSOLAR_METADATA FROM (SELECT REPLACE(SPLIT_PART(CAST($1:source_file AS STRING),'/',5),'.json','') as SITE_ID,$1 AS PAYLOAD,TO_DATE(SPLIT_PART(METADATA$FILENAME,'/',2) || '-' || SPLIT_PART(METADATA$FILENAME,'/',3) || '-' || SPLIT_PART(METADATA$FILENAME,'/',4),'YYYY-MM-DD') as FILE_ARRIVAL_DATE,CAST($1:source_file AS STRING) AS ORIGINAL_FILENAME, METADATA$FILENAME AS SPLIT_FILENAME,SYSDATE(),'"+PIPELINE_RUN_ID+"' AS PIPELINE_RUN_ID FROM @DATA_LAKE_{{ env }}.RAW.STG_SCADA_METADATA/"+array_obj[i].year+"/"+array_obj[i].month+"/"+array_obj[i].day+") pattern='.*.json'";                
                   snowflake.execute({sqlText: insert_stmt});
               
               }else{       return "Invalid JSON passed in procedure";   // Return a success/error indicator. 
               
               }
           }
               
        snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )

       return "Success";   // Return a success/error indicator.
        
        $$
       ;       
       
