-----Create procedure to load scada metadata
use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

-- DROP OLD PROCEDURE RAW.PROC_STAGE_SCADA_METADATA
DROP PROCEDURE IF EXISTS RAW.PROC_STAGE_SCADA_METADATA(VARCHAR, VARCHAR, VARCHAR);

-- Create SP to load scada metadata 
CREATE OR REPLACE PROCEDURE RAW.PROC_STAGE_SCADA_METADATA(YEARMONTHJSON VARCHAR, PATTERN VARCHAR, PIPELINE_RUN_ID VARCHAR, PIPELINE_NAME VARCHAR)
    RETURNS string
    LANGUAGE javascript
    strict
    EXECUTE AS CALLER 
    AS
    $$

       var insert_stmt = "";     
       
       var array_obj = JSON.parse(YEARMONTHJSON);

     	snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = '"+PIPELINE_NAME+"~"+PIPELINE_RUN_ID+"';"} ) 

               for(i=0;i<array_obj.length;i++ )  {
 
               if(array_obj[i].year != null && array_obj[i].month == null &&  array_obj[i].day == null){
               
                   var insert_stmt = "COPY INTO DATA_LAKE_{{ db }}.RAW.STAGE_INSOLAR_METADATA FROM (SELECT REPLACE(SPLIT_PART(CAST($1:source_file AS STRING),'/',5),'.json','') as SITE_ID,$1 AS PAYLOAD,TO_DATE(SPLIT_PART(METADATA$FILENAME,'/',2) || '-' || SPLIT_PART(METADATA$FILENAME,'/',3) || '-' || SPLIT_PART(METADATA$FILENAME,'/',4),'YYYY-MM-DD') as FILE_ARRIVAL_DATE,CAST($1:source_file AS STRING) AS ORIGINAL_FILENAME, METADATA$FILENAME AS SPLIT_FILENAME,SYSDATE(),'"+PIPELINE_RUN_ID+"' AS PIPELINE_RUN_ID FROM @DATA_LAKE_{{ db }}.RAW.STG_SCADA_METADATA/"+array_obj[i].year+") pattern='.*"+PATTERN+"'";
                   snowflake.execute({sqlText: insert_stmt});

               } else if(array_obj[i].year != null && array_obj[i].month != null &&  array_obj[i].day == null){
               
                   var insert_stmt = "COPY INTO DATA_LAKE_{{ db }}.RAW.STAGE_INSOLAR_METADATA FROM (SELECT REPLACE(SPLIT_PART(CAST($1:source_file AS STRING),'/',5),'.json','') as SITE_ID,$1 AS PAYLOAD,TO_DATE(SPLIT_PART(METADATA$FILENAME,'/',2) || '-' || SPLIT_PART(METADATA$FILENAME,'/',3) || '-' || SPLIT_PART(METADATA$FILENAME,'/',4),'YYYY-MM-DD') as FILE_ARRIVAL_DATE,CAST($1:source_file AS STRING) AS ORIGINAL_FILENAME, METADATA$FILENAME AS SPLIT_FILENAME,SYSDATE(),'"+PIPELINE_RUN_ID+"' AS PIPELINE_RUN_ID FROM @DATA_LAKE_{{ db }}.RAW.STG_SCADA_METADATA/"+array_obj[i].year+"/"+array_obj[i].month+") pattern='.*"+PATTERN+"'";
                   snowflake.execute({sqlText: insert_stmt});     
               
               }else if(array_obj[i].year != null && array_obj[i].month != null &&  array_obj[i].day != null) {
              
                   var insert_stmt = "COPY INTO DATA_LAKE_{{ db }}.RAW.STAGE_INSOLAR_METADATA FROM (SELECT REPLACE(SPLIT_PART(CAST($1:source_file AS STRING),'/',5),'.json','') as SITE_ID,$1 AS PAYLOAD,TO_DATE(SPLIT_PART(METADATA$FILENAME,'/',2) || '-' || SPLIT_PART(METADATA$FILENAME,'/',3) || '-' || SPLIT_PART(METADATA$FILENAME,'/',4),'YYYY-MM-DD') as FILE_ARRIVAL_DATE,CAST($1:source_file AS STRING) AS ORIGINAL_FILENAME, METADATA$FILENAME AS SPLIT_FILENAME,SYSDATE(),'"+PIPELINE_RUN_ID+"' AS PIPELINE_RUN_ID FROM @DATA_LAKE_{{ db }}.RAW.STG_SCADA_METADATA/"+array_obj[i].year+"/"+array_obj[i].month+"/"+array_obj[i].day+") pattern='.*"+PATTERN+"'";                
                   snowflake.execute({sqlText: insert_stmt});
               
               }else{       return "Invalid JSON passed in procedure";   // Return a success/error indicator. 
               
               }
           }
               
        snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )

       return "Success";   // Return a success/error indicator.
        
        $$
       ;       
       