use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace FILE FORMAT "RAW".FF_CSV_RAW_PRODUCTION_DATA  
COMPRESSION = 'AUTO' FIELD_DELIMITER = ',' RECORD_DELIMITER = '\n' SKIP_HEADER = 0 
FIELD_OPTIONALLY_ENCLOSED_BY = 'NONE' TRIM_SPACE = TRUE 
ERROR_ON_COLUMN_COUNT_MISMATCH = TRUE ESCAPE = 'NONE' 
ESCAPE_UNENCLOSED_FIELD = '\134' DATE_FORMAT = 'AUTO' 
TIMESTAMP_FORMAT = 'AUTO' NULL_IF = ('');

create or replace stage "RAW"."STG_STARK_PRODUCTION_DATA" 
URL = 'azure://lsbpdata{{ blobsuffix }}.blob.core.windows.net/stark-landing-zone/lsbp-sites' 
STORAGE_INTEGRATION = SINT_LSBPDATA_LZ_{{ integration }}
file_format=RAW.FF_CSV_RAW_PRODUCTION_DATA
COMMENT = 'Stage to do read stark production data';

create or replace stage "RAW"."STG_UPL_PRODUCTION_DATA"
URL = 'azure://lsbpdata{{ blobsuffix }}.blob.core.windows.net/upl-landing-zone/lsbp-sites'
STORAGE_INTEGRATION = SINT_LSBPDATA_LZ_{{ integration }}
file_format=RAW.FF_CSV_RAW_PRODUCTION_DATA
COMMENT = 'Stage to do read upl production data';