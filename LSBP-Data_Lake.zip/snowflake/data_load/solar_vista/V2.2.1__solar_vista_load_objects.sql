use database data_lake_{{ env }};
use warehouse DATA_LOAD_{{ env }}_WH;
use role dl_{{ env }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

--DROP FILE FORMAT "DATA_LAKE_{{ env }}."REFERENCE".FF_CSV_REF_SOLAR_VISTA
CREATE OR REPLACE FILE FORMAT "REFERENCE".FF_CSV_REF_SOLAR_VISTA TYPE = 'CSV' COMPRESSION = 'AUTO' RECORD_DELIMITER = '
' FIELD_OPTIONALLY_ENCLOSED_BY = '"' SKIP_HEADER = 0 TRIM_SPACE = FALSE ERROR_ON_COLUMN_COUNT_MISMATCH = TRUE 
 ESCAPE = '\\'  NULL_IF = '' ENCODING = UTF8 FIELD_DELIMITER = '|';

--DROP STAGE "REFERENCE"."STG_SOLAR_VISTA_DATA"
CREATE OR REPLACE STAGE "REFERENCE"."STG_SOLAR_VISTA_DATA"
	URL = 'azure://lsbpdata{{ blobsuffix }}.blob.core.windows.net/sv-landing-zone/' 
	STORAGE_INTEGRATION = sint_lsbpdata_lz_{{ env }}
	FILE_FORMAT = "REFERENCE".FF_CSV_REF_SOLAR_VISTA
	COMMENT = 'Stage to load Solar Vista files'; 
    
--DROP PROCEDURE "REFERENCE"."PROC_LOAD_SV_DATA"( VARCHAR,  VARCHAR,  VARCHAR,  VARCHAR,  VARCHAR)
CREATE OR REPLACE PROCEDURE "REFERENCE"."PROC_LOAD_SV_DATA"(FILE VARCHAR, SOURCE_TBL VARCHAR, PIPELINE_RUN_ID VARCHAR, PIPELINE_NAME VARCHAR)
    RETURNS string
    LANGUAGE javascript
    strict
    EXECUTE AS CALLER 
    AS
    $$             
        
        var tbl_command = "select table_schema, table_name from information_schema.tables where comment = '"+SOURCE_TBL+"'"
        var sql_command = {sqlText: tbl_command};
        var stmt = snowflake.createStatement(sql_command);
        var res = stmt.execute();
        res.next();
        var TARGET_SCHEMA = res.getColumnValue(1);
        var TARGET_TBL = res.getColumnValue(2);
        var QUOTED_TARGET_SCHEMA = '"'+res.getColumnValue(1)+'"';
        var QUOTED_TARGET_TBL = '"'+res.getColumnValue(2)+'"';
        
        var cols_command = "select listagg(concat(\$\$\"\$\$\,column_name,\$\$\"\$\$\),',') WITHIN GROUP ( order by ordinal_position ),listagg(comment,', ') WITHIN GROUP ( order by ordinal_position ) from INFORMATION_SCHEMA.COLUMNS where table_schema='"+TARGET_SCHEMA+"' and table_name='"+TARGET_TBL+"' and comment is not null;"
        sql_command = {sqlText: cols_command};
        stmt = snowflake.createStatement(sql_command);
        res = stmt.execute();
        res.next();
        var TARGET_COLS = res.getColumnValue(1);
        var PARSE_COLS = res.getColumnValue(2);
                   
        snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = '"+PIPELINE_NAME+"~"+PIPELINE_RUN_ID+"';"} ) 
        snowflake.execute( {sqlText: "BEGIN WORK;"} ); 
        try{        
          
           snowflake.execute( {sqlText: "DELETE FROM "+QUOTED_TARGET_SCHEMA+"."+QUOTED_TARGET_TBL+";"} );
           var load_command = "copy into "+QUOTED_TARGET_SCHEMA+"."+QUOTED_TARGET_TBL+"("+TARGET_COLS+",PROCESS_EXEC_ID,LOAD_TS, LOAD_FILE) FROM (select "+PARSE_COLS+",'"+PIPELINE_RUN_ID+"' AS PROCESS_EXEC_ID, SYSDATE() AS LOAD_TS, METADATA$FILENAME AS LOAD_FILE from '@DATA_LAKE_{{ env }}.REFERENCE.STG_SOLAR_VISTA_DATA\/"+FILE+"');"
          sql_command = {sqlText: load_command};

          snowflake.execute(sql_command);
          snowflake.execute( {sqlText: "COMMIT WORK;"} );
        }
        catch(err){
            snowflake.execute( {sqlText: "ROLLBACK WORK;"} );
            throw err;
        }
        finally{
            snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
        }
                
        return "Success";
        
    $$

 --CALL "REFERENCE"."PROC_LOAD_SV_DATA"('2021/04/07/ProductsCategories-20210407.csv','ProductsCategories','pl_exec_id_test','pl_name_test')
  
    