use database data_lake_{{ env }};
use warehouse DATA_LOAD_{{ env }}_WH;
use role dl_{{ env }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

create or replace table reference."SV_ScheduledService_DueDateAudit"
(
"UID"						integer		not null comment '$1',
"ScheduledServiceID"		integer		comment '$2',
"AuditDate"					datetime	comment '$3',
"RecordStatusID"			integer		comment '$4',
"AuditUser"					varchar(200)		comment '$5',
"AgreementID"				integer		comment '$6',
"CustomerID"				integer		comment '$7',
"EquipmentID"				integer		comment '$8',
"SchedServiceType"			smallint	comment '$9',
"integerervalID"				integer	comment '$10',
"integerervalEveryID"			integer	comment '$11',
"ServiceRoutineID"				integer	comment '$12',
"StatusID"						integer	comment '$13',
"ServiceOrdersJobID"			integer	comment '$14',
"Charge"					float		comment '$15',
"CurrencyCharge"			float		comment '$16',
"ServiceSchemeID"			integer		comment '$17',
"PersonnelID"				integer		comment '$18',
"SSEquipmentID"			integer			comment '$19',
"EstDurationInMins"		integer			comment '$20',
"CustomersEquipmentSSID"	integer		comment '$21',
"AgreementEquipmentID"	integer			comment '$22',
"OldScheduledDate"		datetime		comment '$23',
"OldScheduledTime"		datetime 		comment '$24',	
"NewScheduledDate"		datetime		comment '$25',
"NewScheduledTime"		datetime 		comment '$26',
CONSTRAINT   aaaScheduledService_DueDateAudit_PK  PRIMARY KEY     (UID) ,
 process_exec_id varchar(100),
 load_ts timestamp_ntz,
 load_file varchar(100)
 )comment ='ScheduledService_DueDateAudit';

create or replace table reference."SV_ServiceOrdersJobs_ScheduledServiceAudit"
(
"UID"					integer		not null	comment '$1' ,
"JobID"					integer			comment '$2',
"AuditDate"				datetime		comment '$3',
"RecordStatusID"		integer			comment '$4',
"AuditUser"				varchar(200)			comment '$5',
"OldScheduledDate"		datetime		comment '$6',
"OldScheduledTime"		datetime		comment '$7',
"NewScheduledDate"		datetime		comment '$8',
"NewScheduledTime"		datetime 		comment '$9',
CONSTRAINT   aaaServiceOrdersJobs_ScheduledServiceAudit_PK  PRIMARY KEY     (UID) ,
 process_exec_id varchar(100),
 load_ts timestamp_ntz,
 load_file varchar(100)
 )comment ='ServiceOrdersJobs_ScheduledServiceAudit';