use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

CREATE OR REPLACE TABLE "REFERENCE"."SV_Causes" ( 
 "UID"              INTEGER          NOT NULL comment '$1' ,
 "RecordStatusID"   INTEGER              NULL comment '$2' ,
 "CreatedDate"      DATETIME             NULL comment '$3' ,
 "CreatedTime"      DATETIME             NULL comment '$4' ,
 "CreatedByID"      INTEGER              NULL comment '$5' ,
 "Description"      VARCHAR(50)          NULL comment '$6' ,
 "ShortCode"        VARCHAR(10)          NULL comment '$7' ,
 "Memo"             TEXT                 NULL comment '$8' ,
 "CauseCategoryID"  INTEGER              NULL comment '$9' ,
 "DescriptionL2"    VARCHAR(50)          NULL comment '$10',
 "DescriptionL3"    VARCHAR(50)          NULL comment '$11',
 "DescriptionL4"    VARCHAR(50)          NULL comment '$12',
 "DescriptionL5"    VARCHAR(50)          NULL comment '$13',
 "DescriptionL6"    VARCHAR(50)          NULL comment '$14',
 "DescriptionL7"    VARCHAR(50)          NULL comment '$15',
 "DescriptionL8"    VARCHAR(50)          NULL comment '$16',
 "RecordTimeStamp"  varchar(100)         NULL comment '$17',
 process_exec_id varchar(100),
 load_ts timestamp_ntz,
 load_file varchar(100),
  CONSTRAINT   aaaCauses_PK PRIMARY KEY (UID) 
 )comment ='Causes';
