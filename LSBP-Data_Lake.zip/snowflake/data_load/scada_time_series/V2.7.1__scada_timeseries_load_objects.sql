use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;


CREATE OR REPLACE FILE FORMAT "RAW".FF_CSV_SCADA_TS_LOGS 
    TYPE = 'CSV' COMPRESSION = 'AUTO' 
    FIELD_DELIMITER = ',' 
    RECORD_DELIMITER = '\n' 
    SKIP_HEADER = 1 
    FIELD_OPTIONALLY_ENCLOSED_BY = 'NONE' 
    TRIM_SPACE = TRUE 
    ERROR_ON_COLUMN_COUNT_MISMATCH = TRUE 
    ESCAPE = 'NONE' 
    ESCAPE_UNENCLOSED_FIELD = '\134' 
    DATE_FORMAT = 'AUTO' 
    TIMESTAMP_FORMAT = 'AUTO' 
    NULL_IF = ('\\N') 
    COMMENT = 'File format for reading the log files of timeseries data';


CREATE OR REPLACE STAGE "RAW".STG_SCADA_TIMESERIES_LOG
	URL = 'azure://lsbpdata{{ blobsuffix }}.blob.core.windows.net/inaccess-landing-zone/Insolar_Time_Series/logs/' 
	STORAGE_INTEGRATION = sint_lsbpdata_lz_{{ integration }}
	FILE_FORMAT = "RAW".FF_CSV_SCADA_TS_LOGS 
	COMMENT = 'Stage to do load of SCADA timeseries parquet files ';



/*ALTER TABLE IF EXISTS "RAW"."STAGE_INSOLAR_TS" ADD COLUMN  "FILE_ARRIVAL_DATE" DATE;*/

UPDATE  "RAW"."STAGE_INSOLAR_TS" SET FILE_ARRIVAL_DATE = TO_DATE(REGEXP_SUBSTR(FILENAME,'(\\d{4}\/\\d{2}\/\\d{2})'),'YYYY/MM/DD');


---------------Procedure to stage files from blob to stage using log file

CREATE OR REPLACE PROCEDURE "RAW"."PROC_STAGE_TIMESERIES_RECONCILIATION"(YEAR FLOAT,MONTH FLOAT,DAY FLOAT,PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller
AS
$$

    var dt_month = MONTH.toString().padStart(2,'0');
    var dt_day = DAY.toString().padStart(2,'0');

    snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','Blob2StageUsingLogs'))"});
	snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );

    snowflake.execute( {sqlText: "alter session set timestamp_type_mapping = timestamp_ltz;"} );

	var tempTableSql;
	var tempTableName = "COMMON.\"TEMP_PROD_INSOLAR_TS_LOG_"+PROCESS_RUN_ID+"\"";
    var noOfFileToLoad=0;
    var noOfFilesNotLoaded=0;
    
    tempTableSql =  snowflake.createStatement({
    sqlText: "CREATE OR REPLACE TEMPORARY TABLE "+tempTableName+" AS  SELECT  distinct  CONCAT('\\'',log.file_name,'\\'') AS file_name,row_number() OVER (ORDER BY log.file_name) as row_number FROM ( SELECT REPLACE($1,'Insolar_Time_Series/','') AS FILE_NAME FROM @RAW.STG_SCADA_TIMESERIES_LOG/files/"+YEAR+"/"+dt_month+"/"+dt_day+") log LEFT JOIN (SELECT DISTINCT FILE_NAME FROM TABLE (information_schema.copy_history(table_name=>'RAW.STAGE_INSOLAR_TS', start_time=>  to_timestamp('"+YEAR+"-"+dt_month+"-"+dt_day+" 00:00:00'), end_time=> to_timestamp('"+YEAR+"-"+dt_month+"-"+dt_day+" 23:59:59'))) WHERE error_count =0 ) history ON log.FILE_NAME=history.FILE_NAME WHERE history.FILE_NAME IS  NULL"
    });	
    
    tempTableSql.execute();

    var countOfFiles =  snowflake.createStatement({
    sqlText: "SELECT COUNT(*) AS CNT FROM "+tempTableName+" "
    });	    
    rs =  countOfFiles.execute();
	rs.next();
	noOfFileToLoad = rs.getColumnValue(1);

   	snowflake.execute({sqlText: "set groupcount = (SELECT ceil(COUNT(*)/1000) FROM "+tempTableName+")"});

    var stmt = snowflake.createStatement({
    sqlText: "SELECT listagg(filename,',') AS FILELISTS FROM ( SELECT file_name AS filename,row_number() OVER (ORDER BY file_name) as row_number,mod(row_number,$groupcount) as group_number FROM "+tempTableName+" ) GROUP BY  group_number;"
                    });
    var result_set = stmt.execute();;
    var copycommand;

        while (result_set.next())  {

             copycommand = "COPY INTO RAW.STAGE_INSOLAR_TS FROM ( SELECT $1 AS PAYLOAD, SYSDATE(), METADATA$FILENAME AS FILENAME,'"+PROCESS_RUN_ID+"' AS PIPELINE_RUN_ID,TO_DATE(REGEXP_SUBSTR(METADATA$FILENAME,'(\\\\d{4}\/\\\\d{2}\/\\\\d{2})'),'YYYY/MM/DD') AS FILE_ARRIVAL_DATE FROM @RAW.STG_SCADA_TIMESERIES )  files=( "+result_set.getColumnValue(1)+" )  on_error=skip_file ";
             snowflake.execute( {sqlText:copycommand} );
        }


    var checkUnloadedFileSql =  snowflake.createStatement({
    sqlText: "SELECT COUNT(distinct log.file_name),listagg(distinct log.file_name,',')  FROM ( SELECT REPLACE($1,'Insolar_Time_Series/','') AS FILE_NAME FROM @RAW.STG_SCADA_TIMESERIES_LOG/files/"+YEAR+"/"+dt_month+"/"+dt_day+") log LEFT JOIN (SELECT file_name,error_count FROM TABLE (information_schema.copy_history(table_name=>'RAW.STAGE_INSOLAR_TS', start_time=>  to_timestamp('"+YEAR+"-"+dt_month+"-"+dt_day+" 00:00:00')))) history ON log.FILE_NAME=history.FILE_NAME WHERE history.error_count > 0"
    });	
    rs =  checkUnloadedFileSql.execute();
	rs.next();
	noOfFilesNotLoaded = rs.getColumnValue(1);
    var listOfFilesNotLoaded = rs.getColumnValue(2);

  	snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"});

    if(noOfFilesNotLoaded > 0){

        throw JSON.stringify({"totalFilesToLoad": noOfFileToLoad,"noOfFilesLoaded":noOfFileToLoad - noOfFilesNotLoaded, "noOfFilesNotLoaded": noOfFilesNotLoaded, "listOfFilesNotLoaded": listOfFilesNotLoaded});
    
    }
    
    return JSON.stringify({"Files copied":noOfFileToLoad});

$$
;





-------Craete PROC_STAGE_TIMESERIES_DAILY_LOAD procedure for daily data load
CREATE OR REPLACE PROCEDURE "RAW"."PROC_STAGE_TIMESERIES_DAILY_LOAD"(YEAR FLOAT,MONTH FLOAT,DAY FLOAT,TOTAL_SITE_GROUPS FLOAT,WHICH_SITE_GROUP FLOAT,PIPELINE_RUN_ID VARCHAR,PIPELINE_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS CALLER 
AS
$$

var dt_month = MONTH.toString().padStart(2,'0');
var dt_day = DAY.toString().padStart(2,'0');

var sites_cmd =
  {
      sqlText: "SELECT array_agg(distinct site_id) FROM REFERENCE.SOURCE_SITES WHERE data_source = 'Insolar' AND  site_key % "+TOTAL_SITE_GROUPS+" = "+WHICH_SITE_GROUP
    }
	var stmt = snowflake.createStatement(sites_cmd);
	var res = stmt.execute();
	
	snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PIPELINE_RUN_ID+"','"+PIPELINE_NAME+"','DailyBlob2Stage'))"});
	snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );

	res.next();
	var SITES = res.getColumnValue(1);

	for (i=0;i<SITES.length;i++) {

		var command = "COPY INTO RAW.STAGE_INSOLAR_TS FROM (SELECT $1 AS PAYLOAD, SYSDATE(), METADATA$FILENAME AS FILENAME,'"+PIPELINE_RUN_ID+"' AS PIPELINE_RUN_ID,TO_DATE(REGEXP_SUBSTR(METADATA$FILENAME,'(\\\\d{4}\/\\\\d{2}\/\\\\d{2})'),'YYYY/MM/DD') AS FILE_ARRIVAL_DATE FROM @RAW.STG_SCADA_TIMESERIES/"+SITES[i]+"/measurement/"+YEAR+"/"+dt_month+"/"+dt_day+") pattern='.*.gzip' on_error=skip_file"

		var sql_command = {sqlText: command};

		snowflake.execute(sql_command);
	}
		
	snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )

	return "Success";   // Return a success/error indicator.
	$$
	; 

   
    
-------Craete PROC_STAGE_TIMESERIES_MONTHLY_LOAD procedure for monthly data load

CREATE OR REPLACE PROCEDURE "RAW"."PROC_STAGE_TIMESERIES_MONTHLY_LOAD"(YEAR FLOAT,MONTH FLOAT,TOTAL_SITE_GROUPS FLOAT,WHICH_SITE_GROUP FLOAT,PIPELINE_RUN_ID VARCHAR,PIPELINE_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS CALLER 
AS
$$

var dt_month = MONTH.toString().padStart(2,'0');
var sites_cmd =
  {
      sqlText: "SELECT array_agg(distinct site_id) FROM REFERENCE.SOURCE_SITES WHERE data_source = 'Insolar' AND  site_key % "+TOTAL_SITE_GROUPS+" = "+WHICH_SITE_GROUP

}
	var stmt = snowflake.createStatement(sites_cmd);
	var res = stmt.execute();

	snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PIPELINE_RUN_ID+"','"+PIPELINE_NAME+"','MonthlyBlob2Stage'))"});
	snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );

	res.next();
	var SITES = res.getColumnValue(1);

	for (i=0;i<SITES.length;i++) {
		var command = "COPY INTO RAW.STAGE_INSOLAR_TS FROM (SELECT $1 AS PAYLOAD, SYSDATE(), METADATA$FILENAME AS FILENAME,'"+PIPELINE_RUN_ID+"' AS PIPELINE_RUN_ID,TO_DATE(REGEXP_SUBSTR(METADATA$FILENAME,'(\\\\d{4}\/\\\\d{2}\/\\\\d{2})'),'YYYY/MM/DD') AS FILE_ARRIVAL_DATE FROM @RAW.STG_SCADA_TIMESERIES/"+SITES[i]+"/measurement/"+YEAR+"/"+dt_month+") pattern='.*.gzip' on_error=skip_file"

		var sql_command = {sqlText: command};

		snowflake.execute(sql_command);
	}

	snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )

	return "Success";   // Return a success/error indicator.
$$
;             
    

    
    
    
------------Create PROC_STAGE_TIMESERIES_YEARLY_LOAD procedure for yearly data load
CREATE OR REPLACE PROCEDURE "RAW"."PROC_STAGE_TIMESERIES_YEARLY_LOAD"(YEAR FLOAT,TOTAL_SITE_GROUPS FLOAT,WHICH_SITE_GROUP FLOAT,PIPELINE_RUN_ID VARCHAR,PIPELINE_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS CALLER 
AS
$$

var sites_cmd =
  {
      sqlText: "SELECT array_agg(distinct site_id) FROM REFERENCE.SOURCE_SITES WHERE data_source = 'Insolar' AND  site_key % "+TOTAL_SITE_GROUPS+" = "+WHICH_SITE_GROUP
    }

	var stmt = snowflake.createStatement(sites_cmd);
	var res = stmt.execute();

	snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PIPELINE_RUN_ID+"','"+PIPELINE_NAME+"','YearlyBlob2Stage'))"});
	snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );

	res.next();
	var SITES = res.getColumnValue(1);

	for (i=0;i<SITES.length;i++) {

		var command = "COPY INTO RAW.STAGE_INSOLAR_TS FROM (SELECT $1 AS PAYLOAD, SYSDATE(), METADATA$FILENAME AS FILENAME,'"+PIPELINE_RUN_ID+"' AS PIPELINE_RUN_ID,TO_DATE(REGEXP_SUBSTR(METADATA$FILENAME,'(\\\\d{4}\/\\\\d{2}\/\\\\d{2})'),'YYYY/MM/DD') AS FILE_ARRIVAL_DATE FROM @RAW.STG_SCADA_TIMESERIES/"+SITES[i]+"/measurement/"+YEAR+") pattern='.*.gzip' on_error=skip_file"

		var sql_command = {sqlText: command};

		snowflake.execute(sql_command);
	}
		
	snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )

	return "Success";   // Return a success/error indicator.

$$
;

 DROP TABLE IF EXISTS "CURATED"."D_SITES";