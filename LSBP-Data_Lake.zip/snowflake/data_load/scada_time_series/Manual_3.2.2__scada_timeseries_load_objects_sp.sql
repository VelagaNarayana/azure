use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

create or replace pipe RAW.PIPE_STAGE_INSOLAR_TS
  auto_ingest = true
  integration = QINT_LSBPDATA_LZ_{{ integration }}
  as
COPY INTO RAW.STAGE_INSOLAR_TS FROM 
(SELECT $1 AS PAYLOAD, SYSDATE() AS LOAD_TS, 
 METADATA$FILENAME AS FILENAME,
CONCAT('snowpipe-',to_varchar(load_ts,'YYYYMMDD-'),to_varchar(time_slice(load_ts, 15, 'MINUTE','START'),'HH24MI-'), to_varchar(time_slice(load_ts, 15, 'MINUTE','END'),'HH24MI') 
) AS PIPELINE_RUN_ID,
 TO_DATE(REGEXP_SUBSTR(METADATA$FILENAME,'(\\d{4}\/\\d{2}\/\\d{2})'),'YYYY/MM/DD') AS FILE_ARRIVAL_DATE 
 FROM @RAW.STG_SCADA_TIMESERIES) pattern='.*.gzip';

CREATE OR REPLACE STREAM "RAW".STRM_STAGE_INSOLAR_TS_FACT_INSOLAR_TS ON TABLE "RAW"."STAGE_INSOLAR_TS" append_only = true;