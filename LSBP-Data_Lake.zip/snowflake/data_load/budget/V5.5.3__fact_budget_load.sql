use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

CREATE OR REPLACE PROCEDURE  "RAW"."PROC_UPSERT_FACT_BUDGETS"(SOURCE_FILE_PATH VARCHAR,SOURCE_FILE_NAME VARCHAR,PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
RETURNS string
LANGUAGE javascript
strict
EXECUTE AS caller 
AS
 $$
   try{
        snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','blob2factTable'))"});
        snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} ); 

	    var rowsInserted=0;
        
        var stmt = snowflake.createStatement({
               sqlText: "INSERT INTO  RAW.FACT_BUDGETS(BUDGET_KEY,SITE_KEY,DATE_MONTH_KEY,BUDGET_IRR,BUDGET_PROD,BUDGET_PR,BUDGET_LOSSES,ORIGINAL_BUDGET_MODEL_NAME,ORIGINAL_YEAR,ORIGINAL_MONTH,PROCESS_EXEC_ID,CREATED_TS,UPDATED_TS,LOAD_FILE) WITH monthly_budget AS ( SELECT common.resolve_unknown_dims(dim.budget_key) as budget_key,common.resolve_unknown_dims(dim.site_key) as site_key,budget.* FROM ( SELECT  $1 AS site_id_formula, $4 as budget_model_name,$5 as budget_category,$7::date as valid_from, $8::date as valid_to, $9 as year, $10 as irr_01,$11 as irr_02,$12 as irr_03,$13 as irr_04,$14 as irr_05,$15 as irr_06,$16 as irr_07,$17 as irr_08,$18 as irr_09,$19 as irr_10,$20 as irr_11,$21 as irr_12, $22 as prod_01,$23 as prod_02,$24 as prod_03,$25 as prod_04,$26 as prod_05,$27 as prod_06,$28 as prod_07,$29 as prod_08,$30 as prod_09,$31 as prod_10,$32 as prod_11,$33 as prod_12, $34 as pr_01,$35 as pr_02,$36 as pr_03,$37 as pr_04,$38 as pr_05,$39 as pr_06,$40 as pr_07,$41 as pr_08,$42 as pr_09,$43 as pr_10,$44 as pr_11,$45 as pr_12,  $46 as losses_01,$47 as losses_02,$48 as losses_03,$49 as losses_04,$50 as losses_05,$51 as losses_06,$52 as losses_07,$53 as losses_08,$54 as losses_09,$55 as losses_10,$56 as losses_11,$57 as losses_12, metadata$filename as load_file FROM @RAW.STG_BUDGET_DATASET/"+SOURCE_FILE_PATH+"/"+SOURCE_FILE_NAME+" WHERE $1 IS NOT NULL AND $4 IS NOT NULL  AND $9 IS NOT NULL ) budget LEFT JOIN CURATED.DIM_BUDGETS dim ON budget.site_id_formula = dim.site_id_formula AND budget.budget_model_name = dim.budget_model_name AND coalesce(budget.budget_category,'') = coalesce(dim.budget_category,'') ) SELECT budget_dataset.budget_key,budget_dataset.site_key,common.resolve_unknown_dims(dim_calender.date_key) as date_month_key,budget_irr,budget_prod,budget_pr,budget_losses,budget_dataset.budget_model_name as original_budget_model_name,budget_dataset.year as original_year,budget_dataset.month_of_year as original_month, ? as process_exec_id, SYSDATE() as created_ts,SYSDATE() as updated_ts,load_file  FROM(  SELECT irr.budget_key,irr.site_key,irr.budget_model_name,irr.year,irr.month_of_year,irr.budget_irr,prod.budget_prod,pr.budget_pr,losses.budget_losses,load_file FROM (  SELECT budget_key,site_key,budget_model_name,year,replace(irr_month,'IRR_','')::integer as month_of_year,budget_irr,load_file FROM  (select * from monthly_budget unpivot(budget_irr for irr_month in ( irr_01,irr_02,irr_03,irr_04,irr_05,irr_06,irr_07,irr_08,irr_09,irr_10,irr_11,irr_12))) )irr LEFT JOIN  (SELECT budget_key,year,replace(prod_month,'PROD_','')::integer as month_of_year,budget_prod FROM  (select * from monthly_budget unpivot(budget_prod for prod_month in (prod_01,prod_02,prod_03,prod_04,prod_05,prod_06,prod_07,prod_08,prod_09,prod_10,prod_11,prod_12))) )prod ON irr.budget_key=prod.budget_key AND irr.year=prod.year AND irr.month_of_year=prod.month_of_year LEFT JOIN  ( SELECT budget_key,year,replace(pr_month,'PR_','')::integer as month_of_year,budget_pr FROM  (select * from monthly_budget unpivot (budget_pr for pr_month in (pr_01,pr_02,pr_03,pr_04,pr_05,pr_06,pr_07,pr_08,pr_09,pr_10,pr_11,pr_12))) )pr  ON irr.budget_key=pr.budget_key AND irr.year=pr.year AND irr.month_of_year=pr.month_of_year LEFT JOIN  (  SELECT budget_key,year,replace(losses_month,'LOSSES_','')::integer as month_of_year,budget_losses FROM  (select * from monthly_budget unpivot(budget_losses for losses_month in (losses_01,losses_02,losses_03,losses_04,losses_05,losses_06,losses_07,losses_08,losses_09,losses_10,losses_11,losses_12))) )losses   ON irr.budget_key=losses.budget_key AND irr.year=losses.year AND irr.month_of_year=losses.month_of_year ) budget_dataset LEFT JOIN (SELECT date_key,year,month FROM CURATED.DIM_CALENDAR_DATE WHERE DAY = 1) dim_calender ON budget_dataset.year =dim_calender.year and budget_dataset.month_of_year=dim_calender.month",
                binds:[PROCESS_RUN_ID]
        });  
        var rsMergeQuery = stmt.execute();
        rsMergeQuery.next();
        var count = {"Inserted":rsMergeQuery.getColumnValue(1)};

        }finally{
            snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
        }

    return JSON.stringify({"Budets":count});
$$
;
