use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER TABLE "RAW"."STAGE_SATELLITE_TS"
ADD COLUMN FILE_DATE DATE NULL;

update "RAW"."STAGE_SATELLITE_TS" set file_date = TO_DATE(REGEXP_SUBSTR (filename,'(\\d{4}\/\\d{2}\/\\d{2})'),'YYYY/MM/DD') where not is_monthly_load;
update "RAW"."STAGE_SATELLITE_TS" set file_date = TO_DATE(REGEXP_SUBSTR (filename,'(\\d{4}\/\\d{2})'),'YYYY/MM') where is_monthly_load;
