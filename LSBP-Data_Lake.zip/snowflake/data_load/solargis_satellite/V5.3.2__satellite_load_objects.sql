use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

alter table raw.stage_satellite_ts
drop column is_monthly_load;

CREATE OR REPLACE PROCEDURE "RAW"."PROC_STAGE_SATELLITE_TS"(SOURCE_PATH VARCHAR, PIPELINE_RUN_ID VARCHAR, PIPELINE_NAME VARCHAR)
    RETURNS string
    LANGUAGE javascript
    strict
    EXECUTE AS CALLER 
    AS
    $$
            
     	snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = '"+PIPELINE_NAME+"~"+PIPELINE_RUN_ID+"';"} ) 

        var insert_stmt = "COPY INTO RAW.STAGE_SATELLITE_TS FROM ( SELECT $1 AS PAYLOAD, METADATA$FILENAME AS FILENAME, SYSDATE() AS LOAD_TS,'"+PIPELINE_RUN_ID+"' AS PROCESS_EXEC_ID, TO_DATE(REGEXP_SUBSTR (METADATA$FILENAME,'(\\\\d{4}\/\\\\d{2}\/\\\\d{2})'),'YYYY/MM/DD') as file_date FROM @RAW.STG_SATELLITE_DATA/"+SOURCE_PATH+") pattern='.*.xml'";
        snowflake.execute({sqlText: insert_stmt});        
        
        
        snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )

        return "Success";   // Return a success/error indicator.
        
        $$
       ;     