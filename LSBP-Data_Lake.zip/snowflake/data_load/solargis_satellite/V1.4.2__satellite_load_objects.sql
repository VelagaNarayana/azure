use database data_lake_{{ env }};
use warehouse DATA_LOAD_{{ env }}_WH;
use role dl_{{ env }}_data_engineers;


---Create file format for Satellite data load 
CREATE FILE FORMAT IF NOT EXISTS "RAW".FF_XML_RAW_SATELLITE
    TYPE = 'XML' COMPRESSION = 'AUTO'
    PRESERVE_SPACE = FALSE
    STRIP_OUTER_ELEMENT = TRUE
    DISABLE_SNOWFLAKE_DATA = FALSE
    DISABLE_AUTO_CONVERT = FALSE
    IGNORE_UTF8_ERRORS = FALSE
    COMMENT = 'File format to parse Satellite xml files';


-----Create stage to load satellite data
CREATE STAGE IF NOT EXISTS  RAW.STG_SATELLITE_DATA
    URL = 'azure://lsbpdata{{ blobsuffix }}.blob.core.windows.net/satellite-landing-zone/'
    STORAGE_INTEGRATION = sint_lsbpdata_lz_{{ env }}
    FILE_FORMAT = "RAW".FF_XML_RAW_SATELLITE
    COMMENT = 'Stage to do load of Satellite data ';



-----Create table to store Satellite stage 
CREATE TABLE IF NOT EXISTS  "RAW"."STAGE_SATELLITE_TS"
       (
        "PAYLOAD" VARIANT NOT NULL,
        "IS_MONTHLY_LOAD" BOOLEAN,
        "FILENAME" STRING NOT NULL,
        "LOAD_TS" TIMESTAMP NOT NULL,
        "PROCESS_EXEC_ID" STRING NOT NULL
       )
       COMMENT = 'Store Satellite stag data';



-----Create procedure to load scada metadata
CREATE OR REPLACE PROCEDURE "RAW"."PROC_STAGE_SATELLITE_TS"(YEARMONTHDAYJSON VARCHAR, PIPELINE_RUN_ID VARCHAR, PIPELINE_NAME VARCHAR)
    RETURNS string
    LANGUAGE javascript
    strict
    EXECUTE AS CALLER 
    AS
    $$
      
       var jsonObj = JSON.parse(YEARMONTHDAYJSON);

     	snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = '"+PIPELINE_NAME+"~"+PIPELINE_RUN_ID+"';"} ) 

        if(jsonObj.year != null && jsonObj.month != null && jsonObj.day != null){
            var insert_stmt = "COPY INTO DATA_LAKE_{{ env }}.RAW.STAGE_SATELLITE_TS FROM ( SELECT $1 AS PAYLOAD, 0 AS IS_MONTHLY_LOAD, METADATA$FILENAME AS FILENAME, SYSDATE() AS LOAD_TS,'"+PIPELINE_RUN_ID+"' AS PROCESS_EXEC_ID FROM @DATA_LAKE_{{ env }}.RAW.STG_SATELLITE_DATA/"+jsonObj.year+"/"+jsonObj.month+"/"+jsonObj.day+") pattern='.*.xml'";
            snowflake.execute({sqlText: insert_stmt});        
        }else if(jsonObj.year != null && jsonObj.month != null && jsonObj.folder != null){                
            var insert_stmt = "COPY INTO DATA_LAKE_{{ env }}.RAW.STAGE_SATELLITE_TS FROM ( SELECT $1 AS PAYLOAD, 1 AS IS_MONTHLY_LOAD, METADATA$FILENAME AS FILENAME, SYSDATE() AS LOAD_TS,'"+PIPELINE_RUN_ID+"' AS PROCESS_EXEC_ID FROM @DATA_LAKE_{{ env }}.RAW.STG_SATELLITE_DATA/"+jsonObj.year+"/"+jsonObj.month+"/"+jsonObj.folder+") pattern='.*.xml'";
            snowflake.execute({sqlText: insert_stmt});
        }else{        
            return "Invalid JSON passed in procedure";
        }
        
        snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )

        return "Success";   // Return a success/error indicator.
        
        $$
       ;       
