use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

CREATE OR REPLACE FILE FORMAT "RAW".FF_JS_METEO_CONTROL 
    TYPE = 'JSON' 
    COMPRESSION = 'AUTO' 
    ENABLE_OCTAL = FALSE 
    ALLOW_DUPLICATE = FALSE 
    STRIP_OUTER_ARRAY = FALSE 
    STRIP_NULL_VALUES = FALSE 
    IGNORE_UTF8_ERRORS = FALSE 
    COMMENT = 'File format to read all files for meteo control from blob ';



-- Create Stage for timeseries data load 
CREATE OR REPLACE STAGE "RAW".STG_METEO_CONTROL_METADATA
	URL = 'azure://lsbpdata{{ blobsuffix }}.blob.core.windows.net/meteocontrol-landing-zone/metadata/' 
	STORAGE_INTEGRATION = sint_lsbpdata_lz_{{ integration }}
	FILE_FORMAT = "RAW".FF_JS_METEO_CONTROL 
	COMMENT = 'Stage to do read meteo control files from blob ';