use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

CREATE OR REPLACE FILE FORMAT "RAW".FF_CSV_METEO_CONTROL 
    TYPE = 'CSV' 
    COMPRESSION = 'AUTO' 
    FIELD_DELIMITER = '%$' 
    RECORD_DELIMITER = '\n' 
    SKIP_HEADER = 0 
    FIELD_OPTIONALLY_ENCLOSED_BY = 'NONE' 
    TRIM_SPACE = TRUE 
    ERROR_ON_COLUMN_COUNT_MISMATCH = TRUE 
    ESCAPE = 'NONE' 
    ESCAPE_UNENCLOSED_FIELD = '\134' 
    DATE_FORMAT = 'AUTO' 
    TIMESTAMP_FORMAT = 'AUTO' 
    NULL_IF = ('\\N') 
    COMMENT = 'File format to read  Meteo Control timeseries data';


CREATE OR REPLACE STAGE "RAW".STG_METEO_CONROL_TIMESERIES_DATA
	URL = 'azure://lsbpdata{{ blobsuffix }}.blob.core.windows.net/meteocontrol-landing-zone/timeseries' 
	STORAGE_INTEGRATION = sint_lsbpdata_lz_{{ integration }}
	FILE_FORMAT = "RAW".FF_CSV_METEO_CONTROL
	COMMENT = 'Stage to do read timeseries meteo control';