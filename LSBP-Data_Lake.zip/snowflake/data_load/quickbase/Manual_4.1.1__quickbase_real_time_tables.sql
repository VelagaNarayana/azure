
use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

insert into "CONTROL"."QUICKBASE_LOAD" values ('bq8z2rija', 'Test table','REFERENCE','QB_TEST_WEBHOOKS',false);

create or replace table REFERENCE.qb_test_webhooks(
    record_id integer comment 'TO_NUMBER(GET( rec.value, ''@rid'' )::string)',
    order_num integer comment 'TRY_TO_NUMBER(XMLGET( rec.value, ''order'' ):"$"::string)' , 
    topic varchar(3000) comment 'XMLGET( rec.value, ''topic'' ):"$"::string' , 
    fact varchar comment 'XMLGET( rec.value, ''fact'' ):"$"::string' , 
    text_length integer comment 'TO_NUMBER(XMLGET( rec.value, ''text_length'' ):"$"::string)',
	last_modified_by varchar(1000) comment 'COMMON.REPLACE_HTML(regexp_substr(XMLGET( rec.value, ''last_modified_by'' )::string,''<last_modified_by>(.*)</last_modified_by>'',1, 1,''e'',1))' , 
    process_exec_id varchar(100),
    load_ts datetime default sysdate(),	
    load_file varchar(100),
	updated_ts datetime default sysdate()
 );