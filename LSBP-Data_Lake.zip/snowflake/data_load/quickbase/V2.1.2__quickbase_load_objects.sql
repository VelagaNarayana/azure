use database data_lake_{{ env }};
use warehouse DATA_LOAD_{{ env }}_WH;
use role dl_{{ env }}_data_engineers;

CREATE FILE FORMAT "REFERENCE".FF_XML_REF_QUICKBASE 
TYPE = 'XML' COMPRESSION = 'AUTO' 
PRESERVE_SPACE = FALSE 
STRIP_OUTER_ELEMENT = FALSE 
DISABLE_SNOWFLAKE_DATA = FALSE 
DISABLE_AUTO_CONVERT = FALSE 
IGNORE_UTF8_ERRORS = FALSE 
COMMENT = 'Format to parse XML Quickbase data';        

CREATE OR REPLACE STAGE "REFERENCE"."STG_QUICKBASE_DATA"
	URL = 'azure://lsbpdata{{ blobsuffix }}.blob.core.windows.net/quickbase-landing-zone/' 
	STORAGE_INTEGRATION = sint_lsbpdata_lz_{{ env }}
	FILE_FORMAT = "REFERENCE".FF_XML_REF_QUICKBASE
	COMMENT = 'Stage to load Quickbase files'; 

--DROP PROCEDURE "REFERENCE"."PROC_LOAD_QB_DATA"( VARCHAR,  VARCHAR,  VARCHAR,  VARCHAR,  VARCHAR)

CREATE OR REPLACE PROCEDURE "REFERENCE"."PROC_LOAD_QB_DATA"(FILE VARCHAR, TARGET_SCHEMA VARCHAR, TARGET_TBL VARCHAR, PIPELINE_RUN_ID VARCHAR, PIPELINE_NAME VARCHAR)
    RETURNS string
    LANGUAGE javascript
    strict
    EXECUTE AS CALLER 
    AS
    $$             
        var cols_command = "select listagg(column_name,',') WITHIN GROUP ( order by ordinal_position ),listagg(concat(comment,' as ',column_name),', ') WITHIN GROUP ( order by ordinal_position ) from INFORMATION_SCHEMA.COLUMNS where table_schema='"+TARGET_SCHEMA+"' and table_name='"+TARGET_TBL+"' and comment is not null;"
        var sql_command = {sqlText: cols_command};
        var stmt = snowflake.createStatement(sql_command);
        var res = stmt.execute();
        res.next();
        var TARGET_COLS = res.getColumnValue(1);
        var PARSE_COLS = res.getColumnValue(2);
                   
        snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = '"+PIPELINE_NAME+"~"+PIPELINE_RUN_ID+"';"} ) 
        snowflake.execute( {sqlText: "BEGIN WORK;"} ); 
        try{        
          
           snowflake.execute( {sqlText: "DELETE FROM "+TARGET_SCHEMA+"."+TARGET_TBL+";"} );
           var load_command = "insert into "+TARGET_SCHEMA+"."+TARGET_TBL+"("+TARGET_COLS+",PROCESS_EXEC_ID,LOAD_TS, LOAD_FILE) select "+PARSE_COLS+",'"+PIPELINE_RUN_ID+"' AS PROCESS_EXEC_ID, SYSDATE() AS LOAD_TS, METADATA$FILENAME AS LOAD_FILE from '@DATA_LAKE_{{ env }}.REFERENCE.STG_QUICKBASE_DATA\/"+FILE+"' nxml ,lateral FLATTEN(nxml.$1:\"$\") rec where GET(rec.value, '@') = 'record'  ;"
          sql_command = {sqlText: load_command};

          snowflake.execute(sql_command);
          snowflake.execute( {sqlText: "COMMIT WORK;"} );
        }
        catch(err){
            snowflake.execute( {sqlText: "ROLLBACK WORK;"} );
            throw err;
        }
        finally{
            snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
        }
                
        return "Success";
        
    $$
    
  
 
 
        