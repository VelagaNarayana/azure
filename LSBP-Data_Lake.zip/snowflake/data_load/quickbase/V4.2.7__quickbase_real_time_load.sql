use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

DROP PROCEDURE IF EXISTS "REFERENCE"."PROC_LOAD_QB_REAL_TIME_DATA"(VARCHAR, VARCHAR, VARCHAR);

CREATE OR REPLACE PROCEDURE "REFERENCE"."PROC_LOAD_QB_REAL_TIME_DATA"(CHANGED_XML_DOC VARCHAR, REQUEST_RECEIVED_TS VARCHAR, PIPELINE_RUN_ID VARCHAR, PIPELINE_NAME VARCHAR)
    RETURNS string
    LANGUAGE javascript
    strict
    EXECUTE AS CALLER 
    AS
    $$
        snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PIPELINE_RUN_ID+"','"+PIPELINE_NAME+"','doc2stage'))"});
        snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );  
        try{                  
           
           var load_command = "insert into reference.qb_real_time_change_history(qb_table_code, change_action, webhook_details, table_details, xml_record, process_exec_id, created_ts ) select  XMLGET(XMLGET(changed_doc.payload,'table'),'qb_table_id'):\"$\"::string as qb_table_code, XMLGET(XMLGET(changed_doc.payload,'table'),'action'):\"$\"::string as change_action, XMLGET(changed_doc.payload,'webhook') as webhook_details, XMLGET(changed_doc.payload,'table') as table_details, XMLGET(changed_doc.payload,'record') as xml_record,? as process_exec_id, to_timestamp(?) as created_ts  from (select parse_xml(?) as payload) changed_doc;"
           sql_command = {sqlText: load_command, binds:[PIPELINE_RUN_ID,REQUEST_RECEIVED_TS,CHANGED_XML_DOC]};
           snowflake.execute(sql_command);

        }       
        finally{
            snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
        }
        return "Record inserted into history table."
    $$;

    CREATE OR REPLACE PROCEDURE "REFERENCE"."PROC_APPLY_QB_REAL_TIME_CHANGES"(PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
    RETURNS string
    LANGUAGE javascript
    strict
    EXECUTE AS CALLER 
    AS
    $$
        snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','stage2ref'))"});
        snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );
        
        var stmt0 = snowflake.createStatement({
                       sqlText: "select qb_table_code, change_action,created_ts from reference.qb_real_time_change_history where process_exec_id=?",
                       binds:[PROCESS_RUN_ID]
                   });  
        var rs0 = stmt0.execute();
        var cnt = stmt0.getRowCount();
        if(cnt == 1){
            
            rs0.next();
            
            var LOAD_FILE='Webhook';
            var qbTblCode = rs0.getColumnValue(1);
            var qbAction = rs0.getColumnValue(2);
            
            var colsCmd = "select table_schema,table_name,listagg(column_name,',') WITHIN GROUP ( order by ordinal_position ),listagg(comment,', ') WITHIN GROUP ( order by ordinal_position ),listagg(concat('old.',column_name,' = ',comment),', ') WITHIN GROUP ( order by ordinal_position ) from INFORMATION_SCHEMA.COLUMNS where (table_schema,table_name) in (select sf_schema,sf_table_name from control.quickbase_load where qb_table_code='"+qbTblCode+"') and comment is not null  group by table_name, table_schema;"
            var sqlCmd = {sqlText: colsCmd};
            var stmt1 = snowflake.createStatement(sqlCmd);
            var rs1 = stmt1.execute();
            rs1.next();
            var targetColsIns = rs1.getColumnValue(3)+",PROCESS_EXEC_ID, LOAD_TS,UPDATED_TS, LOAD_FILE";
            var parseColsIns = rs1.getColumnValue(4)+",? , rec.created_ts,rec.created_ts, ?";
            var colsUpd = rs1.getColumnValue(5)+", old.updated_ts=rec.created_ts, old.process_exec_id=?, old.load_file=?";
            var targetTable = rs1.getColumnValue(2);
            var targetSchema = rs1.getColumnValue(1);
            
            if(qbAction.toLowerCase()==="add" || qbAction.toLowerCase()==="replace") {
                var loadCmd = "merge into "+targetSchema+"."+targetTable+" old using (select xml_record as value , created_ts, change_action from reference.qb_real_time_change_history where process_exec_id=?) rec on old.record_id = TO_NUMBER(GET( rec.value, '@rid' )::string) when matched and rec.created_ts >= old.updated_ts then update set "+colsUpd+" when not matched then insert ("+targetColsIns+") values("+parseColsIns+")",
                sqlCmd = {sqlText: loadCmd, binds:[PROCESS_RUN_ID, PROCESS_RUN_ID, LOAD_FILE, PROCESS_RUN_ID, LOAD_FILE]};
                stmt1 = snowflake.createStatement(sqlCmd);
                rs1 = stmt1.execute();
                rs1.next();                
                return JSON.stringify({"Inserted":rs1.getColumnValue(1),"Updated":rs1.getColumnValue(2)});                       
            }else if(qbAction.toLowerCase()==="delete") {
            
                var delCmd = "delete from "+targetSchema+"."+targetTable+" where record_id in (select TO_NUMBER(GET( xml_record, '@rid' )::string) from reference.qb_real_time_change_history where process_exec_id=?)";
                sqlCmd = {sqlText: delCmd, binds:[PROCESS_RUN_ID]};
                stmt1 = snowflake.createStatement(sqlCmd);
                rs1 = stmt1.execute();
                rs1.next();                
                return JSON.stringify({"Deleted":rs1.getColumnValue(1)});
            
            } else {
                throw new Error('Unknown change option - '+qbAction);
            }
 
            
        } else {
            throw new Error('Cannot apply changes with more than 1 record.Actual records found - '+cnt);
        } 

    $$;