use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

DROP PROCEDURE IF EXISTS "REFERENCE"."PROC_LOAD_QB_DATA"( VARCHAR,  VARCHAR,  VARCHAR,  VARCHAR,  VARCHAR);

CREATE OR REPLACE PROCEDURE "REFERENCE"."PROC_LOAD_QB_DATA"(FILE VARCHAR, TARGET_SCHEMA VARCHAR, TARGET_TBL VARCHAR, PIPELINE_RUN_ID VARCHAR, PIPELINE_NAME VARCHAR, FULL_RELOAD BOOLEAN)
    RETURNS string
    LANGUAGE javascript
    strict
    EXECUTE AS CALLER 
    AS
    $$             
        var cols_command = "select listagg(column_name,',') WITHIN GROUP ( order by ordinal_position ),listagg(concat(comment,' as ',column_name),', ') WITHIN GROUP ( order by ordinal_position ) from INFORMATION_SCHEMA.COLUMNS where table_schema='"+TARGET_SCHEMA+"' and table_name='"+TARGET_TBL+"' and comment is not null;"
        var sql_command = {sqlText: cols_command};
        var stmt = snowflake.createStatement(sql_command);
        var res = stmt.execute();
        res.next();
        var TARGET_COLS = res.getColumnValue(1)+",PROCESS_EXEC_ID,LOAD_FILE";
        var PARSE_COLS = res.getColumnValue(2)+",'"+PIPELINE_RUN_ID+"' AS PROCESS_EXEC_ID, METADATA$FILENAME AS LOAD_FILE";
        var TEMP_TABLE = "common.\"TMP_REF_QB_"+PIPELINE_RUN_ID+"\"";
                   
        snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = '"+PIPELINE_NAME+"~"+PIPELINE_RUN_ID+"';"} ) 
        snowflake.execute( {sqlText: "BEGIN WORK;"} ); 
        var count = 0;
        try{        
        
           var tempTableQuery = "create or replace temporary table "+TEMP_TABLE+" as select "+PARSE_COLS+" from '@REFERENCE.STG_QUICKBASE_DATA\/"+FILE+"' nxml ,lateral FLATTEN(nxml.$1:\"$\") rec where GET(rec.value, '@') = 'record'  ;"
           snowflake.execute( {sqlText:tempTableQuery} ); 
          
           var delQuery= "DELETE FROM "+TARGET_SCHEMA+"."+TARGET_TBL;
           if(!FULL_RELOAD){
               delQuery+=" where record_id in (select distinct record_id from "+TEMP_TABLE+");"
           }
           snowflake.execute( {sqlText:delQuery} );
           var load_command = "insert into "+TARGET_SCHEMA+"."+TARGET_TBL+"("+TARGET_COLS+") select "+TARGET_COLS+" from "+TEMP_TABLE;
           var stmt = snowflake.createStatement({
               sqlText: load_command
           });  
          var rs = stmt.execute();
          rs.next();
          count = {"Inserted":rs.getColumnValue(1)};         
          snowflake.execute( {sqlText: "COMMIT WORK;"} );
          
        }
        catch(err){
            snowflake.execute( {sqlText: "ROLLBACK WORK;"} );
            throw err;
        }
        finally{
            snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
        }
                
         return JSON.stringify({ "Records inserted" : count});
   
    $$;