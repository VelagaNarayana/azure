use database data_lake_{{ db }};
use warehouse DATA_LOAD_{{ wh }}_WH;
use role dl_{{ role }}_data_engineers;

ALTER SESSION SET QUERY_TAG='DevOps~Schemachange';

 create or replace table reference.qb_real_time_change_history (
    qb_table_code varchar(50),
    change_action varchar(25),
    webhook_details variant,
    table_details variant,
    xml_record variant,
    created_ts datetime,    
    process_exec_id varchar(200)
 ) cluster by (qb_table_code,to_date(created_ts));

 CREATE OR REPLACE PROCEDURE "REFERENCE"."PROC_LOAD_QB_REAL_TIME_DATA"(CHANGED_XML_DOC VARCHAR, PIPELINE_RUN_ID VARCHAR, PIPELINE_NAME VARCHAR)
    RETURNS string
    LANGUAGE javascript
    strict
    EXECUTE AS CALLER 
    AS
    $$
        snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PIPELINE_RUN_ID+"','"+PIPELINE_NAME+"','doc2stage'))"});
        snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );  
        try{                  
           
           var load_command = "insert into reference.qb_real_time_change_history(qb_table_code, change_action, webhook_details, table_details, xml_record, process_exec_id, created_ts ) select  XMLGET(XMLGET(changed_doc.payload,'table'),'qb_table_id'):\"$\"::string as qb_table_code, XMLGET(XMLGET(changed_doc.payload,'table'),'action'):\"$\"::string as change_action, XMLGET(changed_doc.payload,'webhook') as webhook_details, XMLGET(changed_doc.payload,'table') as table_details, XMLGET(changed_doc.payload,'record') as xml_record,? as process_exec_id, sysdate() as created_ts  from (select parse_xml(?) as payload) changed_doc;"
           sql_command = {sqlText: load_command, binds:[PIPELINE_RUN_ID,CHANGED_XML_DOC]};
           snowflake.execute(sql_command);

        }       
        finally{
            snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
        }
        return "Record inserted into history table."
    $$;

    CREATE OR REPLACE PROCEDURE "REFERENCE"."PROC_APPLY_QB_REAL_TIME_CHANGES"(PROCESS_RUN_ID VARCHAR, PROCESS_NAME VARCHAR)
    RETURNS string
    LANGUAGE javascript
    strict
    EXECUTE AS CALLER 
    AS
    $$
        snowflake.execute({sqlText: "set qtag = (select COMMON.GET_QUERY_TAG('"+PROCESS_RUN_ID+"','"+PROCESS_NAME+"','stage2ref'))"});
        snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = $qtag;"} );
        
        var stmt0 = snowflake.createStatement({
                       sqlText: "select qb_table_code, change_action,created_ts from reference.qb_real_time_change_history where process_exec_id=?",
                       binds:[PROCESS_RUN_ID]
                   });  
        var rs0 = stmt0.execute();
        var cnt = stmt0.getRowCount();
        if(cnt == 1){
            
            rs0.next();
            
            var TARGET_SCHEMA="REFERENCE";
            var LOAD_FILE='Webhook';
            var qbTblCode = rs0.getColumnValue(1);
            var qbAction = rs0.getColumnValue(2);
            
            var colsCmd = "select table_name,listagg(column_name,',') WITHIN GROUP ( order by ordinal_position ),listagg(comment,', ') WITHIN GROUP ( order by ordinal_position ),listagg(concat('old.',column_name,' = ',comment),', ') WITHIN GROUP ( order by ordinal_position ) from INFORMATION_SCHEMA.COLUMNS where table_schema='"+TARGET_SCHEMA+"' and table_name=(select table_name from information_schema.tables where comment='"+qbTblCode+"') and comment is not null  group by table_name;"
            var sqlCmd = {sqlText: colsCmd};
            var stmt1 = snowflake.createStatement(sqlCmd);
            var rs1 = stmt1.execute();
            rs1.next();
            var targetColsIns = rs1.getColumnValue(2)+",PROCESS_EXEC_ID, LOAD_TS,UPDATED_TS, LOAD_FILE";
            var parseColsIns = rs1.getColumnValue(3)+",? , sysdate(),sysdate(), ?";
            var colsUpd = rs1.getColumnValue(4)+", old.updated_ts=sysdate(), old.process_exec_id=?, old.load_file=?";
            var targetTable = rs1.getColumnValue(1);
            
            if(qbAction.toLowerCase()==="add"){
                var loadCmd = "insert into "+TARGET_SCHEMA+"."+targetTable+"("+targetColsIns+") select "+parseColsIns+" from (select xml_record as value from reference.qb_real_time_change_history where process_exec_id=?) rec"
                sqlCmd = {sqlText: loadCmd, binds:[PROCESS_RUN_ID, LOAD_FILE, PROCESS_RUN_ID]};
                stmt1 = snowflake.createStatement(sqlCmd);
                rs1 = stmt1.execute();
                rs1.next();
                return JSON.stringify({ "Inserted" : rs1.getColumnValue(1)});
            
            }else if(qbAction.toLowerCase()==="replace") {
                var loadCmd = "merge into "+TARGET_SCHEMA+"."+targetTable+" old using (select xml_record as value from reference.qb_real_time_change_history where process_exec_id=?) rec on old.record_id = TO_NUMBER(GET( rec.value, '@rid' )::string) when matched then update set "+colsUpd+" when not matched then insert ("+targetColsIns+") values("+parseColsIns+")",
                sqlCmd = {sqlText: loadCmd, binds:[PROCESS_RUN_ID, PROCESS_RUN_ID, LOAD_FILE, PROCESS_RUN_ID, LOAD_FILE]};
                stmt1 = snowflake.createStatement(sqlCmd);
                rs1 = stmt1.execute();
                rs1.next();                
                return JSON.stringify({"Inserted":rs1.getColumnValue(1),"Updated":rs1.getColumnValue(2)});                       
            }else if(qbAction.toLowerCase()==="delete") {
            
                var delCmd = "delete from "+TARGET_SCHEMA+"."+targetTable+" where record_id in (select TO_NUMBER(GET( xml_record, '@rid' )::string) from reference.qb_real_time_change_history where process_exec_id=?)";
                sqlCmd = {sqlText: delCmd, binds:[PROCESS_RUN_ID]};
                stmt1 = snowflake.createStatement(sqlCmd);
                rs1 = stmt1.execute();
                rs1.next();                
                return JSON.stringify({"Deleted":rs1.getColumnValue(1)});
            
            } else {
                throw new Error('Unknown change option - '+qbAction);
            }
 
            
        } else {
            throw new Error('Cannot apply changes with more than 1 record.Actual records found - '+cnt);
        } 

    $$;

    CREATE OR REPLACE PROCEDURE "REFERENCE"."PROC_LOAD_QB_DATA"(FILE VARCHAR, TARGET_SCHEMA VARCHAR, TARGET_TBL VARCHAR, PIPELINE_RUN_ID VARCHAR, PIPELINE_NAME VARCHAR, FULL_RELOAD BOOLEAN)
    RETURNS string
    LANGUAGE javascript
    strict
    EXECUTE AS CALLER 
    AS
    $$             
        var cols_command = "select listagg(column_name,',') WITHIN GROUP ( order by ordinal_position ),listagg(concat(comment,' as ',column_name),', ') WITHIN GROUP ( order by ordinal_position ) from INFORMATION_SCHEMA.COLUMNS where table_schema='"+TARGET_SCHEMA+"' and table_name='"+TARGET_TBL+"' and comment is not null;"
        var sql_command = {sqlText: cols_command};
        var stmt = snowflake.createStatement(sql_command);
        var res = stmt.execute();
        res.next();
        var TARGET_COLS = res.getColumnValue(1)+",PROCESS_EXEC_ID,LOAD_TS, UPDATED_TS, LOAD_FILE";
        var PARSE_COLS = res.getColumnValue(2)+",'"+PIPELINE_RUN_ID+"' AS PROCESS_EXEC_ID, SYSDATE() AS LOAD_TS, LOAD_TS AS UPDATED_TS, METADATA$FILENAME AS LOAD_FILE";
        var TEMP_TABLE = "common.\"TMP_REF_QB_"+PIPELINE_RUN_ID+"\"";
                   
        snowflake.execute( {sqlText: "ALTER SESSION SET QUERY_TAG = '"+PIPELINE_NAME+"~"+PIPELINE_RUN_ID+"';"} ) 
        snowflake.execute( {sqlText: "BEGIN WORK;"} ); 
        var count = 0;
        try{        
        
           var tempTableQuery = "create or replace temporary table "+TEMP_TABLE+" as select "+PARSE_COLS+" from '@REFERENCE.STG_QUICKBASE_DATA\/"+FILE+"' nxml ,lateral FLATTEN(nxml.$1:\"$\") rec where GET(rec.value, '@') = 'record'  ;"
           snowflake.execute( {sqlText:tempTableQuery} ); 
          
           var delQuery= "DELETE FROM "+TARGET_SCHEMA+"."+TARGET_TBL;
           if(!FULL_RELOAD){
               delQuery+=" where record_id in (select distinct record_id from "+TEMP_TABLE+");"
           }
           snowflake.execute( {sqlText:delQuery} );
           var load_command = "insert into "+TARGET_SCHEMA+"."+TARGET_TBL+"("+TARGET_COLS+") select "+TARGET_COLS+" from "+TEMP_TABLE;
           var stmt = snowflake.createStatement({
               sqlText: load_command
           });  
          var rs = stmt.execute();
          rs.next();
          count = {"Inserted":rs.getColumnValue(1)};         
          snowflake.execute( {sqlText: "COMMIT WORK;"} );
          
        }
        catch(err){
            snowflake.execute( {sqlText: "ROLLBACK WORK;"} );
            throw err;
        }
        finally{
            snowflake.execute( {sqlText: "ALTER SESSION UNSET QUERY_TAG;"} )
        }
                
         return JSON.stringify({ "Records inserted" : count});
        
          
        
    $$;

    