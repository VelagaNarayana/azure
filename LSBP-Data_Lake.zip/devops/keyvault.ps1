﻿$rg = "data_lake_rg_"+${env:ENV}
$name = "dl-kv-"+${env:ENV}

$check = Get-AzKeyVault -ResourceGroupName $rg -Name $name -ErrorAction SilentlyContinue

if ( $check -eq $null )
{
    New-AzKeyVault -Name $name -ResourceGroupName $rg -Location "UK South" -EnabledForDeployment -EnabledForTemplateDeployment -EnableRbacAuthorization -Sku Standard -Tags @{Environment="LSBP_"+${env:ENV}.ToUpper()}
}
else
{
    echo " Keyvault $name already exits"
}