﻿$rg = "data_lake_rg_"+${env:ENV}
$name = "lsbpdata"+${env:ENV}

$check = Get-AzStorageAccount -ResourceGroupName $rg -Name $name -ErrorAction SilentlyContinue

if ( $check -eq $null )
{
    New-AzStorageAccount -ResourceGroupName $rg -Name $name -Location "UK South" -SkuName "Standard_RAGRS" -Kind StorageV2 -EnableHierarchicalNamespace $true -AllowBlobPublicAccess $true -MinimumTlsVersion TLS1_2 -Tags @{Environment="LSBP_"+${env:ENV}.ToUpper()}
    New-AzRmStorageContainer -ResourceGroupName $rg -StorageAccountName $name -Name "inaccess-landing-zone" -PublicAccess None 
    New-AzRmStorageContainer -ResourceGroupName $rg -StorageAccountName $name -Name "stark-landing-zone" -PublicAccess None 
    New-AzRmStorageContainer -ResourceGroupName $rg -StorageAccountName $name -Name "upl-landing-zone" -PublicAccess None
    New-AzRmStorageContainer -ResourceGroupName $rg -StorageAccountName $name -Name "quickbase-landing-zone" -PublicAccess None
    New-AzRmStorageContainer -ResourceGroupName $rg -StorageAccountName $name -Name "satellite-landing-zone" -PublicAccess None
}
else
{
    echo " Storage account $name already exits"
}