﻿$rg = "data_lake_rg_"+${env:ENV}
$name = "dl-df-"+${env:ENV}

$check = Get-AzDataFactoryV2 -ResourceGroupName $rg -Name $name -ErrorAction SilentlyContinue

if ( $check -eq $null )
{
    Set-AzDataFactoryV2 -ResourceGroupName $rg -Name $name -Location "Uk South" -AccountName "lsbp-data" -ProjectName "LSBP-Data_Lake" -RepositoryName $name -CollaborationBranch "main" -RootFolder "/" -Tag @{Environment="LSBP_"+${env:ENV}.ToUpper()} -Force
}
else 
{
    echo " Data Factory $name already exits"
}