﻿$rg = "data_lake_rg_"+${env:ENV}
$name = "dl-func-"+${env:ENV}
$storage = "lsbpdata"+${env:ENV}

$check = Get-AzFunctionApp -ResourceGroupName $rg -Name $name -ErrorAction SilentlyContinue

if ( $check -eq $null )
{
    New-AzFunctionApp -ResourceGroupName $rg -Name $name -Location "UK South" -DisableApplicationInsights -RuntimeVersion 12 -OSType Windows -Runtime Node -StorageAccountName $storage -Tag @{Environment="LSBP_"+${env:ENV}.ToUpper()}  
}
else
{
    echo " Function App  $name already exits"
}