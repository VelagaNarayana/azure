var storage = require('azure-storage');
const { DefaultAzureCredential  }= require("@azure/identity"); //https://www.npmjs.com/package/@azure/identity
const appConfig = require("@azure/app-configuration"); //https://www.npmjs.com/package/@azure/app-configuration
const { SecretClient } = require("@azure/keyvault-secrets");

const azCredential = new DefaultAzureCredential();

let blobService = null;  //cache the connection 
let appConfigInfo = null; //Caches the configuration

/**
 * Retreives the application configuration from Azure config
 */
 function getApplicationConfigurationForBlob(context) {
  
  const appConfigURI = process.env["APP_CONFIG_URI"];
  const env = process.env["APP_ENV"]
  const appConfigClient = new appConfig.AppConfigurationClient(appConfigURI);

  if(appConfigInfo != null) {
      return new Promise(function(resolve, reject) {
          resolve(appConfigInfo);
      });
  } 

  context.log('Getting application context ...');
  return Promise.all([
      appConfigClient.getConfigurationSetting( {key : 'AZ_STORAGE_ACCOUNT',label:env})
      , appConfigClient.getConfigurationSetting({key : 'AZ_KEY_STORAGE_ACCESS',label:env}) 
  ]).then( (appConfigSettings) => {
      appConfigInfo = {};

     // console.log(appConfigSettings);
      appConfigSettings.forEach(e => {
         // console.log(` Setting ${e.key} ... `);
          appConfigInfo[e.key] = e.value;
      })
      
      return appConfigInfo;
  })/*.catch((error) => {
      context.log(error)
      context.res = {
        status: 500,
        body: error
    };
    context.done

  });*/

}

function initBlobService() {

      if(typeof blobService == 'undefined'  || blobService == null) {
        console.log(appConfigInfo["AZ_STORAGE_ACCOUNT"])
        blobService = storage.createBlobService(appConfigInfo["AZ_STORAGE_ACCOUNT"],appConfigInfo["AZ_KEY_STORAGE_ACCESS"]);
      }
}

  const downloadBlob = async (containerName, blobName) => {
    return new Promise((resolve, reject) => {
        blobService.getBlobToText(containerName, blobName, (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve({ message: `Blob downloaded "${data}"`, text: data });
            }
        });
    });
};

const createBlob = async(container, blob, content) => {
  return new Promise((resolve, reject) => {
    blobService.createBlockBlobFromText(container,blob,content,(err,result)=>{
        if (err) {
          reject(err);
      } else {
          resolve({ message: `Blob created "${result}"`,path:blob});
      }
    });
  });
};

async function splitFile(container, folder, file, context) {

  const inputPath = folder+"/"+file;
  context.log("Input path - "+inputPath);

  const blobDataPromise = await  downloadBlob(container, inputPath);    

    var blobContent = blobDataPromise.text;
    const inputJson = JSON.parse(blobContent);
  
    const outputFolder = "_Split_"+folder
    var splitJson = []
    var outputFiles = []
    var total = 0
    var cnt = 0
    var filenum=0
    for (var key in inputJson) {
          cnt ++;
          total ++;
          splitJson.push({source_file:inputPath, device_key:key,device_value:inputJson[key]})
          if(cnt == 1000){
            filenum++;          
            console.log (cnt + " " + filenum)
            const outputFile = "_split"+filenum+"_"+file
            outputFiles.push(outputFile)
            const outputJson = JSON.stringify(splitJson)
            const blobCreated = await createBlob(container,outputFolder+"/"+outputFile,outputJson);
            splitJson = []
            cnt = 0
          }
  
        }
  
        if(cnt < 1000){
          filenum++;          
          console.log (cnt + " " + filenum)
          const outputFile = "_split"+filenum+"_"+file
          outputFiles.push(outputFile)
          const outputJson = JSON.stringify(splitJson)
          const outputPath = outputFolder+"/"+outputFile;
          const blobCreated = await createBlob(container,outputPath,outputJson);
          splitJson = []
          cnt = 0
        }
  
        context.res = {
           status: 200,
          body: {folder:outputFolder, files:outputFiles, records:total}  
        };  
        context.done();

}

  
module.exports = async function (context, req) {

  if(!(req.body.folder && req.body.file &&  req.body.container)) {
    context.res = {
        status: 400,
        body: {"error":"Please provide container, folder and file names"}
    };
    context.done();
    return {};
}

const container = req.body.container;
  const folder = req.body.folder;
  const file = req.body.file;
  
  try{
  await  getApplicationConfigurationForBlob(context);
  initBlobService();
  await splitFile(container,folder,file,context)
  }catch(err) {
    context.res = {
      status: 500,
      body: {"error":err}
  };
  }


  

       
  
        
      



  

           
  
}