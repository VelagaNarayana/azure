const { DefaultAzureCredential  }= require("@azure/identity"); //https://www.npmjs.com/package/@azure/identity
const appConfig = require("@azure/app-configuration"); //https://www.npmjs.com/package/@azure/app-configuration
const { SecretClient } = require("@azure/keyvault-secrets"); //https://www.npmjs.com/package/@azure/keyvault-secrets

var snowflake = require('snowflake-sdk');
const { 
    v1: uuidv1,
    v4: uuidv4,
  } = require('uuid');
  

const azCredential = new DefaultAzureCredential();

/**
 * Holds the connection and caches it. Subsequent call can use reuse the 
 * connection to speed up the process.
 */
 let connection = null;  //cache the connection 
 let appConfigInfo = null; //Caches the configuration

 /**
 * Retreives the application configuration from Azure config
 */
function getApplicationConfigurationForSnowflake(context) {

    const appConfigURI = process.env["APP_CONFIG_URI"];
    const env = process.env["APP_ENV"];
    const appConfigClient = new appConfig.AppConfigurationClient(appConfigURI);

    if(appConfigInfo != null) {
        return new Promise(function(resolve, reject) {
            resolve(appConfigInfo);
        });
    } 

    context.log('Getting application context ...');
    return Promise.all([
        appConfigClient.getConfigurationSetting( {key : 'SNOWFLAKE_ACCOUNT'})
        , appConfigClient.getConfigurationSetting({key : 'SNOWFLAKE_ROLE' , label:env})
        , appConfigClient.getConfigurationSetting({key : 'SNOWFLAKE_WH', label: env})
        , appConfigClient.getConfigurationSetting({key : 'SNOWFLAKE_USER', label:env })
        , appConfigClient.getConfigurationSetting({key : 'SNOWFLAKE_PASSWD', label:env })
        , appConfigClient.getConfigurationSetting({key : 'SNOWFLAKE_DB', label:env })
    
    ]).then( (appConfigSettings) => {
        appConfigInfo = {};

        //console.log(settings);
        appConfigSettings.forEach(e => {
            //console.log(` Setting ${e.key} ... `);
            appConfigInfo[e.key] = e.value;
            //console.log(` Value ${appConfigInfo[e.key]} ... `);
        })
        
        return appConfigInfo;
    }).catch((error) => {
        console.log(` Error while retreiving application config : ${error} `);
        context.res = {
            status: 500,
            body: {"error":error}
        };
        context.done();
    });

}

/**
 * Retreives the secrets from Key vault for the following app configs
 *  - azfn:fnQuery:snowsql_qry_usr
 *  - azfn:fnQuery:snowsql_qry_pwd
 * @param {*} context
 * @param {*} kvAppConfigKey : azfn:fnQuery:snowsql_qry_usr or azfn:fnQuery:snowsql_qry_pwd
 * @param {*} configKey : the key under which the value will be stored once retrieved.
 */
 function retreiveKeyVaultSecrets(context) {

    function getKVSecrets(context ,kvAppConfigKey ,configKey) {

        if(appConfigInfo.hasOwnProperty(configKey)) {
            return new Promise(function(resolve, reject) {
                resolve(appConfigInfo);
            });
        } 

        const kvurl_with_secret = JSON.parse(appConfigInfo[kvAppConfigKey])['uri']; 
        kvurl = kvurl_with_secret.substring(0 ,kvurl_with_secret.indexOf("/secrets"));
        kvsecret_name = kvurl_with_secret.substring(kvurl_with_secret.lastIndexOf("/")+1);
        
        const client = new SecretClient(kvurl, azCredential);

        return Promise.all([
            client.getSecret(kvsecret_name)
        ]).then( (x) => {
            //context.log(x);
            appConfigInfo[configKey] = x[0].value;
        });
    }

    context.log('Getting key vault secrets ...');
    return Promise.all([
        getKVSecrets(context ,'SNOWFLAKE_USER','snowflake-service-user' )
       ,getKVSecrets(context ,'SNOWFLAKE_PASSWD','snowflake-service-password' )
    ]); 
}


/**
 * Connects to snowflake.
 * 
 * @param {*} context 
 */
 function connectToSnowflake(context) {

    if(typeof connection !== 'undefined'  && connection != null) {
        return new Promise(function(resolve, reject) {
            resolve(connection);
        });
    } 

    context.log.info(`Connecting to snowflake account - @[${appConfigInfo["SNOWFLAKE_ACCOUNT"]}] ...`);
    context.log.info(`Connecting to snowflake using role - @[${appConfigInfo["SNOWFLAKE_ROLE"]}] ...`);
    context.log.info(`Connecting to snowflake using database - @[${appConfigInfo["SNOWFLAKE_DB"]}] ...`);
    connectionObj = snowflake.createConnection( {
                account: appConfigInfo["SNOWFLAKE_ACCOUNT"], 
                username: appConfigInfo["snowflake-service-user"], 
                password: appConfigInfo["snowflake-service-password"], 
                warehouse: appConfigInfo["SNOWFLAKE_WH"], 
                role: appConfigInfo["SNOWFLAKE_ROLE"] ,
                database: appConfigInfo["SNOWFLAKE_DB"]
            });

    return Promise.resolve(connectionObj.connect());
}     

function applyQbChanges(execId, context) {
    connection.execute({
        sqlText: 'call REFERENCE.PROC_APPLY_QB_REAL_TIME_CHANGES($$'+execId+'$$,$$az-func-apply-qb-changes$$)',
        complete: function(err, stmt, rows) {
            if (err) {                         
                context.res = {
                    status: 500,
                    body: JSON.stringify({error:err.message}),
                    headers: {'Content-Type': 'application/json' }                  
                };
                context.done();
              } else {
               const result = JSON.stringify(rows[0]);
               context.res = {
                    status: 200,
                    body: {'output':rows[0]["PROC_APPLY_QB_REAL_TIME_CHANGES"],'execution_id':execId},
                    headers: {'Content-Type': 'application/json' }  
                };
                context.done();
        }
            
        }
      })

}

function insertChangeHistory(changedDoc,requestRecdTime,context){

    const execId = uuidv1();

    context.log("Process execution ID = "+execId);
    connection.execute({
        sqlText: 'call REFERENCE.PROC_LOAD_QB_REAL_TIME_DATA(?,$$'+requestRecdTime+'$$,$$'+execId+'$$,$$az-func-apply-qb-changes$$)',
        binds:[changedDoc],
        complete: function(err, stmt, rows) {
            if (err) {                         
                context.res = {
                    status: 500,
                    body: JSON.stringify({error:err.message}),
                    headers: {'Content-Type': 'application/json' }                  
                };
                context.done();
              } else {
                applyQbChanges(execId,context)
            }
      
        }
      })
}


module.exports =  function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');

    if(!(req.body.changed_doc)) {
        context.res = {
            status: 400,
            body: {"error":"Please provide an input document"}
        };
        context.done();
        return {};
    }

    var currentUtcTime = Date.now();    
    const changedDoc = req.body.changed_doc;
    const requestRecdTime = (!req.body.request_received_time)? currentUtcTime : req.body.request_received_time ;
    context.log ("Request received time = "+requestRecdTime)

    const applicationConfigPromise = getApplicationConfigurationForSnowflake(context);
    const kvDataRetrievedConfigPromise = applicationConfigPromise
    .then( () => retreiveKeyVaultSecrets(context))
    .catch ((err) => {
        console.log(err)
        context.res = {
            status: 500,
            body: {"error":err}
        };
        context.done();
    });

    const snowflakeConnPromise =  kvDataRetrievedConfigPromise
    .then( () => connectToSnowflake(context))
    .catch ((err) => {
        console.log(err)
        context.res = {
            status: 500,
            body: {"error":err}
        };
        context.done();
    });

    snowflakeConnPromise.then( (conn) => {
            connection = conn;
            context.log('Snowflake connection '  + (connection != null));
            insertChangeHistory(changedDoc,requestRecdTime, context);
    }).catch ((err) => {
        console.log(err)
        context.res = {
            status: 500,
            body: {"error":err}
        };
        context.done();
    });
  

 
}