const { DefaultAzureCredential  }= require("@azure/identity"); //https://www.npmjs.com/package/@azure/identity
const appConfig = require("@azure/app-configuration"); //https://www.npmjs.com/package/@azure/app-configuration
const { SecretClient } = require("@azure/keyvault-secrets"); //https://www.npmjs.com/package/@azure/keyvault-secrets

var snowflake = require('snowflake-sdk');

const azCredential = new DefaultAzureCredential();

/**
 * Holds the connection and caches it. Subsequent call can use reuse the 
 * connection to speed up the process.
 */
 let connection = null;  //cache the connection 
 let appConfigInfo = null; //Caches the configuration

 /**
 * Retreives the application configuration from Azure config
 */
function getApplicationConfigurationForSnowflake(context) {
    //console.log(process.env)
    const appConfigURI = process.env["APP_CONFIG_URI"];
    const env = process.env["APP_ENV"];
    const appConfigClient = new appConfig.AppConfigurationClient(appConfigURI);

    if(appConfigInfo != null) {
        return new Promise(function(resolve, reject) {
            resolve(appConfigInfo);
        });
    } 

    context.log('Getting application context ...');
    return Promise.all([
        appConfigClient.getConfigurationSetting( {key : 'SNOWFLAKE_ACCOUNT'})
        , appConfigClient.getConfigurationSetting({key : 'SNOWFLAKE_ROLE' , label:env})
        , appConfigClient.getConfigurationSetting({key : 'SNOWFLAKE_WH', label: env})
        , appConfigClient.getConfigurationSetting({key : 'SNOWFLAKE_USER', label:env })
        , appConfigClient.getConfigurationSetting({key : 'SNOWFLAKE_PASSWD', label:env })
    
    ]).then( (appConfigSettings) => {
        appConfigInfo = {};

        //console.log(settings);
        appConfigSettings.forEach(e => {
            //console.log(` Setting ${e.key} ... `);
            appConfigInfo[e.key] = e.value;
        })
        
        return appConfigInfo;
    }).catch((error) => {
        console.log(` Error while retreiving application config : ${error} `);
        context.res = {
            status: 500,
            body: {"error":error}
        };
        context.done();
    });

}

/**
 * Retreives the secrets from Key vault for the following app configs
 *  - azfn:fnQuery:snowsql_qry_usr
 *  - azfn:fnQuery:snowsql_qry_pwd
 * @param {*} context
 * @param {*} kvAppConfigKey : azfn:fnQuery:snowsql_qry_usr or azfn:fnQuery:snowsql_qry_pwd
 * @param {*} configKey : the key under which the value will be stored once retrieved.
 */
 function retreiveKeyVaultSecrets(context) {

    function getKVSecrets(context ,kvAppConfigKey ,configKey) {

        if(appConfigInfo.hasOwnProperty(configKey)) {
            return new Promise(function(resolve, reject) {
                resolve(appConfigInfo);
            });
        } 

        const kvurl_with_secret = JSON.parse(appConfigInfo[kvAppConfigKey])['uri']; 
        kvurl = kvurl_with_secret.substring(0 ,kvurl_with_secret.indexOf("/secrets"));
        kvsecret_name = kvurl_with_secret.substring(kvurl_with_secret.lastIndexOf("/")+1);
        
        const client = new SecretClient(kvurl, azCredential);

        return Promise.all([
            client.getSecret(kvsecret_name)
        ]).then( (x) => {
            //context.log(x);
            appConfigInfo[configKey] = x[0].value;
        });
    }

    context.log('Getting key vault secrets ...');
    return Promise.all([
        getKVSecrets(context ,'SNOWFLAKE_USER','snowflake-service-user' )
       ,getKVSecrets(context ,'SNOWFLAKE_PASSWD','snowflake-service-password' )
    ]); 
}


/**
 * Connects to snowflake.
 * 
 * @param {*} context 
 */
 function connectToSnowflake(context) {

    if(typeof connection !== 'undefined'  && connection != null) {
        return new Promise(function(resolve, reject) {
            resolve(connection);
        });
    } 

     context.log.info(`Connecting to snowflake @[${appConfigInfo["SNOWFLAKE_ACCOUNT"]}] ...`);
    connectionObj = snowflake.createConnection( {
                account: appConfigInfo["SNOWFLAKE_ACCOUNT"], 
                username: appConfigInfo["snowflake-service-user"], 
                password: appConfigInfo["snowflake-service-password"], 
                warehouse: appConfigInfo["SNOWFLAKE_WH"], 
                role: appConfigInfo["SNOWFLAKE_ROLE"]  
            });

    return Promise.resolve(connectionObj.connect());
}     

function fetchFromSnowflake(database, schema, table, context){

    connection.execute({
        sqlText: 'select * from '+database+'.'+schema+'.'+table,
        complete: function(err, stmt, rows) {
            if (err) {                         
                context.res = {
                    status: 500,
                    body: JSON.stringify({error:err.message}),
                    headers: {'Content-Type': 'application/json' }                  
                };
                context.done();
              } else {
               const result = JSON.stringify(rows);
               context.res = {
                    status: 200,
                    body: JSON.stringify(rows),
                    headers: {'Content-Type': 'application/json' }  
                };
                context.done();
        }
      
        }
      })
}


module.exports =  function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');

    if(!(req.body.database && req.body.schema &&  req.body.table)) {
        context.res = {
            status: 400,
            body: {"error":"Please provide a database, schema and control table name"}
        };
        context.done();
        return {};
    }

    const db = req.body.database;
    const sc = req.body.schema;
    const tbl = req.body.table;


    const applicationConfigPromise = getApplicationConfigurationForSnowflake(context);
    const kvDataRetrievedConfigPromise = applicationConfigPromise
    .then( () => retreiveKeyVaultSecrets(context))
    .catch ((err) => {
        console.log(err)
        context.res = {
            status: 500,
            body: {"error":err}
        };
        context.done();
    });

    const snowflakeConnPromise =  kvDataRetrievedConfigPromise
    .then( () => connectToSnowflake(context))
    .catch ((err) => {
        console.log(err)
        context.res = {
            status: 500,
            body: {"error":err}
        };
        context.done();
    });

    snowflakeConnPromise.then( (conn) => {
            connection = conn;
            context.log('Snowflake connection '  + (connection != null));
            fetchFromSnowflake(db,sc,tbl,context);
    }).catch ((err) => {
        console.log(err)
        context.res = {
            status: 500,
            body: {"error":err}
        };
        context.done();
    });
  

 
}